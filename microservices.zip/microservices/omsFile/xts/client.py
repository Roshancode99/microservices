from Connect import XTSConnect


API_KEY = "5c018a4a95e23bde52d843"
API_SECRET = "Girx536$hq"
source = "WEBAPI"

xt = XTSConnect(API_KEY, API_SECRET, source)
res = xt.interactive_login()
print("Login: ", res)