import pandas as pd
import datetime
import os

class fivepaisaAPI:
    def __init__(self,apiobj):
        self.apiobj = apiobj

        # Example usage of place_order method
        res = {'event': "create", 'tradingsymbol': "HINDALCO", 'qty': 1, 'price': 400, 'order_type': 1, 'buysell': 1}
        self.place_order(res)

        # Example usage of other methods
        self.getTradeBook(self.apiobj)
        self.getPositions(self.apiobj)
        self.getHoldings(self.apiobj)
    
    def place_order(self, res):
        try:
            if res.get('event') == 'create':
                res = res.get('data')
                if res.get('booktype') == 2:
                    response = self.apiobj.place_order(
                        variety=self.apiobj.VARIETY_REGULAR,
                        exchange=self.apiobj.EXCHANGE_NSE,
                        tradingsymbol=res.get('ticker_code'),
                        transaction_type=self.apiobj.TRANSACTION_TYPE_BUY if res.get('buysell') == 1 else self.apiobj.TRANSACTION_TYPE_SELL,
                        quantity=int(res.get('qty')),
                        product=self.apiobj.PRODUCT_CNC,
                        order_type=self.apiobj.ORDER_TYPE_MARKET
                    )
                    return response

                elif res.get('booktype') == 1:
                    print("order limit", res)
                    response = self.apiobj.place_order(OrderType='B' if res.get('buysell') == 1 else 'S',
                                                        Exchange='N',
                                                        ExchangeType='D', 
                                                        ScripCode = str(int(res.get('token'))), 
                                                        Qty=res.get('qty'), 
                                                        Price=float(res.get('price')))
                    return response

            elif res.get('event') == 'modify':
                res = res.get('data')
                print("modify", res)
                response = self.apiobj.modify_order(
                    ExchOrderID=res.get('order_id'),
                    Qty=int(res.get('qty')),
                    Price=float(res.get('price')),
                )
                return response

            elif res.get('event') == 'cancel':
                res = res.get('data')
                print("cancel", res)
                response = self.apiobj.cancel_order(exchange='N', exchange_segment='D', exch_order_id=res.get('order_id'))
                return response
        except Exception as e:
            print("Error on place_order ", e, self.apiobj, res)
            return None
    
    def getOrders(self):
        data = self.apiobj.order_book()
        return data
    
    def getTradeBook(self, orderno):
        print("getTradeBook", self.apiobj, orderno)
        data = self.apiobj.order_trades(orderno)
        folder = 'tradebook'
        for i in data:
            i['client'] = 1
            query = f"""
            INSERT INTO public."TradeLogs"(uidnum, strategyid, strategy_name, servername, account_id, userid, token, product, trade_id, order_id, exchange, symbol, side, price, qty, exchange_order_id, fill_timestamp, order_timestamp, exchange_timestamp) VALUES ({0}, {0}, '{'0'}', '{'192.168.10.103'}', '{i.get('account_id')}', {0}, {i.get('instrument_token')}, '{i.get('product')}', {i.get('trade_id')}, {i.get('order_id')}, '{i.get('exchange')}', '{i.get('tradingsymbol')}', '{i.get('transaction_type')}', {i.get('average_price')}, {i.get('quantity')}, {i.get('exchange_order_id')}, '{i.get('fill_timestamp')}', '{i.get('order_timestamp')}', '{i.get('exchange_timestamp')}');
            """
            print(i.get('exchange_timestamp'))
            self._forExecuteQuery(query)
        
        path = f"""{self.baseDir}clients/{str(i['client'])}"""
        try:
            os.makedirs(path+'/'+folder)
        except FileExistsError as e:
            pass
        filedirect = os.path.join(f"""{path}/{folder}/{folder}{str(i.get('exchange_timestamp')).split(' ')[0].replace('-','')}.csv""")
        data = pd.DataFrame(data)
        data.to_csv(filedirect)
        return data
    
    def getPositions(self):
        data = self.apiobj.positions()
        data = data.get('net')
        data = pd.DataFrame(data)
        data['client'] = 1
        data['netpositionno'] = data['client'].astype(str) + data['instrument_token'].astype(str)
        data['date'] = str(datetime.datetime.now().strftime('%Y%m%d'))
        print(data)
        data.to_csv('netposition.csv')
    
    def getHoldings(self):
        data = self.apiobj.holdings()
        print(data)
