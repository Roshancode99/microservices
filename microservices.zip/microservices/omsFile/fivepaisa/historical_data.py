from datetime import datetime
from py5paisa import FivePaisaClient
import logging,json,os
from utilities import Utilities


class FivepaisaOMS(Utilities):
    
    def __init__(self):
        super().__init__()
        logging.basicConfig(filename=f"""{os.getcwd()}/Logs/ErrorLogs/ErrorLogs{str(datetime.now().strftime('%Y%m%d'))}.log""", filemode='a',format='%(asctime)s - %(levelname)s - %(message)s')
        apidetails=self.jsonConfigfile.get('fivepaisa_api')
        self.fivepaisa=FivePaisaClient(cred=apidetails.get('cred'))

        self.fivepaisa.access_token = apidetails.get('access_token')
        self.fivepaisa.Jwt_token = apidetails.get('access_token')
        self.fivepaisa.client_code = apidetails.get('client_code')


        temp=self.fivepaisa.historical_data('N','C',999920000,'1m','2023-08-01','2023-08-07')
        print(temp)

        

FivepaisaOMS()