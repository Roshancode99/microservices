from datetime import datetime,timedelta,date
from py5paisa import FivePaisaClient
import logging,json,os
from utilities import Utilities,print_green,print_red,print_yellow
import pandas as pd
import sysv_ipc
import os

class FivepaisaOMS(Utilities):
    
    def __init__(self):
        super().__init__()
        self.flag=1
        self.bodPathPath=self.jsonConfigfile.get('settings').get('fileLocation').get('bodPath')
        self.todayDate = str(date.today()).replace('-','')

        self.market_feeds = sysv_ipc.MessageQueue(self.QKeys.get('market_feeds'),sysv_ipc.IPC_CREAT)

        self.tokenidKeyMapDict = dict()
        self.tokenidKeyMapDict = self.gettokenidKeyContractFile()


        while self.flag>0:
            with open('/home/centos/pushpendra/rms-be/microservices/Logs/PrintLogs/fivepaisa_market_feed', 'r') as file:
                # print(file.readline())
                for line in file.readlines():
                    try:
                        data_str = line.strip().replace("'", "\"")
                        temp=json.loads(data_str)
                        temp['token']=self.tokenidKeyMapDict.get(temp.get('token'))
                        print_green(temp)
                        self.market_feeds.send(json.dumps(temp))
                        
                    except:
                        print_red("Error on ")

    def gettokenidKeyContractFile(self):
        tokenidKeyMapDict = dict()
        filePath =self.baseDir+self.bodPathPath+'nse_contractfile'+self.todayDate+'.csv'
        print("gettokenidKeyContractFile ***************",filePath)
        if(os.path.exists(filePath)):
            df = pd.read_csv(filePath, usecols = ['token','tokenid2'])
            tokenidKeyMapDict = dict(zip(df.token, df.tokenid2))
        else:
            cur_date = datetime.strptime(self.todayDate, "%Y%m%d").date()
            pre_date = str(cur_date+ timedelta(days=-1)).replace('-','')
            self.todayDate = pre_date
            self.gettokenidKeyContractFile()
        return tokenidKeyMapDict
    # 262007762946
    # 262006334466

FivepaisaOMS()