import os
import requests
from datetime import datetime

class Contract_Gen:
    
    def __init__(self):
        # Generate the file path with today's date
        current_date = datetime.now().strftime('%Y%m%d')
        file_path = f'/home/centos/pushpendra/rms-be/sharedMemory/store/contracts/fivepaisa_contractfile_{current_date}.csv'
        
        if os.path.exists(file_path):
            # If file already exists for today's date, open it in append mode
            with open(file_path, 'a') as f:
                f.write("\n")  # Add a newline separator
                res = requests.get('https://images.5paisa.com/website/scripmaster-csv-format.csv')
                if res.status_code == 200:
                    f.write(res.text)  # Append the content to the existing file
                    print("File updated successfully:", file_path)
                else:
                    print("Something went wrong while updating file!!! Status Code:", res.status_code)
        else:
            # If file doesn't exist for today's date, create a new file
            res = requests.get('https://images.5paisa.com/website/scripmaster-csv-format.csv')
            if res.status_code == 200:
                with open(file_path, 'w+') as f:
                    f.write(res.text)
                print("File created successfully:", file_path)
            else:
                print("Something went wrong while creating file!!! Status Code:", res.status_code)

Contract_Gen()
