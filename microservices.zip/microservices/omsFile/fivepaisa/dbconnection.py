import psycopg2
import logging
from psycopg2.extensions import ISOLATION_LEVEL_AUTOCOMMIT
import sys
import json

class DBCon:

    def __init__(self):
        settingFile = sys.argv[1]
        try:
            with open(settingFile, "r") as jsonfile:
                self.jsonConfigfile = json.load(jsonfile)
                # print(self.jsonConfigfile)
                # dbcon = self.jsonConfigfile.get("dbcon")
                dbcon = self.jsonConfigfile.get("dbconTest")
                print(dbcon)
        except Exception as e:
            print(e)

        self.con = psycopg2.connect(host=dbcon['host'],port=dbcon['port'],dbname=dbcon['dbname'], user=dbcon['user'])
          
    def _forFetchQuery(self, query):
        try:
            cursor = self.con.cursor()
            cursor.execute(query)
            data=cursor.fetchall()
            data = [(dict((cursor.description[i][0].lower(), val)
                    for i, val in enumerate(row))) for row in data]
            cursor.close()
            # self.conSource.close()
            return data
        except Exception as e:
            print(e)

    def _forExecuteQuery(self, query):
        try :
            self.con.set_isolation_level(ISOLATION_LEVEL_AUTOCOMMIT)
            cursor = self.con.cursor()
            cursor.execute(query)
            self.con.commit()
        except Exception as e :
            print("[Error] in (SQLDATA,forUpdate) msg: ",str(e))  
            self.con.rollback()
            logging.basicConfig(filename='Query.log', filemode='a', format='%(name)s - %(levelname)s - %(message)s')
            logging.warning(query)
   
# DBCon()


# import psycopg2
# import logging
# from psycopg2.extensions import ISOLATION_LEVEL_AUTOCOMMIT
# import sys
# import json

# class DBCon:

#     def _init_(self):
        
#         # database connection
#         self.con = psycopg2.connect(host="52.66.127.232",port="5432",dbname="cosmicTest", user="postgres")
#         self.con.set_isolation_level(psycopg2.extensions.ISOLATION_LEVEL_AUTOCOMMIT)

#         # self.con = psycopg2.connect(host=dbcon['host'],port=dbcon['port'],dbname=dbcon['dbname'], user=dbcon['user'])
          
#     def _forFetchQuery(self, query):
#         try:
#             cursor = self.con.cursor()
#             cursor.execute(query)
#             data=cursor.fetchall()
#             data = [(dict((cursor.description[i][0].lower(), val)
#                     for i, val in enumerate(row))) for row in data]
#             cursor.close()
            
#             # self.conSource.close()
#             return data
#         except Exception as e:
#             print(e)

#     def _forExecuteQuery(self, query):
#         try :
#             self.con.set_isolation_level(ISOLATION_LEVEL_AUTOCOMMIT)
#             cursor = self.con.cursor()
#             cursor.execute(query)
#             self.con.commit()
#         except Exception as e :
#             print("[Error] in (SQLDATA,forUpdate) msg: ",str(e))  
#             self.con.rollback()
#             logging.basicConfig(filename='Query.log', filemode='a', format='%(name)s - %(levelname)s - %(message)s')
#             logging.warning(query)
         
   
# DBCon()

# # import psycopg2
# # import logging
# # from psycopg2.extensions import ISOLATION_LEVEL_AUTOCOMMIT
# # import sys
# # import json

# # class DBCon:

# #     def __init__(self):
        
# #         # database connection
# #         self.con = psycopg2.connect(host="52.66.127.232",port="5432",dbname="cosmicTest", user="postgres")
# #         self.con.set_isolation_level(psycopg2.extensions.ISOLATION_LEVEL_AUTOCOMMIT)

# #         # self.con = psycopg2.connect(host=dbcon['host'],port=dbcon['port'],dbname=dbcon['dbname'], user=dbcon['user'])
          
# #     def _forFetchQuery(self, query):
# #         try:
# #             cursor = self.con.cursor()
# #             cursor.execute(query)
# #             data=cursor.fetchall()
# #             data = [(dict((cursor.description[i][0].lower(), val)
# #                     for i, val in enumerate(row))) for row in data]
# #             cursor.close()
            
# #             # self.conSource.close()
# #             return data
# #         except Exception as e:
# #             print(e)

# #     def _forExecuteQuery(self, query):
# #         try :
# #             self.con.set_isolation_level(ISOLATION_LEVEL_AUTOCOMMIT)
# #             cursor = self.con.cursor()
# #             cursor.execute(query)
# #             self.con.commit()
# #         except Exception as e :
# #             print("[Error] in (SQLDATA,forUpdate) msg: ",str(e))  
# #             self.con.rollback()
# #             logging.basicConfig(filename='Query.log', filemode='a', format='%(name)s - %(levelname)s - %(message)s')
# #             logging.warning(query)
         
   
# # DBCon()