from utilities import Utilities
import threading
from datetime import datetime,timedelta
import json
import threading
import sysv_ipc
from fivepaisaAPI import fivepaisaAPI
from py5paisa import FivePaisaClient
import logging
import time
import pandas as pd
import os,re

class FivepaisaOMS(Utilities):
    
    def __init__(self):
        super().__init__()
        logging.basicConfig(filename=f"""{os.getcwd()}/Logs/ErrorLogs/ErrorLogs{str(datetime.now().strftime('%Y%m%d'))}.log""", filemode='a',format='%(asctime)s - %(levelname)s - %(message)s')

        self.broker_api_queue=self.jsonConfigfile.get('broker_api_queue')
        
        # Initialize empty credentials
        self.apidetails = {}
        self.fivepaisa = None
        self.tradelist=[]
        self.flag=1
        self.percent=10
        self.apis={}
        self.clientAPIInstence={}
        self.clientOrderBookThreads={}


        try:
            self.fivepaisaOMS = sysv_ipc.MessageQueue(self.QKeys.get('fivepaisaOMS'),sysv_ipc.IPC_CREX)
        except Exception as e: 
            self.fivepaisaOMS = sysv_ipc.MessageQueue(self.QKeys.get('fivepaisaOMS'))

        try:
            self.fivepaisaAPI = sysv_ipc.MessageQueue(self.broker_api_queue.get('fivepaisaAPI'),sysv_ipc.IPC_CREX)
        except Exception as e: 
            self.fivepaisaAPI = sysv_ipc.MessageQueue(self.broker_api_queue.get('fivepaisaAPI'))

        try:
            self.dbWriterQueueList = sysv_ipc.MessageQueue(self.QKeys.get('dbWriterQueue'),sysv_ipc.IPC_CREX)
        except Exception as e:
            self.dbWriterQueueList = sysv_ipc.MessageQueue(self.QKeys.get('dbWriterQueue'))

        threading.Thread(target=self.fivepaisaAPIQueueReader).start()
        threading.Thread(target=self.fivepaisaOMSQueueReader).start()
        threading.Thread(target=self.writeAllResponseFromAPI).start()

    def writeAllResponseFromAPI(self):
        while self.flag>0:
            try:
                t=pd.DataFrame(self.tradelist)
                t.to_csv(f"""{os.getcwd()}/Logs/fivepaisa_tradelist_{str(datetime.now().strftime('%Y%m%d'))}.csv""")
                time.sleep(1)
            except Exception as e:
                print("Error on writeAllResponseFromAPI",e)



    # def makeFivepaisaConnection(self,apidetails):
    #     try:
    #         fivepaisa=FivePaisaClient(cred=apidetails.get('cred'))
    #         fivepaisa.access_token = apidetails.get('access_token')
    #         fivepaisa.Jwt_token = apidetails.get('access_token')
    #         fivepaisa.client_code = apidetails.get('client_code')
    #         return fivepaisa
    #     except Exception as e:
    #         print("error on makeFivepaisaConnection",e)
    #         logging.warning(f"""{datetime.now()} {str(apidetails)} Error on makeFivepaisaConnection!!!""")
    #         return None
                
    def makeFivepaisaConnection(self, credentials):
        try:
            self.apidetails = credentials
            self.fivepaisa = FivePaisaClient(cred=self.apidetails.get('cred'))
            self.fivepaisa.access_token = self.apidetails.get('access_token')
            self.fivepaisa.Jwt_token = self.apidetails.get('access_token')
            self.fivepaisa.client_code = self.apidetails.get('client_code')
           
        except Exception as e:
            print("Error updating credentials:", e)

    def fivepaisaOMSQueueReader(self):
        print('waiting for message queue reading .............')
        while self.flag > 0:
            data=dict()
            try:
                item = self.fivepaisaOMS.receive()
                item = json.loads(item[0])
                data=item.get('data')
                self.tradelist.append(data)
                print(item)
                
                if item.get('data').get('buysell')==1:
                    item['data']['price']=int(item['data']['price'])+(int(item['data']['price'])*(self.percent/100))

                if item.get('data').get('buysell')==2:
                    item['data']['price']=int(item['data']['price'])-(int(item['data']['price'])*(self.percent/100))

                item['data']['price']=self.roundPrice(item['data']['price'])/100

                res=fivepaisaAPI.place_order(item,self.clientAPIInstence.get(item.get('data').get('client')))
                logging.warning(f"""{datetime.now()} {str(res)} call fivepaisaOMSQueueReader!!!""")
                
            except Exception as e:
                print("[Error] in (self,fivepaisaOMSQueueReader) msg: ", str(e))
                break

    def fivepaisaAPIQueueReader(self):
        print("fivepaisaAPIQueueReader")
        while self.flag > 0:
            data=dict()
            try:
                item = self.fivepaisaAPI.receive()
                item = json.loads(item[0])
                print(item)
                data=item.get('data')
                if item.get('event')=='add' or item.get('event')=='update':
                    self.apis[data.get('client')]=data
                    self.clientAPIInstence[data.get('client')]=self.makeFivepaisaConnection(data.get('api_config'))
                    self.clientOrderBookThreads[data.get('client')]=threading.Thread(
                        target=self.getOrderBook,args=(
                            self.clientAPIInstence[data.get('client')],data.get('client'))).start()
                elif  item.get('event')=='delete':
                    del self.apis[data.get('client')]
                    del self.clientAPIInstence[data.get('client')]
                    del self.clientOrderBookThreads[data.get('client')]

                print(self.apis)
                print(self.clientAPIInstence)
                logging.warning(f"""{datetime.now()} {str(item)} fivepaisaAPIQueueReader!!!""")
                
            except Exception as e:
                print("[Error] in (self,fivepaisaAPIQueueReader) msg: ", str(e))

    def getOrderBook(self,fivepaisa,client):
        tradecount=0
        while self.flag>0:
            try:
                orders=fivepaisaAPI.getOrders(fivepaisa)
                if orders:
                    if tradecount<len(orders):
                        for i in orders:
                            print(i)

                            input_timestamp = i.get('BrokerOrderTime')
                            # Extract timestamp and offset using regex
                            # Extract milliseconds timestamp and UTC offset from input string
                            milliseconds_timestamp = int(input_timestamp.split('(')[1].split('+')[0])
                            utc_offset_str = input_timestamp.split('+')[1][:-2]


                            # Convert milliseconds to seconds
                            timestamp_seconds = milliseconds_timestamp / 1000

                            unix_timestamp=int((timestamp_seconds+19800)*1000)
                         
                            print(unix_timestamp)

                            if i.get('OrderStatus')=='Fully Executed':
                                trade={"TradedOrderNo":i.get('ExchOrderID'),
                                                    "TraderId":0,
                                                    "TransCode":20222,
                                                    "SuperAdm":0,
                                                    "Adm":0,
                                                    "Client":client,
                                                    "RealTrade":1,
                                                    "StrategyID":0,
                                                    "UIDNum":0,
                                                    "Exchange":'NSE',
                                                    "Segment":'FO',
                                                    "ServerName":'AWS',
                                                    "TimeStampNs":unix_timestamp,
                                                    "BrokerId":0,
                                                    "AccountNo":"DAcc",
                                                    "BuySell":1 if i.get('BuySell')=='B' else 2,
                                                    "OrigVol":i.get('Qty'),
                                                    "DiscVol":i.get('DisClosedQty'),
                                                    "RemVol":i.get('PendingQty'),
                                                    "RemDiscVol":i.get('PendingQty'),
                                                    "Price":i.get('Rate')*100,
                                                    "GoodTillDate":0,
                                                    "FillNum":i.get('ExchOrderID'),
                                                    "FillQty":i.get('Qty'),
                                                    "FillPrice":float(i.get('AveragePrice'))*100,
                                                    "VolFilledToday":i.get('Qty'),
                                                    "Logtime":0,
                                                    "Token":i.get('ScripCode'),
                                                    "PAN":'FWAPD2222E',
                                                    "NNFField":0,
                                                    "AlgoId":0,
                                                    "Algocategory":0,
                                                    "LAR":0,
                                                    "brokername":"fivepaisa" 

                                                    }
                                print(trade)
                                self.dbWriterQueueList.send(json.dumps({'write':'tradebook','data':trade}))

                            if i.get('OrderStatus')=='Rejected By 5P':
                                trade={"TradedOrderNo":i.get('ExchOrderID'),
                                                    "TraderId":0,
                                                    "TransCode":20231,
                                                    "SuperAdm":0,
                                                    "Adm":0,
                                                    "Client":client,
                                                    "RealTrade":1,
                                                    "StrategyID":0,
                                                    "UIDNum":0,
                                                    "Exchange":'NSE',
                                                    "Segment":'FO',
                                                    "ServerName":'AWS',
                                                    "TimeStampNs":unix_timestamp,
                                                    "BrokerId":0,
                                                    "AccountNo":"DAcc",
                                                    "BuySell": 1 if i.get('BuySell')=='B' else 2,
                                                    "OrigVol":i.get('Qty'),
                                                    "DiscVol":i.get('DisClosedQty'),
                                                    "RemVol":i.get('PendingQty'),
                                                    "RemDiscVol":i.get('PendingQty'),
                                                    "Price":i.get('Rate')*100,
                                                    "GoodTillDate":0,
                                                    "FillNum":i.get('ExchOrderID'),
                                                    "FillQty":i.get('Qty'),
                                                    "FillPrice":float(i.get('Rate') if i.get('Rate')!="" else 0)*100,
                                                    "VolFilledToday":i.get('Qty'),
                                                    "Logtime":0,
                                                    "Token":i.get('ScripCode'),
                                                    "PAN":'FWAPD2222E',
                                                    "NNFField":0,
                                                    "AlgoId":0,
                                                    "Algocategory":0,
                                                    "LAR":0,
                                                    "BookType":1 ,
                                                    "brokername":"fivepaisa" 
                                                    }
                                self.dbWriterQueueList.send(json.dumps({'write':'ordererrorlogs','data':trade}))
                            
                            if i.get('OrderStatus')=='Pending':
                                trade={"TradedOrderNo":i.get('ExchOrderID'),
                                                    "TraderId":0,
                                                    "TransCode":20073,
                                                    "SuperAdm":0,
                                                    "Adm":0,
                                                    "Client":client,
                                                    "RealTrade":1,
                                                    "StrategyID":0,
                                                    "UIDNum":0,
                                                    "Exchange":'NSE',
                                                    "Segment":'FO',
                                                    "ServerName":'AWS',
                                                    "TimeStampNs":unix_timestamp,
                                                    "BrokerId":0,
                                                    "AccountNo":"DAcc",
                                                    "BuySell":1 if i.get('BuySell')=='B' else 2,
                                                    "OrigVol":i.get('Qty'),
                                                    "DiscVol":i.get('DisClosedQty'),
                                                    "RemVol":i.get('PendingQty'),
                                                    "RemDiscVol":i.get('PendingQty'),
                                                    "Price":i.get('Rate')*100,
                                                    "GoodTillDate":0,
                                                    "FillNum":i.get('ExchOrderID'),
                                                    "FillQty":i.get('Qty'),
                                                    "FillPrice":float(i.get('Rate'))*100,
                                                    "VolFilledToday":i.get('Qty'),
                                                    "Logtime":0,
                                                    "Token":i.get('ScripCode'),
                                                    "PAN":'FWAPD2222E',
                                                    "NNFField":0,
                                                    "AlgoId":0,
                                                    "Algocategory":0,
                                                    "LAR":0,
                                                    "BookType":1 ,
                                                    "brokername":"fivepaisa" 

                                                    }
                                self.dbWriterQueueList.send(json.dumps({'write':'orderlogs','data':trade}))

                        print(f"""{len(orders)-tradecount} New Trade!!!!! Total Trades {len(orders)} {str(client)}""")
                        tradecount=len(orders)
                    else:
                        print("Trade Not Found!!!!!",client)
                else:
                    print("No Order Placed yet!!!!!",client)

            except Exception as e:
                print("Error on insertTradeBook",e,client)
            
            time.sleep(20)


FivepaisaOMS()
