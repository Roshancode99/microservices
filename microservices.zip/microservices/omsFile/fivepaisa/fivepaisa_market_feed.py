from datetime import datetime, date, timedelta
from py5paisa import FivePaisaClient
import logging, json, os
from utilities import Utilities
import pandas as pd
import sysv_ipc

class FivepaisaOMS(Utilities):
    
    def __init__(self):
        super().__init__()
        logging.basicConfig(filename=f"{os.getcwd()}/Logs/ErrorLogs/ErrorLogs{str(datetime.now().strftime('%Y%m%d'))}.log", filemode='a',format='%(asctime)s - %(levelname)s - %(message)s')
        
        self.bodPathPath = self.jsonConfigfile.get('settings').get('fileLocation').get('bodPath')
        self.todayDate = str(date.today()).replace('-', '')

        self.market_feeds = sysv_ipc.MessageQueue(self.QKeys.get('market_feeds'), sysv_ipc.IPC_CREAT)
        self.tokenidKeyMapDict = self.gettokenidKeyContractFile()

        temp = pd.read_csv(f"{self.baseDir}store/contracts/fivepaisa_contractfile{str(datetime.now().strftime('%Y%m%d'))}.csv", usecols=['Exch', 'ExchType', 'Scripcode', 'ISIN', 'StrikeRate'])
        temp = temp.loc[((temp['Exch'] == 'N') & (temp['ExchType'] == 'D') & ((temp['ISIN'] == 'BANKNIFTY') | (temp['ISIN'] == 'NIFTY')) )]
        req_list = temp.to_dict('records')
        req_list.append({ "Exch": "N", "ExchType": "C", "ScripCode": 999920000 })
        req_list.append({ "Exch": "N", "ExchType": "C", "ScripCode": 999920005 })

        apidetails = self.jsonConfigfile.get('fivepaisa_api')
        self.fivepaisa = FivePaisaClient(cred=apidetails.get('cred'))
        self.fivepaisa.access_token = apidetails.get('access_token')
        self.fivepaisa.Jwt_token = apidetails.get('access_token')
        self.fivepaisa.client_code = apidetails.get('client_code')

        req_data = self.fivepaisa.Request_Feed('mf', 's', req_list)

        def on_message(ws, message):
            try:
                data = json.loads(message)[0]
                temp = {
                    "token": 26000 if data.get('Token') == 999920000 else (26001 if data.get('Token') == 999920005 else data.get('Token')),
                    "bid": int(data.get('BidRate') * 100),
                    "bidqty": data.get('BidQty'),
                    "askqty": data.get('OffQty'),
                    "ask": int(data.get('OffRate') * 100),
                    "ltp": int(data.get('LastRate') * 100),
                    "ltq": data.get('LastQty'),
                    "ltt": "",
                    "exchange_timestamp": str(datetime.fromtimestamp(int(data['TickDt'].replace('/Date(', '').replace(')/', '')) / 1000.0))
                }
                print(temp)
                temp['token'] = self.tokenidKeyMapDict.get(temp.get('token'))
                self.market_feeds.send(json.dumps(temp))
            except Exception as e:
                logging.error(f"Error in processing message: {e}")

        self.fivepaisa.connect(req_data)
        self.fivepaisa.receive_data(on_message)

    def gettokenidKeyContractFile(self):
        tokenidKeyMapDict = dict()
        filePath = f"{self.baseDir}{self.bodPathPath}nse_contractfile{self.todayDate}.csv"
        if os.path.exists(filePath):
            df = pd.read_csv(filePath, usecols=['token', 'tokenid2'])
            tokenidKeyMapDict = dict(zip(df.token, df.tokenid2))
        else:
            cur_date = datetime.strptime(self.todayDate, "%Y%m%d").date()
            pre_date = str(cur_date + timedelta(days=-1)).replace('-', '')
            self.todayDate = pre_date
            self.gettokenidKeyContractFile()
        return tokenidKeyMapDict

FivepaisaOMS()
