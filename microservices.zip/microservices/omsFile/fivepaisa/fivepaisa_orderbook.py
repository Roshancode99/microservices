from utilities import Utilities
import threading
from datetime import datetime
import json,traceback
import threading
import sysv_ipc
from fivepaisaAPI import fivepaisaAPI
from py5paisa import FivePaisaClient
import logging
import time
import pandas as pd
import os,re

class FivepaisaOMS(Utilities):
    
    def __init__(self):
        super().__init__()
        logging.basicConfig(filename=f"""{os.getcwd()}/Logs/ErrorLogs/ErrorLogs{str(datetime.now().strftime('%Y%m%d'))}.log""", filemode='a',format='%(asctime)s - %(levelname)s - %(message)s')
        self.tradecount=0
        self.date_format = '%d-%m-%Y %H:%M:%S'
        self.todayDate = str(datetime.today()).replace('-','')
        apidetails=self.jsonConfigfile.get('fivepaisa_api')
        self.fivepaisa=FivePaisaClient(cred=apidetails.get('cred'))
        self.fivepaisa.access_token = apidetails.get('access_token')
        self.fivepaisa.Jwt_token = apidetails.get('access_token')
        self.fivepaisa.client_code = apidetails.get('client_code')

        self.tradelist=[]
        self.flag=1
        self.allresponse={}
        print("fivepaisa_orderbook")

        try:
            self.dbWriterQueueList = sysv_ipc.MessageQueue(self.QKeys.get('dbWriterQueue'),sysv_ipc.IPC_CREX)
        except Exception as e:
            self.dbWriterQueueList = sysv_ipc.MessageQueue(self.QKeys.get('dbWriterQueue'))

        while self.flag>0:
            self.insertTradeBook()
            time.sleep(20)


    def insertTradeBook(self):
        try:
            orders=fivepaisaAPI.getOrders(self.fivepaisa)

            if orders:
                
                if self.tradecount<len(orders):

                    temp=pd.DataFrame(orders)
                    for i in orders:
                        input_string = i.get('BrokerOrderTime')
                        match = re.match(r"/Date\((\d+)\+(\d+)\)/", input_string)
                        if match:
                            unix_timestamp = int(match.group(1)) // 1000 
                        else:
                            print("Invalid input string format.")

                        if i.get('OrderStatus')=='Fully Executed':
                            trade={"TradedOrderNo":i.get('ExchOrderID'),
                                                "TraderId":0,
                                                "TransCode":20222,
                                                "SuperAdm":0,
                                                "Adm":0,
                                                "Client":2,
                                                "RealTrade":1,
                                                "StrategyID":0,
                                                "UIDNum":0,
                                                "Exchange":'NSE',
                                                "Segment":'FO',
                                                "ServerName":'AWS',
                                                "TimeStampNs":unix_timestamp,
                                                "BrokerId":0,
                                                "AccountNo":"DAcc",
                                                "BuySell":1 if i.get('BuySell')=='B' else 2,
                                                "OrigVol":i.get('Qty'),
                                                "DiscVol":i.get('DisClosedQty'),
                                                "RemVol":i.get('PendingQty'),
                                                "RemDiscVol":i.get('PendingQty'),
                                                "Price":i.get('Rate')*100,
                                                "GoodTillDate":0,
                                                "FillNum":i.get('ExchOrderID'),
                                                "FillQty":i.get('Qty'),
                                                "FillPrice":float(i.get('AveragePrice'))*100,
                                                "VolFilledToday":i.get('Qty'),
                                                "Logtime":0,
                                                "Token":i.get('ScripCode'),
                                                "PAN":'FWAPD2222E',
                                                "NNFField":0,
                                                "AlgoId":0,
                                                "Algocategory":0,
                                                "LAR":0,
                                                "brokername":"fivepaisa" 

                                                }
                            print(trade)
                            self.dbWriterQueueList.send(json.dumps({'write':'tradebook','data':trade}))

                        if i.get('OrderStatus')=='Rejected By 5P':
                            trade={"TradedOrderNo":i.get('ExchOrderID'),
                                                "TraderId":0,
                                                "TransCode":20231,
                                                "SuperAdm":0,
                                                "Adm":0,
                                                "Client":2,
                                                "RealTrade":1,
                                                "StrategyID":0,
                                                "UIDNum":0,
                                                "Exchange":'NSE',
                                                "Segment":'FO',
                                                "ServerName":'AWS',
                                                "TimeStampNs":unix_timestamp,
                                                "BrokerId":0,
                                                "AccountNo":"DAcc",
                                                "BuySell": 1 if i.get('BuySell')=='B' else 2,
                                                "OrigVol":i.get('Qty'),
                                                "DiscVol":i.get('DisClosedQty'),
                                                "RemVol":i.get('PendingQty'),
                                                "RemDiscVol":i.get('PendingQty'),
                                                "Price":i.get('Rate')*100,
                                                "GoodTillDate":0,
                                                "FillNum":i.get('ExchOrderID'),
                                                "FillQty":i.get('Qty'),
                                                "FillPrice":float(i.get('Rate') if i.get('Rate')!="" else 0)*100,
                                                "VolFilledToday":i.get('Qty'),
                                                "Logtime":0,
                                                "Token":i.get('ScripCode'),
                                                "PAN":'FWAPD2222E',
                                                "NNFField":0,
                                                "AlgoId":0,
                                                "Algocategory":0,
                                                "LAR":0,
                                                "BookType":1 ,
                                                "brokername":"fivepaisa" 
                                                }
                            self.dbWriterQueueList.send(json.dumps({'write':'ordererrorlogs','data':trade}))
                        
                        if i.get('OrderStatus')=='Pending':
                            trade={"TradedOrderNo":i.get('ExchOrderID'),
                                                "TraderId":0,
                                                "TransCode":20073,
                                                "SuperAdm":0,
                                                "Adm":0,
                                                "Client":2,
                                                "RealTrade":1,
                                                "StrategyID":0,
                                                "UIDNum":0,
                                                "Exchange":'NSE',
                                                "Segment":'FO',
                                                "ServerName":'AWS',
                                                "TimeStampNs":unix_timestamp,
                                                "BrokerId":0,
                                                "AccountNo":"DAcc",
                                                "BuySell":1 if i.get('BuySell')=='B' else 2,
                                                "OrigVol":i.get('Qty'),
                                                "DiscVol":i.get('DisClosedQty'),
                                                "RemVol":i.get('PendingQty'),
                                                "RemDiscVol":i.get('PendingQty'),
                                                "Price":i.get('Rate')*100,
                                                "GoodTillDate":0,
                                                "FillNum":i.get('ExchOrderID'),
                                                "FillQty":i.get('Qty'),
                                                "FillPrice":float(i.get('Rate'))*100,
                                                "VolFilledToday":i.get('Qty'),
                                                "Logtime":0,
                                                "Token":i.get('ScripCode'),
                                                "PAN":'FWAPD2222E',
                                                "NNFField":0,
                                                "AlgoId":0,
                                                "Algocategory":0,
                                                "LAR":0,
                                                "BookType":1 ,
                                                "brokername":"fivepaisa" 

                                                }
                            self.dbWriterQueueList.send(json.dumps({'write':'orderlogs','data':trade}))

                    print(f"""{len(orders)-self.tradecount} New Trade!!!!! Total Trades {len(orders)} """)
                    self.tradecount=len(orders)
                else:
                    print("Trade Not Found!!!!!")


        except Exception as e:
            print("Error on insertTradeBook",e)
    

FivepaisaOMS()