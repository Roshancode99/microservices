import pandas as pd
import datetime
import os

class ZerodhaAPI:
    
    @classmethod
    def place_order(self,res,apiobj):
        try:
            if res.get('event')=='create':
                res=res.get('data')
                if res.get('booktype')==2:
                    pass

                elif res.get('booktype')==1:
                    print("order limit",res)
                    response=apiobj.place_order(
                                            variety=apiobj.VARIETY_REGULAR,
                                            exchange=apiobj.EXCHANGE_NFO,
                                            tradingsymbol= res.get('ticker_code'),
                                            transaction_type=apiobj.TRANSACTION_TYPE_BUY if res.get('buysell')==1 else apiobj.TRANSACTION_TYPE_SELL,
                                            quantity=int(res.get('qty')),
                                            price=float(res.get('price')),
                                            product=apiobj.PRODUCT_NRML,
                                            order_type=apiobj.ORDER_TYPE_LIMIT,
                                            tag=str(res.get('strategyid'))
                                        )
                    return response

            elif res.get('event')=='modify':
                res=res.get('data')
                print("modify",res)
                # response=apiobj.modify_order(
                #                             ExchOrderID= res.get('order_id'),
                #                             Qty=int(res.get('qty')),
                #                             Price=float(res.get('price')),
                #                         )
                # return response

            elif res.get('event')=='cancel':
                res=res.get('data')
                print("cancel",res)
                # response=apiobj.cancel_order(exchange='N',exchange_segment='D',exch_order_id=res.get('order_id'))
                # return response
        except Exception as e:
            print("Error on place_order ",e,apiobj,res)
            return None
    
    @classmethod
    def getOrders(self,apiobj):
        data=apiobj.orders()
        # print(data)
        return data

    @classmethod
    def getPositions(self,apiobj):
        data=apiobj.positions()
        data=data.get('net')
        data=pd.DataFrame(data)
        data['client']=1
        data['netpositionno']=data['client'].astype(str)+data['instrument_token'].astype(str)
        data['date']=str(datetime.datetime.now().strftime('%Y%m%d'))
        print(data)
        data.to_csv('netposition.csv')
        # for i in data:
        #     print(i)
    
    @classmethod
    def getHoldings(self,apiobj):
        data=apiobj.holdings()
        print(data)

ZerodhaAPI()

