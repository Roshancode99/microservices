import requests
from utilities import Utilities
from datetime import datetime
from kiteconnect import KiteConnect
import pandas as pd

class Contract_Gen(Utilities):
    
    def __init__(self):
        super().__init__()
        apidetails=self.jsonConfigfile.get('zerodha_api')
        self.zerodha=KiteConnect(apidetails.get('api_key'))
        self.zerodha.set_access_token(apidetails.get("access_token"))
        res=pd.DataFrame(self.zerodha.instruments())

        print(res)
        if res.shape[0]:
            res.to_csv(self.baseDir+'store/contracts/zerodha_contractfile'+str(datetime.now().strftime('%Y%m%d'))+'.csv')
        else:
            print("Something wents wrong!!!",res)

Contract_Gen()