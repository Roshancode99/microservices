from utilities import Utilities
import threading
from datetime import datetime,timedelta
import json
import threading
import sysv_ipc
from zerodhaAPI import ZerodhaAPI
from kiteconnect import KiteConnect
import logging
import time
import pandas as pd
import os,re

class ZerodhaOMS(Utilities):
    
    def __init__(self):
        super().__init__()
        logging.basicConfig(filename=f"""{os.getcwd()}/Logs/ErrorLogs/ErrorLogs{str(datetime.now().strftime('%Y%m%d'))}.log""", filemode='a',format='%(asctime)s - %(levelname)s - %(message)s')
        self.broker_api_queue=self.jsonConfigfile.get('broker_api_queue')




        self.tradelist=[]
        self.flag=1
        self.percent=10
        self.apis={}
        self.clientAPIInstence={}
        self.clientOrderBookThreads={}

        print("zerodhaOMS")

        try:
            self.zerodhaOMS = sysv_ipc.MessageQueue(self.QKeys.get('zerodhaOMS'),sysv_ipc.IPC_CREX)
        except Exception as e: 
            self.zerodhaOMS = sysv_ipc.MessageQueue(self.QKeys.get('zerodhaOMS'))

        try:
            self.zerodhaAPI = sysv_ipc.MessageQueue(self.broker_api_queue.get('zerodhaAPI'),sysv_ipc.IPC_CREX)
        except Exception as e: 
            self.zerodhaAPI = sysv_ipc.MessageQueue(self.broker_api_queue.get('zerodhaAPI'))

        try:
            self.dbWriterQueueList = sysv_ipc.MessageQueue(self.QKeys.get('dbWriterQueue'),sysv_ipc.IPC_CREX)
        except Exception as e:
            self.dbWriterQueueList = sysv_ipc.MessageQueue(self.QKeys.get('dbWriterQueue'))

        self.zerodhaToTokenMap=self.zerodhaToToken()

        threading.Thread(target=self.zerodhaAPIQueueReader).start()
        threading.Thread(target=self.zerodhaOMSQueueReader).start()
        threading.Thread(target=self.writeAllResponseFromAPI).start()

    def zerodhaToToken(self):
        tokenidKeyMapDict = dict()
        filePath =self.baseDir+'store/contracts/zerodha_contractfile'+str(datetime.now().strftime('%Y%m%d'))+'.csv'
        # print("gettokenidKeyContractFile ***************",filePath)
        df = pd.read_csv(filePath, usecols = ['instrument_token','exchange_token'])
        tokenidKeyMapDict = dict(zip(df.instrument_token,df.exchange_token))
     
        return tokenidKeyMapDict

    def writeAllResponseFromAPI(self):
        while self.flag>0:
            try:
                t=pd.DataFrame(self.tradelist)
                t.to_csv(f"""{os.getcwd()}/Logs/zerodha_tradelist_{str(datetime.now().strftime('%Y%m%d'))}.csv""")
                time.sleep(1)
            except Exception as e:
                print("Error on writeAllResponseFromAPI",e)

    def makeZerodhaConnection(self,apidetails):
        try:
            zerodha=KiteConnect(apidetails.get('api_key'))
            zerodha.set_access_token(apidetails.get('access_token'))
            return zerodha
        except Exception as e:
            print("error on makeZerodhaConnection",e)
            logging.warning(f"""{datetime.now()} {str(apidetails)} Error on makeZerodhaConnection!!!""")
            return None

    def zerodhaOMSQueueReader(self):
        print("Waiting for message Queue Reading ............")
        while self.flag > 0:
            data=dict()
            try:
                item = self.zerodhaOMS.receive()
                item = json.loads(item[0])
                data=item.get('data')
                self.tradelist.append(data)
                print(item)
                
                if item.get('data').get('buysell')==1:
                    item['data']['price']=int(item['data']['price'])+(int(item['data']['price'])*(self.percent/100))

                if item.get('data').get('buysell')==2:
                    item['data']['price']=int(item['data']['price'])-(int(item['data']['price'])*(self.percent/100))

                item['data']['price']=self.roundPrice(item['data']['price'])/100

                res=ZerodhaAPI.place_order(item,self.clientAPIInstence.get(item.get('data').get('clientid')))
                logging.warning(f"""{datetime.now()} {str(res)} call zerodhaOMSQueueReader!!!""")
                
            except Exception as e:
                print("[Error] in (self,zerodhaOMSQueueReader) msg: ", str(e))
                break

    def zerodhaAPIQueueReader(self):
        print("zerodhaAPIQueueReader")
       
        while self.flag > 0:
            data=dict()
            try:
                item = self.zerodhaAPI.receive()
                item = json.loads(item[0])
                print(item)
                data=item.get('data')
                if item.get('event')=='add' or item.get('event')=='update':
                    self.apis[data.get('clientid')]=data
                    self.clientAPIInstence[data.get('clientid')]=self.makeZerodhaConnection(data.get('api_config'))
                    self.clientOrderBookThreads[data.get('clientid')]=threading.Thread(target=self.getOrderBook,args=(self.clientAPIInstence[data.get('clientid')],data.get('clientid'))).start()
                elif  item.get('event')=='delete':
                    del self.apis[data.get('clientid')]
                    del self.clientAPIInstence[data.get('clientid')]
                    del self.clientOrderBookThreads[data.get('clientid')]

                print(self.apis)
                print(self.clientAPIInstence)
                logging.warning(f"""{datetime.now()} {str(item)} zerodhaAPIQueueReader!!!""")
                
            except Exception as e:
                print("[Error] in (self,zerodhaAPIQueueReader) msg: ", str(e))

    def getOrderBook(self,zerodha,clientid):
        tradecount=0
        while self.flag>0:
            try:
                orders=ZerodhaAPI.getOrders(zerodha)
                if orders:
                    if tradecount<len(orders):
                        for i in orders:
                            print(i)
                            unix_timestamp=int(i.get('order_timestamp').timestamp())
                            unix_timestamp=(unix_timestamp+19800)*1000

                            if i.get('status')=='COMPLETE':
                                trade={"TradedOrderNo":i.get('exchange_order_id'),
                                                    "TraderId":0,
                                                    "TransCode":20222,
                                                    "SuperAdm":0,
                                                    "Adm":0,
                                                    "Client":clientid,
                                                    "RealTrade":1,
                                                    "StrategyID":i.get('tag') if i.get('tag') else -1,
                                                    "UIDNum":0,
                                                    "Exchange":'NSE',
                                                    "Segment":'FO',
                                                    "ServerName":'AWS',
                                                    "TimeStampNs":unix_timestamp,
                                                    "BrokerId":0,
                                                    "AccountNo":i.get('placed_by'),
                                                    "BuySell":1 if i.get('transaction_type')=='BUY' else 2,
                                                    "OrigVol":i.get('quantity'),
                                                    "DiscVol":i.get('disclosed_quantity'),
                                                    "RemVol":i.get('pending_quantity'),
                                                    "RemDiscVol":i.get('pending_quantity'),
                                                    "Price":i.get('price')*100,
                                                    "GoodTillDate":0,
                                                    "FillNum":i.get('order_id'),
                                                    "FillQty":i.get('filled_quantity'),
                                                    "FillPrice":float(i.get('average_price'))*100,
                                                    "VolFilledToday":i.get('filled_quantity'),
                                                    "Logtime":0,
                                                    "Token":self.zerodhaToTokenMap.get(i.get('instrument_token')),
                                                    "PAN":'FWAPD2222E',
                                                    "NNFField":0,
                                                    "AlgoId":0,
                                                    "Algocategory":0,
                                                    "LAR":0,
                                                    "brokername":"zerodha" 

                                                    }
                                self.dbWriterQueueList.send(json.dumps({'write':'tradebook','data':trade}))

                            if i.get('status')=='CANCELLED':
                                # print(i)
                                trade={"TradedOrderNo":i.get('exchange_order_id'),
                                                    "TraderId":0,
                                                    "TransCode":20231,
                                                    "SuperAdm":0,
                                                    "Adm":0,
                                                    "Client":clientid,
                                                    "RealTrade":1,
                                                    "StrategyID":i.get('tag') if i.get('tag') else -1,
                                                    "UIDNum":0,
                                                    "Exchange":'NSE',
                                                    "Segment":'FO',
                                                    "ServerName":'AWS',
                                                    "TimeStampNs":unix_timestamp,
                                                    "BrokerId":0,
                                                    "AccountNo":i.get('placed_by'),
                                                    "BuySell": 1 if i.get('transaction_type')=='BUY' else 2,
                                                    "OrigVol":i.get('quantity'),
                                                    "DiscVol":i.get('disclosed_quantity'),
                                                    "RemVol":i.get('pending_quantity'),
                                                    "RemDiscVol":i.get('pending_quantity'),
                                                    "Price":i.get('price')*100,
                                                    "GoodTillDate":0,
                                                    "FillNum":i.get('order_id'),
                                                    "FillQty":i.get('filled_quantity'),
                                                    "FillPrice":float(i.get('average_price') if i.get('average_price')!="" else 0)*100,
                                                    "VolFilledToday":i.get('filled_quantity'),
                                                    "Logtime":0,
                                                    "Token":self.zerodhaToTokenMap.get(i.get('instrument_token')),
                                                    "PAN":'FWAPD2222E',
                                                    "NNFField":0,
                                                    "AlgoId":0,
                                                    "Algocategory":0,
                                                    "LAR":0,
                                                    "BookType":1 ,
                                                    "brokername":"zerodha" 
                                                    }
                                # print(trade)
                                self.dbWriterQueueList.send(json.dumps({'write':'ordererrorlogs','data':trade}))
                            
                            if i.get('status')=='OPEN':
                                # print(i)
                                trade={"TradedOrderNo":i.get('exchange_order_id'),
                                                    "TraderId":0,
                                                    "TransCode":20073,
                                                    "SuperAdm":0,
                                                    "Adm":0,
                                                    "Client":clientid,
                                                    "RealTrade":1,
                                                    "StrategyID":i.get('tag') if i.get('tag') else -1,
                                                    "UIDNum":0,
                                                    "Exchange":'NSE',
                                                    "Segment":'FO',
                                                    "ServerName":'AWS',
                                                    "TimeStampNs":unix_timestamp,
                                                    "BrokerId":0,
                                                    "AccountNo":i.get('placed_by'),
                                                    "BuySell":1 if i.get('transaction_type')=='BUY' else 2,
                                                    "OrigVol":i.get('quantity'),
                                                    "DiscVol":i.get('disclosed_quantity'),
                                                    "RemVol":i.get('pending_quantity'),
                                                    "RemDiscVol":i.get('pending_quantity'),
                                                    "Price":i.get('price')*100,
                                                    "GoodTillDate":0,
                                                    "FillNum":i.get('order_id'),
                                                    "FillQty":i.get('filled_quantity'),
                                                    "FillPrice":float(i.get('price'))*100,
                                                    "VolFilledToday":i.get('quantity'),
                                                    "Logtime":0,
                                                    "Token":self.zerodhaToTokenMap.get(i.get('instrument_token')),
                                                    "PAN":'FWAPD2222E',
                                                    "NNFField":0,
                                                    "AlgoId":0,
                                                    "Algocategory":0,
                                                    "LAR":0,
                                                    "BookType":1 ,
                                                    "brokername":"zerodha" 

                                                    }
                                # print(trade)
                                self.dbWriterQueueList.send(json.dumps({'write':'orderlogs','data':trade}))

                        print(f"""{len(orders)-tradecount} New Trade!!!!! Total Trades {len(orders)} {str(clientid)}""")
                        tradecount=len(orders)
                    else:
                        print("Trade Not Found!!!!!",clientid)
                else:
                    print("No Order Placed yet!!!!!",clientid)

            except Exception as e:
                print("Error on insertTradeBook",e,clientid)
            
            time.sleep(20)


ZerodhaOMS()