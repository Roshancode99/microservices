import pandas as pd
import datetime
import os

class TestAPI:
    @classmethod
    def place_order(cls, res, apiobj):
        try:
            if res.get('event') == 'create':
                res = res.get('data')
                if res.get('booktype') == 2:
                    response = apiobj.place_order(
                        variety=apiobj.VARIETY_REGULAR,
                        exchange=apiobj.EXCHANGE_NSE,
                        tradingsymbol=res.get('ticker_code'),
                        transaction_type=apiobj.TRANSACTION_TYPE_BUY if res.get('buysell') == 1 else apiobj.TRANSACTION_TYPE_SELL,
                        quantity=int(res.get('qty')),
                        product=apiobj.PRODUCT_CNC,
                        order_type=apiobj.ORDER_TYPE_MARKET
                    )
                    return response

                elif res.get('booktype') == 1:
                    print("Order limit")
                    response = apiobj.place_order(
                        variety=apiobj.VARIETY_REGULAR,
                        exchange=apiobj.EXCHANGE_NSE,
                        tradingsymbol=res.get('ticker_code'),
                        transaction_type=apiobj.TRANSACTION_TYPE_BUY if res.get('buysell') == 1 else apiobj.TRANSACTION_TYPE_SELL,
                        quantity=int(res.get('qty')),
                        price=float(res.get('price')),
                        product=apiobj.PRODUCT_CNC,
                        order_type=apiobj.ORDER_TYPE_LIMIT
                    )
                    return response

            elif res.get('event') == 'modify':
                res = res.get('data')
                response = apiobj.modify_order(
                    variety=apiobj.VARIETY_REGULAR,
                    order_id=res.get('order_id'),
                    quantity=int(res.get('qty')),
                    price=float(res.get('price')),
                )
                return response

            elif res.get('event') == 'cancel':
                res = res.get('data')
                response = apiobj.cancel_order(
                    variety=apiobj.VARIETY_REGULAR,
                    order_id=res.get('order_id'),
                )
                return response
        except Exception as e:
            print("Error on place_order:", e, res)
            return None
    
    @classmethod
    def get_orders(cls, apiobj):
        data = apiobj.orders()
        return data
    
    @classmethod
    def get_positions(cls, apiobj):
        data = apiobj.positions()
        data = data.get('net')
        data = pd.DataFrame(data)
        data['client'] = 1
        data['netpositionno'] = data['client'].astype(str) + data['instrument_token'].astype(str)
        data['date'] = datetime.datetime.now().strftime('%Y%m%d')
        print(data)
        data.to_csv('netposition.csv', index=False)
        return data
    
    @classmethod
    def get_holdings(cls, apiobj):
        data = apiobj.holdings()
        print(data)
    
    @classmethod
    def getTradeBook(self,orderno,apiobj):
        print("getTradeBook",apiobj,orderno)
        data=apiobj.order_trades(orderno)
        folder='tradebook'
        for i in data:
            i['client']=1
            query=f"""
            INSERT INTO public."TradeLogs"(uidnum, strategyid, strategy_name, servername, account_id, userid, token, product, trade_id, order_id, exchange, symbol, side, price, qty, exchange_order_id, fill_timestamp, order_timestamp, exchange_timestamp) VALUES ({0}, {0}, '{'0'}', '{'192.168.10.103'}', '{i.get('account_id')}', {0}, {i.get('instrument_token')}, '{i.get('product')}', {i.get('trade_id')}, {i.get('order_id')}, '{i.get('exchange')}', '{i.get('tradingsymbol')}', '{i.get('transaction_type')}', {i.get('average_price')}, {i.get('quantity')}, {i.get('exchange_order_id')}, '{i.get('fill_timestamp')}', '{i.get('order_timestamp')}', '{i.get('exchange_timestamp')}');
            """
            print(i.get('exchange_timestamp'))
            self._forExecuteQuery(query)
        path = f"""{self.baseDir}client/{str(i['client'])}"""
        try:
            os.makedirs(path+'/'+folder)
        except FileExistsError as e:
            pass
        filedirect = os.path.join(f"""{path}/{folder}/{folder}{str(i.get('exchange_timestamp')).split(' ')[0].replace('-','')}.csv""")
        data=pd.DataFrame(data)
        data.to_csv(filedirect)
        return data


TestAPI()
