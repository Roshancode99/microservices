import threading
from datetime import datetime
import json
import sysv_ipc
import pandas as pd
import sys

class TestOMS:
    def __init__(self):
        self.flag = 1  # Initialize flag
        setting_file = sys.argv[1] if len(sys.argv) > 1 else "settings.json"
        print("path here",setting_file)
        try:
            with open(setting_file, "r") as jsonfile:
                self.json_config_file = json.load(jsonfile)
        except FileNotFoundError:
            print("Setting file not found.")
            sys.exit(1)
        except json.JSONDecodeError:
            print("Invalid JSON format in the setting file.")
            sys.exit(1)

        # Commenting out MAC address and license expiry validation
        # if self.is_valid_mac() and self.is_valid_expiry():
        #     print("MAC address is valid. Running the code...")
        if True:
            print("Running the code...")
            self.run_code()

    def run_code(self):
        self.tradelist = []
        self.ordernumcount = 1
        print("TestOMS is started !!!!!")
        self.QKeys = self.json_config_file.get('queueKey')

        try:
            self.testOMS = sysv_ipc.MessageQueue(self.QKeys.get('testOMS'), sysv_ipc.IPC_CREX)
        except sysv_ipc.ExistentialError:
            self.testOMS = sysv_ipc.MessageQueue(self.QKeys.get('testOMS'))

        try:
            self.dbWriterQueueList = sysv_ipc.MessageQueue(self.QKeys.get('dbWriterQueue'), sysv_ipc.IPC_CREX)
        except sysv_ipc.ExistentialError:
            self.dbWriterQueueList = sysv_ipc.MessageQueue(self.QKeys.get('dbWriterQueue'))

        threading.Thread(target=self.testOMSQueueReader).start()

    def testOMSQueueReader(self):
        while self.flag > 0:
            print("wating for message reader ................ ")
            data = {}
            try:
                item = self.testOMS.receive()
                item = json.loads(item[0])
                data = item.get('data')

                print(self.ordernumcount, "TEST", data)
                unix_timestamp = int((datetime.now().timestamp() + 19800) * 1000)
                orderno = int(str(unix_timestamp) + str(self.ordernumcount))

                traderes = {'placed_by': 'TEST', 'order_id': str(orderno), 'exchange_order_id': str(orderno), 'parent_order_id': None, 
                            'status': 'COMPLETE', 'status_message': None, 'status_message_raw': None, 'order_timestamp': unix_timestamp,
                            'exchange_update_timestamp': str(datetime.now()), 'exchange_timestamp': datetime.now(), 'variety': 'regular',
                                'modified': True, 'exchange': data.get('exchange'), 'tradingsymbol': str(data.get('ticker_code')), 'instrument_token': data.get('token'), 
                                'order_type': 'LIMIT' if data.get('booktype')==1 else 'MARKET', 
                                'transaction_type': 'BUY' if data.get('buysell')==1 else 'SELL', 'validity': 'DAY', 'validity_ttl': 0, 'product': 'CNC', 
                                'quantity': data.get('qty'), 'disclosed_quantity': 0, 'price': data.get('price'), 'trigger_price': 0,
                                'average_price': data.get('price'), 'filled_quantity': data.get('qty'), 'pending_quantity': 0,
                                    'cancelled_quantity': 0, 'market_protection': 0, 'meta': {}, 'tag': None, 'guid': '57005X0Hymt0doERj3'}


                trade = {
                "TradedOrderNo":traderes.get('exchange_order_id'),
                "TraderId":0,
                "TransCode":20222,
                "SuperAdm":0,
                "Adm":0,
                "Client":data.get('clientid'),
                "RealTrade":0,
                "StrategyID":data.get('strategyid'),
                "UIDNum":0,
                "Exchange":traderes.get('exchange'),
                "Segment":data.get('segment'),
                "ServerName":'192.168.1.175',
                "TimeStampNs":traderes.get('order_timestamp'),
                "BrokerId":0,
                "AccountNo":traderes.get('placed_by'),
                "BuySell":data.get('buysell'),
                "OrigVol":traderes.get('quantity'),
                "DiscVol":traderes.get('disclosed_quantity'),
                "RemVol":traderes.get('pending_quantity'),
                "RemDiscVol":traderes.get('pending_quantity'),
                "Price":traderes.get('price'),
                "GoodTillDate":0,
                "FillNum":traderes.get('order_id'),
                "FillQty":traderes.get('filled_quantity'),
                "FillPrice":traderes.get('average_price'),
                "VolFilledToday":traderes.get('filled_quantity'),
                "Logtime":0,
                "Token":traderes.get('instrument_token'),
                "PAN":'FWAPD2222E',
                "NNFField":0,
                "AlgoId":0,
                "Algocategory":0,
                "LAR":0,
                "brokername":'test'
                }

                self.dbWriterQueueList.send(json.dumps({'write': 'tradebook', 'data': trade}))
                self.ordernumcount += 1
                print("No of Inserted Data  to db :-" ,self.ordernumcount)

            except Exception as e:
                print("[Error] in testOMSQueueReader:", str(e))
                self.tradelist.append(data)
                t = pd.DataFrame(self.tradelist)
                t.to_csv("testTradeList.csv")
                break

if __name__ == "__main__":
    TestOMS()

