import pandas as pd
import datetime
import numpy as np
import sys,os
import json
# import SharedArray as sa
import string
import shutil
from utility import concateDecToDec
import json
# import sharedMemory.settings
# concateDecToDec(11,15686)
# import contract
# import FreezeQuantity

settingFile = sys.argv[1]

try:
    with open(settingFile, "r") as jsonfile:
        jsonfile = json.load(jsonfile)
        settings = jsonfile.get("settings")
        contractSettings = jsonfile.get("contractSettings")
except Exception as e:
    print(e)

print(contractSettings)

# cmNSE = pd.read_csv("security.txt", sep="|", low_memory=False, usecols=[0, 1, 2, 7, 8, 11, 20, 21, 31, 53],

cmNSE = pd.read_csv("security.txt", sep="|", low_memory=False, usecols=[0, 1, 2, 7, 8, 11, 19, 20, 30, 53],
                                names=['token', 'ticker_code','security_type',
                                       'strike_price', 'option_type', 'permitted_to_trade', 'lot_size', 'tick_size',
                                       'expiry', 'contract_name'], skiprows=1)

# print(cmNSE)
# cmNSE['expiry'] = datetime.datetime.now().timestamp()
# cmNSE['expiry'] =cmNSE['expiry'].apply(lambda x: f"{datetime.datetime.fromtimestamp(x+315513000):%d%b%Y}")
cmNSE['expiry'] ='0'

cmNSE['strike_price'] =0
cmNSE['exchange'] ="NSE"
cmNSE['segment'] = "CM"
# cmNSEContractCategory =['EQ', 'MF']
cmNSEContractCategory =['EQ']
cmNSE['security_type'] = cmNSE['security_type'].astype(str)
#cmNSE['indexes'] =cmNSE['security_type']=='EQ'
#cmNSE = cmNSE[cmNSE['indexes'] == 1]
#del cmNSE['indexes']
cmNSE=cmNSE.loc[cmNSE['security_type']=='EQ']
# print(cmNSE)
# cmNSE['security_type']= cmNSE[cmNSE['security_type']=='EQ']
cmNSE['FNO'] ='A'
cmNSE['divider']=100

cmCustom=pd.read_csv('customCMContract.csv')
cmCustom['ticker_code']=cmCustom['ticker_code'].apply(lambda x: str(x).upper())
cmCustom['contract_name']=cmCustom['contract_name'].apply(lambda x: str(x).upper())
# cmNSE = cmNSE.concat(cmCustom, ignore_index = True)
cmNSE = pd.concat([cmCustom,cmNSE])

# cmNSE = cmNSE+cmCustom

# print(cmNSE)

cmNSE['tokenid'] = cmNSE['exchange']+ cmNSE['segment']+cmNSE['token'].astype(str)
cmNSE.loc[(cmNSE['exchange'] == 'NSE') & (cmNSE['segment'] == 'CM'), ['tokenid2']]  = str(contractSettings.get('NSE').get('ID'))+str(contractSettings.get('NSE').get('CM'))+cmNSE['token'].astype(str)


# print(cmNSE['security_type'].dtypes)
# cmNSE.to_csv("CMTICKER.csv")

foNSE =  pd.read_csv("contract.txt", sep="|", low_memory=False, usecols=[0, 2, 3,6, 7, 8, 11, 31, 32,  53],
                   names=['token', 'security_type', 'contract_name','expiry',
                          'strike_price', 'option_type', 'permitted_to_trade', 'lot_size', 'tick_size',
                           'ticker_code'], skiprows=1)


foNSE = foNSE[['token', 'security_type', 'ticker_code',
                          'strike_price', 'option_type', 'permitted_to_trade', 'lot_size', 'tick_size',
                          'expiry', 'contract_name']]
foNSE['expiry']=foNSE['expiry'].apply(lambda x: f"{datetime.datetime.fromtimestamp(x+315513000):%d%b%Y}")
foNSE['exchange'] ="NSE"
foNSE['segment'] = "FO"
foNSE['FNO'] ='NA'
foNSE['divider']=100

foNSE['tokenid'] = foNSE['exchange']+ foNSE['segment']+foNSE['token'].astype(str)
foNSE.loc[(foNSE['exchange'] == 'NSE') & (foNSE['segment'] == 'FO'), ['tokenid2']]  = str(contractSettings.get('NSE').get('ID'))+str(contractSettings.get('NSE').get('FO'))+foNSE['token'].astype(str)


cdNSE = pd.read_csv("cd_contract.txt", sep="|", low_memory=False, usecols=[0, 2, 3,6, 7, 8, 11, 31, 32, 53],
                   names=['token', 'security_type', 'contract_name',
                          'expiry','strike_price', 'option_type', 'permitted_to_trade', 'lot_size', 'tick_size',
                           'ticker_code'], skiprows=1)

cdNSE = cdNSE[['token', 'security_type', 'ticker_code',
                          'strike_price', 'option_type', 'permitted_to_trade', 'lot_size', 'tick_size',
                          'expiry', 'contract_name']]

cdNSE['expiry']=cdNSE['expiry'].apply(lambda x: f"{datetime.datetime.fromtimestamp(x+315513000):%d%b%Y}")
cdNSE['exchange'] ='NSE'
cdNSE['segment'] ='CD'
cdNSE['FNO'] ='NA'
cdNSE['divider']=10**7

cdNSE['tokenid'] = cdNSE['exchange']+ cdNSE['segment']+cdNSE['token'].astype(str)
cdNSE.loc[(cdNSE['exchange'] == 'NSE') & (cdNSE['segment'] == 'CD'), ['tokenid2']]  = str(contractSettings.get('NSE').get('ID'))+str(contractSettings.get('NSE').get('CD'))+cdNSE['token'].astype(str)

#cdNSE['strike_price'] = cdNSE['strike_price'] / 10000000

frames =[cmNSE,foNSE, cdNSE ]
result = pd.concat(frames,ignore_index=True)
result.sort_values(by =['ticker_code', 'security_type'], inplace=True, ascending=(False,True))

############################################  extra addition  ########################################
'''
result = result[result['segment'].isin(["FO","CM"])].reset_index()
result['expiryTempDate'] = [
    datetime.datetime(1980, 1, 1, tzinfo=datetime.timezone.utc) + datetime.timedelta(seconds=x) for x in
        result['expiry']]

result['wordExpiry'] = result["expiryTempDate"].dt.strftime("%-d%b")


result.wordExpiry = result['wordExpiry'].str.upper()
result['symbol'] = result['contract_name'].str.strip()
result['TradingSymbol'] = result['symbol']
print(result['security_type'])
result['TradingSymbol'] = np.where(result['option_type'] == 'XX',
                                                    result['symbol'] +result[
                                                        'wordExpiry'] + 'FUT',
                                                    result['TradingSymbol'])
result['strike_price'] = result['strike_price'] / 100

result['strikePrice']= np.where((result['strike_price']-result['strike_price'].astype('int'))==0,result['strike_price'].astype('int'),round(result['strike_price'].astype('float'),1) )
#foNSE['strikePrice'] = round(foNSE['strike_price'].astype('float'),1)
result['strikePrice'] = result['strikePrice'].astype('str')
#foNSE['strikePrice'] = foNSE['strikePrice'].str.replace('.0', ' ')


length, _ = result.shape

for i in range(0, length):
    temp=result._get_value(i,'strikePrice')
    x=temp[len(temp)-2:len(temp)]
    finalValue=temp
    #print("Starting Value ", finalValue)
    if x=='.0':
        finalValue=temp[0:len(temp)-2]
    #print("Final Value ", finalValue)
    result.at[i,'strikePrice']=finalValue
result['TradingSymbol'] =np.where((result['option_type'] == 'CE') | (result['option_type'] == 'PE'),result['symbol'] +result['wordExpiry'] +result['strikePrice']+ result['option_type'],result['TradingSymbol'])
'''
result['freezeQuantity'] = 0

# Read the Excel file directly with the absolute path
# freezeQuantityFile = pd.read_excel('/home/centos/pushpendra/sharedMemory/rmsdata/nseFreezeList.xls')
freezeQuantityFile = pd.read_excel('nseFreezeList.xls')

# Print the DataFrame to verify that the file was read successfully
print('Contents of the Excel file:', freezeQuantityFile)



freezeQuantityFile.rename(columns=lambda x: x.strip(), inplace=True)
row, _ = freezeQuantityFile.shape
freezeQuantityFile['SYMBOL']= freezeQuantityFile['SYMBOL'].str.strip()
print(freezeQuantityFile.columns)
for i in range(0, row):
    symbol = freezeQuantityFile._get_value(i, 'SYMBOL')
    freezeQuantity = int(freezeQuantityFile._get_value(i,'VOL_FRZ_QTY'))
    #print("Symbol :", symbol, len(symbol))
    #print("Freeze Quantity :", freezeQuantity, type(freezeQuantity))
    result["freezeQuantity"] = np.where(result["contract_name"]==symbol, freezeQuantity, result['freezeQuantity'])
  




try:
    del result['TradingSymbol']
except:
    pass
# print(result['freezeQuantity'][result['contract_name']=="BANKNIFTY"])

result['tokenid2']=result['tokenid2'].apply(lambda x: concateDecToDec(x))
result['multiplier']=1
result['currency']='INR'
result['tick_size']=result['tick_size']/result['divider']



baseDir=settings.get('baseDir')+'/'
# Delete Contract FOLDER
# try:
#     shutil.rmtree(baseDir+'contracts')
# except Exception as e:
#     pass

# Create Contract FOLDER
try:
    os.makedirs(baseDir+'contracts')
except Exception as e:
    pass

# this is for store contracts file in store folder
try:
    os.makedirs(baseDir+'store')
except Exception as e:
    pass

try:
    os.makedirs(baseDir+'/store/contracts')
except Exception as e:
    pass

# print(result.columns)
result.to_csv(baseDir+'store/contracts/nse_contractfile'+str(datetime.datetime.now().strftime('%Y%m%d'))+'.csv')
# /home/centos/pushpendra/rms-be/sharedMemory/store/contracts/

forJson=result.to_dict('records')
forJsonPath=baseDir+'/store/contracts/nse_contractfile'+str(datetime.datetime.now().strftime('%Y%m%d'))+'.json'

print("NSE Contract File Generated SuccessFully to store/contracts .......")

#   ----------------- final code end -----------------------#


if not os.path.exists(forJsonPath):
    with open(forJsonPath, "w") as file:
        json.dump({}, file)

with open(forJsonPath,"w") as file :
# with open(filedirect, "r+") as file:
    # temp = json.load(file)
    temp = {}
    for i in forJson:
        temp[i.get('tokenid2')] = i
        # print(temp)
    file.seek(0)
    json.dump(temp, file)

segmentList=result['segment'].drop_duplicates()
segmentList=segmentList.values

alphaLetter=list(string.ascii_uppercase)
for j in segmentList:
    try:
        shutil.rmtree(baseDir+'contracts/NSE'+j)
    except Exception as e:
        pass

    try:
        os.makedirs(baseDir+'contracts/NSE'+j)
    except FileNotFoundError as e:
        pass

    for i in alphaLetter:
        temp=result.loc[(result['ticker_code'].str.startswith(i,na=False)) & (result['segment']==j)]
        # print(temp)
        if temp.shape[0]>0:
            temp.to_csv(f"""{baseDir}contracts/NSE{j}/{i}.csv""")
            filename = os.path.join(f"""{baseDir}contracts/NSE{j}/{i}.json""")
            with open(filename,"w") as file :
                json.dump(temp.to_dict('records'),file) 

    print(f"""NSE Contract File Store as Separated to contract SHM as for AlphaLetter ......NSE {j}/{i}.csv""")

""" delete a instance """
del result,alphaLetter












