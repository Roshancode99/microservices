import psycopg2
import os
import json
import select

class Utilities():
    def __init__(self):
        self.contractSettings = {}
        with open("/home/centos/pushpendra/rms-be/sharedMemory/settings/generalSettings.json", "r") as jsonfile:
            jsonfile = json.load(jsonfile)
            settings = jsonfile.get("settings")
            self.contractSettings = jsonfile.get("contractSettings")
        
        # database connection
        # self.con = psycopg2.connect(host="52.66.127.232",port="5432",dbname="cosmicTest", user="postgres")
        self.con = psycopg2.connect(host="192.168.100.36",port="5432",dbname="cosmicTest", user="postgres")
        self.con.set_isolation_level(psycopg2.extensions.ISOLATION_LEVEL_AUTOCOMMIT)
        print("db connection done")
        # Start listening for notifications
        # self.dblisten()


    def concateDecToDec(self, a):
        exchange = int(str(a)[:2])
        token = int(str(a)[2:])
        hex_exchange = hex(exchange).replace("0x","")
        hex_token = hex(token).replace("0x","")
        decimalNo = hex_exchange+'0'*(8-(len(hex_token)))+hex_token
        return int(decimalNo,16)
    

    def dblisten(self):
        cur = self.con.cursor()
        print("Inside dblisten")
        cur.execute("LISTEN process")
        while True:
            print("Listening for notifications")
            select.select([self.con], [], [])
            self.con.poll()
            while self.con.notifies:
                notify = self.con.notifies.pop(0)
                print("Got NOTIFY:", notify.pid, notify.channel, notify.payload)
