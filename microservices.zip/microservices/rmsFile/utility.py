def concateDecToDec(a):
    exchange = int(str(a)[:2])
    token = int(str(a)[2:])
    hex_exchange = hex(exchange).replace("0x","")
    hex_token = hex(token).replace("0x","")
    decimalNo = hex_exchange+'0'*(8-(len(hex_token)))+hex_token
    return int(decimalNo,16)