# import pandas as pd
# import requests 


# url = 'https://archives.nseindia.com/content/fo/qtyfreeze.xls'
# r = requests.get(url, allow_redirects=True)
# print(r.content)
# open('nseFreezeList.xls', 'wb').write(r.content)
# data = pd.read_excel('nseFreezeList.xls')
# print(data.head(10))
# print(data.dtypes)


import pandas as pd
import requests
import os

# Define the URL to download the Excel file
url = 'https://archives.nseindia.com/content/fo/qtyfreeze.xls'

# Send a GET request to the URL and download the content
response = requests.get(url)
if response.status_code == 200:
    # Specify the directory where you want to save the file
    save_directory = "/home/centos/pushpendra/rms-be/sharedMemory/rmsdata/"

    data_directory = "/home/centos/pushpendra/rms-be/microservices/rmsFile/"


    # Ensure that the directory exists, create it if not
    if not os.path.exists(save_directory):
        os.makedirs(save_directory)

    # Save the downloaded file to the specified directory
    file_path = os.path.join(save_directory, 'nseFreezeList.xls')
    with open(file_path, 'wb') as file:
        file.write(response.content)

    # Read the Excel file using pandas
    data = pd.read_excel(file_path)
    # Save the downloaded file to the specified directory
    file_path = os.path.join(data_directory, 'nseFreezeList.xls')
    with open(file_path, 'wb') as file:
        file.write(response.content)

    # Read the Excel file using pandas
    data = pd.read_excel(file_path)

    # Display the first 10 rows of the DataFrame
    print(data.head(10))

    # Print the data types of columns in the DataFrame
    print(data.dtypes)
else:
    print("Failed to download the file.")
