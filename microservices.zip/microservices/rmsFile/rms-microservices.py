# Specify the directory where you want to save the file
# directory = '/home/centos/pushpendra/rms-be/sharedMemory/'

import os
from utilities import Utilities
import pandas as pd
import numpy as np
import datetime

class RMS(Utilities):
    def __init__(self):
        super().__init__()

        self.cursor = self.con.cursor()
        self.contract_final = []
        self.db_data = []
        self.sharedMemoryPath = "/home/centos/pushpendra/rms-be/sharedMemory/rmsdata/"

        self.get_data()
        
    def get_data(self):
        # Fetch data from database
        self.cursor.execute("SELECT * FROM trade")
        columns = [col[0] for col in self.cursor.description]
        data = [dict(zip(columns, row)) for row in self.cursor.fetchall()]
        self.db_data = pd.DataFrame(data)

        # Read contract data
        contract_data = pd.read_csv(self.sharedMemoryPath + "contract.txt", sep="|", low_memory=False, usecols=[0, 2, 3,6, 7, 8, 11, 31, 32, 53],
                   names=['token', 'security_type', 'contract_name',
                          'expiry','strike_price', 'option_type', 'permitted_to_trade', 'lot_size', 'tick_size',
                           'ticker_code'], skiprows=1)
        contract_data = contract_data[['token', 'security_type', 'ticker_code',
                          'strike_price', 'option_type', 'permitted_to_trade', 'lot_size', 'tick_size',
                          'expiry', 'contract_name']]
        print(contract_data)

        # Format contract data
        contract_data['expiry']=contract_data['expiry'].apply(lambda x: f"{datetime.datetime.fromtimestamp(x+315513000):%d%b%Y}")
        contract_data['exchange'] ='NSE'
        contract_data['segment'] ='CD'
        contract_data['FNO'] ='NA'
        contract_data['divider']=10**7

        contract_data['tokenID'] = contract_data['exchange']+ contract_data['segment']+contract_data['token'].astype(str)
        contract_data.loc[(contract_data['exchange'] == 'NSE') & (contract_data['segment'] == 'CD'), ['tokenID2']]  = str(self.contractSettings.get('NSE').get('ID'))+str(self.contractSettings.get('NSE').get('CD'))+contract_data['token'].astype(str)

        # contract_data.sort_values(by =['ticker_code', 'security_type'], inplace=True, ascending=(False,True))

        # Read freeze quantity file
        freezeQuantityFile = pd.read_excel(self.sharedMemoryPath + 'nseFreezeList.xls')
        freezeQuantityFile.rename(columns=lambda x: x.strip(), inplace=True)
        row, _ = freezeQuantityFile.shape
        freezeQuantityFile['SYMBOL']= freezeQuantityFile['SYMBOL'].str.strip()
        contract_data["freezeQuantity"] = 0
        for i in range(0, row):
            symbol = freezeQuantityFile._get_value(i, 'SYMBOL')
            freezeQuantity = int(freezeQuantityFile._get_value(i,'VOL_FRZ_QTY'))
            contract_data["freezeQuantity"] = np.where(contract_data["contract_name"]==symbol, freezeQuantity, contract_data['freezeQuantity'])

        try:
            del contract_data['TradingSymbol']
        except:
            pass

        contract_data['tokenID2']=contract_data['tokenID2'].apply(lambda x: self.concateDecToDec(x))
        contract_data['multiplier']=1
        contract_data['currency']='INR'
        contract_data['tick_size']=contract_data['tick_size']/contract_data['divider']

        # Save contract and db data to CSV
        self.contract_final = contract_data
        # print("before final csv ", self.contract_data)
        self.contract_final.to_csv(os.path.join(self.sharedMemoryPath, "contract_final.csv"),index=False)
        # print("after final csv ",self.contract_final)
        self.db_data.to_csv(os.path.join(self.sharedMemoryPath, "db_data.csv"),index=False)
        # print("db data before merge ",self.db_data)

        self.save_merge_data()
        # print("after save data ",self.save_merge_data)
        print("Saved data in shared memory")

    def save_merge_data(self):
        merged_data = pd.merge(self.db_data, self.contract_final, how="left", left_on="Token", right_on='token')
        merged_data.drop(columns="Token", inplace=True)

        # Calculate total quantity price and store it in a new column
        # merged_data['total QntyPrice'] = merged_data['FillQty'] * merged_data['FillPrice']
        
        # Calculate totalBuyQnty and totalSellQnty
        merged_data['totalBuyQnty'] = merged_data['FillQty'].where(merged_data['BuySell'] == 1, 0)
        merged_data['totalSellQnty'] = merged_data['FillQty'].where(merged_data['BuySell'] == 2, 0)

        # Calculate BuyPrice and SellPrice
        merged_data['BuyPrice'] = merged_data['FillPrice'].where(merged_data['BuySell'] == 1, 0)
        merged_data['SellPrice'] = merged_data['FillPrice'].where(merged_data['BuySell'] == 2, 0)

        # Calculate BuyValue and SellValue
        merged_data['BuyValue'] = merged_data['totalBuyQnty'] * merged_data['BuyPrice']
        merged_data['SellValue'] = merged_data['totalSellQnty'] * merged_data['SellPrice']

        # Calculate PNL
        merged_data['PNL'] = merged_data['BuyValue'] - merged_data['SellValue']

        merged_data['NetQnty'] = merged_data['totalBuyQnty'] - merged_data['totalSellQnty']
    
        '''
        Below is Saved the data as Group by TraderID and save data for each TraderID in a separate CSV 
        file. Ensure that this      
        function reuses existing files. If data is already stored in files, subsequent runs of the code 
        should continue storing data into the same file based on TraderID. Additional files are 
        unnecessary; however, if needed, I can save multiple files based on TraderID and DateTime, but 
        for now, let's ignore this option.
        
        '''

        for trader_id, group_data in merged_data.groupby('TraderId'):
            trader_dir = os.path.join(self.sharedMemoryPath, "store")
            if not os.path.exists(trader_dir):
                os.makedirs(trader_dir)
            
            trader_file_path = os.path.join(trader_dir, f"{trader_id}_data.csv")
            
            # Check if file exists, if yes, delete it
            if os.path.exists(trader_file_path):
                os.remove(trader_file_path)
            
            # Save data to CSV file
            group_data.to_csv(trader_file_path, index=False)
            print(f"Saved data for TraderID {trader_id} in {trader_file_path}")


RMS()

#Sai or Roshan, you can implement the data store as a separate entity within the shared memory in the 'store' directory.
