from utilities import Utilities
import datetime
import pandas as pd
import sys
import os
import time,json
import logging
import sysv_ipc
import threading


logging.basicConfig(filename=f"""Logs/SUPER_LOG_FILE_{str(datetime.datetime.now().strftime('%Y%m%d'))}.log""", filemode='a',format='%(asctime)s - %(levelname)s - %(message)s')
class SuperTrendClass(Utilities):
    def __init__(self):
        super().__init__()
        self.flag=1
        self.stvalue=0
        self.tokenid2list=[]
        self.tokenlist=[]
        self.tickerlist=[]

        try:
            self.zerodhaOMS = sysv_ipc.MessageQueue(self.QKeys.get('zerodhaOMS'),sysv_ipc.IPC_CREX)
        except Exception as e: 
            self.zerodhaOMS = sysv_ipc.MessageQueue(self.QKeys.get('zerodhaOMS'))

        try:
            self.testOMS = sysv_ipc.MessageQueue(self.QKeys.get('testOMS'),sysv_ipc.IPC_CREX)
        except Exception as e: 
            self.testOMS = sysv_ipc.MessageQueue(self.QKeys.get('testOMS'))

        try:
            self.xtsOMS = sysv_ipc.MessageQueue(self.QKeys.get('xtsOMS'),sysv_ipc.IPC_CREX)
        except Exception as e: 
            self.xtsOMS = sysv_ipc.MessageQueue(self.QKeys.get('xtsOMS'))

        try:
            self.strategyQueue = sysv_ipc.MessageQueue(self.QKeys.get('strategySuperTrendQueue'),sysv_ipc.IPC_CREX)
        except Exception as e: 
            self.strategyQueue = sysv_ipc.MessageQueue(self.QKeys.get('strategySuperTrendQueue'))

            

        self.ordersList={}

        # if not os.path.exists(f"""Logs/LOG_FILE_{str(datetime.now().strftime('%Y%m%d'))}.log"""):
        logging.basicConfig(filename=f"""Logs/SUPER_LOG_FILE_{str(datetime.datetime.now().strftime('%Y%m%d'))}.log""", filemode='a',format='%(asctime)s - %(levelname)s - %(message)s')

        contractfilePath=self.baseDir+'store/contracts/zerodha_contractfile'+str(datetime.datetime.now().strftime('%Y%m%d'))+'.csv'
        self.contracts=pd.read_csv(contractfilePath)

        self.clientDetails={}
        self.sellflag=0
        self.res=self.read_ticker(176093919241)
        self.runcount = 0
        self.supertrend_period = 10
        self.supertrend_multiplier=5
        self.candlesize = '3minute'
        self.start_time = int(9) * 60 + int(18)  # specify in int (hr) and int (min) foramte
        self.end_time = int(15) * 60 + int(29)  # do not place fresh order
        self.stop_time = int(15) * 60 + int(29)  # square off all open positions
        self.last_time = self.start_time
        self.schedule_interval = 180  # run at every 3 min

        # self.gethistoricaldata([9929218,9929474])
        threading.Thread(target=self.strategyQueueReader).start()
        threading.Thread(target=self.run).start()
        # threading.Thread(target=self.run_AutoClosePosition).start()


    def getStrikePrice(self,ltp):
        strike1=0
        try:
            print("**********",ltp)
            c=ltp%10000
            # print(c)
            d=10000-c
            # print(d)

            if d<5000:
                strike1=ltp+d
            else:
                strike1=ltp-c

            print("strike_price===",int(strike1))
            return strike1

        except Exception as e:
            print("error on getStrikePrice")
            return strike1

    def ATR(self,df, period, ohlc=['open', 'high', 'low', 'close']):
        print("call ATR")
        """
        Function to compute Average True Range (ATR)

        Args :
            df : Pandas DataFrame which contains ['date', 'open', 'high', 'low', 'close', 'volume'] columns
            period : Integer indicates the period of computation in terms of number of candles
            ohlc: List defining OHLC Column names (default ['Open', 'High', 'Low', 'Close'])

        Returns :
            df : Pandas DataFrame with new columns added for
                True Range (TR)
                ATR (ATR_$period)
        """
        atr = 'ATR_' + str(period)

        # Compute true range only if it is not computed and stored earlier in the df
        if not 'TR' in df.columns:
            df['h-l'] = df[ohlc[3]] - df[ohlc[3]]
            df['h-yc'] = abs(df[ohlc[3]] - df[ohlc[3]].shift())
            df['l-yc'] = abs(df[ohlc[3]] - df[ohlc[3]].shift())

            df['TR'] = df[['h-l', 'h-yc', 'l-yc']].max(axis=1)

            # df.drop(['h-l', 'h-yc', 'l-yc'], inplace=True, axis=1)
        
        # print(df)
        # print(atr)
        # Compute EMA of true range using ATR formula after ignoring first row

        # self.EMA(df, 'TR', atr, period, alpha=True)
        df[atr]=df['TR'].rolling(period).sum()/period
        df.fillna(0, inplace=True)
        # print(df.head(16))
        return df

    def SuperTrend(self,df, period , multiplier, ohlc=['open', 'high', 'low', 'close']):

        print("call SuperTrend")
        """
        Function to compute SuperTrend

        Args :
            df : Pandas DataFrame which contains ['date', 'open', 'high', 'low', 'close', 'volume'] columns
            period : Integer indicates the period of computation in terms of number of candles
            multiplier : Integer indicates value to multiply the ATR
            ohlc: List defining OHLC Column names (default ['Open', 'High', 'Low', 'Close'])

        Returns :
            df : Pandas DataFrame with new columns added for
                True Range (TR), ATR (ATR_$period)
                SuperTrend (ST_$period_$multiplier)
                SuperTrend Direction (STX_$period_$multiplier)
        """

        self.ATR(df, period, ohlc=ohlc)
        atr = 'ATR_' + str(period)
        st = 'ST' #+ str(period) + '_' + str(multiplier)
        stx = 'STX' #  + str(period) + '_' + str(multiplier)

        """
        SuperTrend Algorithm :

            BASIC UPPERBAND = (HIGH + LOW) / 2 + Multiplier * ATR
            BASIC LOWERBAND = (HIGH + LOW) / 2 - Multiplier * ATR

            FINAL UPPERBAND = IF( (Current BASICUPPERBAND < Previous FINAL UPPERBAND) or (Previous Close > Previous FINAL UPPERBAND))
                                THEN (Current BASIC UPPERBAND) ELSE Previous FINALUPPERBAND)
            FINAL LOWERBAND = IF( (Current BASIC LOWERBAND > Previous FINAL LOWERBAND) or (Previous Close < Previous FINAL LOWERBAND)) 
                                THEN (Current BASIC LOWERBAND) ELSE Previous FINAL LOWERBAND)

            SUPERTREND = IF((Previous SUPERTREND = Previous FINAL UPPERBAND) and (Current Close <= Current FINAL UPPERBAND)) THEN
                            Current FINAL UPPERBAND
                        ELSE
                            IF((Previous SUPERTREND = Previous FINAL UPPERBAND) and (Current Close > Current FINAL UPPERBAND)) THEN
                                Current FINAL LOWERBAND
                            ELSE
                                IF((Previous SUPERTREND = Previous FINAL LOWERBAND) and (Current Close >= Current FINAL LOWERBAND)) THEN
                                    Current FINAL LOWERBAND
                                ELSE
                                    IF((Previous SUPERTREND = Previous FINAL LOWERBAND) and (Current Close < Current FINAL LOWERBAND)) THEN
                                        Current FINAL UPPERBAND
        """

        # Compute basic upper and lower bands
        df['basic_ub'] = ((df[ohlc[3]] + df[ohlc[3]]) / 2) + (multiplier * df[atr])
        df['basic_lb'] = ((df[ohlc[3]] + df[ohlc[3]]) / 2) - (multiplier * df[atr])

        df.loc[df[atr]==0,'basic_ub']=0
        df.loc[df[atr]==0,'basic_lb']=0

        # Compute final upper and lower bands
        df['final_ub'] = 0.00
        df['final_lb'] = 0.00
        for i in range(period, len(df)):
            df['final_ub'].iat[i] = df['basic_ub'].iat[i] if df['basic_ub'].iat[i] < df['final_ub'].iat[i - 1] or \
                                                            df[ohlc[3]].iat[i - 1] > df['final_ub'].iat[i - 1] else \
            df['final_ub'].iat[i - 1]
            df['final_lb'].iat[i] = df['basic_lb'].iat[i] if df['basic_lb'].iat[i] > df['final_lb'].iat[i - 1] or \
                                                            df[ohlc[3]].iat[i - 1] < df['final_lb'].iat[i - 1] else \
            df['final_lb'].iat[i - 1]

        # Set the Supertrend value
        df[st] = 0.00
        for i in range(period, len(df)):
            df[st].iat[i] = df['final_ub'].iat[i] if df[st].iat[i - 1] == df['final_ub'].iat[i - 1] and df[ohlc[3]].iat[
                i] <= df['final_ub'].iat[i] else \
                df['final_lb'].iat[i] if df[st].iat[i - 1] == df['final_ub'].iat[i - 1] and df[ohlc[3]].iat[i] > \
                                        df['final_ub'].iat[i] else \
                    df['final_lb'].iat[i] if df[st].iat[i - 1] == df['final_lb'].iat[i - 1] and df[ohlc[3]].iat[i] >= \
                                            df['final_lb'].iat[i] else \
                        df['final_ub'].iat[i] if df[st].iat[i - 1] == df['final_lb'].iat[i - 1] and df[ohlc[3]].iat[i] < \
                                                df['final_lb'].iat[i] else 0.00

            # Mark the trend direction up/down
        # print(df[st])
        # print(df[ohlc[3]])
        # print(np.where((df[ohlc[3]] < df[st]), 'down', 'up'))
        # df[stx] = np.where((df[st] > 0.00), np.where((df[ohlc[3]] < df[st]), 'down', 'up'), np.NaN)
        # print(df.tail(1))

        # Remove basic and final bands from the columns
        # df.drop(['basic_ub', 'basic_lb', 'final_ub', 'final_lb'], inplace=True, axis=1)

        df.fillna(0, inplace=True)
        df.to_csv(f"""Logs/SUPER_LOG_FILE_{str(datetime.datetime.now().strftime('%Y%m%d'))}.csv""")
        # print("csv generatedd!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
        return df

    def gethistoricaldata(self,token):
        print("call gethistoricaldata")

        enddate = datetime.datetime.today()
        startdate = enddate - datetime.timedelta(10)
        df = pd.DataFrame(columns=['date', 'open', 'high', 'low', 'close', 'volume'])
        try:
            data1 = self.kite.historical_data(token[0], startdate, enddate, interval=self.candlesize)
            df1 = pd.DataFrame.from_dict(data1, orient='columns', dtype=None)

            data2 = self.kite.historical_data(token[1], startdate, enddate, interval=self.candlesize)
            df2 = pd.DataFrame.from_dict(data2, orient='columns', dtype=None)
            df= pd.merge(df1, df2,  how='left', left_on=['date'], right_on = ['date'])
            df['open']=df['open_x']+df['open_y']
            df['high']=df['high_x']+df['high_y']
            df['low']=df['low_x']+df['low_y']
            df['close']=df['close_x']+df['close_y']
            df['volume']=df['volume_x']+df['volume_y']
            df.drop(['open_x', 'high_x', 'low_x', 'close_x', 'volume_x','open_y', 'high_y', 'low_y', 'close_y', 'volume_y'],axis=1,inplace=True)
            if not df.empty:
                df = df[['date', 'open', 'high', 'low', 'close', 'volume']]
                df['date'] = df['date'].astype(str).str[:-6]
                df['date'] = pd.to_datetime(df['date'])
                df = self.SuperTrend(df,period = self.supertrend_period, multiplier=self.supertrend_multiplier)
                # print(df)
        except Exception as e:
            print("Error in gethistoricaldata", token, e)
        df.to_csv("Logs/SUPER_CSV_FILE_"+str(token[0])+" "+str(token[1])+".csv")
        return df

    def run_trategy(self):

        if self.sellflag==0:
            self.res=self.read_ticker(176093919241)

        ltp=self.res.get('ltp')
        strikeprice=self.getStrikePrice(ltp)
        temp=self.contracts.loc[(self.contracts['exchange']=='NFO') & (self.contracts['segment']=='NFO-OPT') & (self.contracts['contract_name']=='BANKNIFTY') & (self.contracts['strike_price']==strikeprice) & (self.contracts['expiry']=='25May2023')]
        # temp=self.contracts.loc[(self.contracts['exchange']=='NFO') & (self.contracts['segment']=='NFO-OPT') & (self.contracts['contract_name']=='BANKNIFTY') & (self.contracts['strike_price']==strikeprice) & (self.contracts['expiry']==j.get('expiry'))  ]
        if temp.shape[0]==2:
            self.tickerlist=temp['ticker_code'].values
            self.tokenlist=temp['token'].values
            self.tokenid2list=temp['tokenid2'].values
            print("ticker list",self.tickerlist,self.tokenlist)
            histdata = self.gethistoricaldata(self.tokenlist)
            self.stvalue = histdata.ST.values[-1]
            # print(histdata.tail(1))
            bid1=int(self.read_ticker(self.tokenid2list[0]).get('bid0'))/100
            bid2=int(self.read_ticker(self.tokenid2list[1]).get('bid0'))/100
            ask1=int(self.read_ticker(self.tokenid2list[0]).get('ask0'))/100
            ask2=int(self.read_ticker(self.tokenid2list[1]).get('ask0'))/100
            print(self.stvalue,"current price ",bid1,bid2,"sum",bid1+bid2 , self.sellflag)

            if self.stvalue!=0:
                if self.sellflag==0 and self.stvalue>(bid1+bid2):#sell condition
                    print("checking for sell")
                    for j in list(self.clientDetails.values()):
                        if j.get('status'):
                            print(j)
                            msg=f"""Trigger Time {datetime.datetime.now()} | broker name {j.get('apiplatform')} |strategyid {j.get('strategyid')} | Client {j.get('client')} | Expiry {j.get('expiry')} | Qty {j.get('qty')} |ST value {self.stvalue} | NIFTYBANK LTP {ltp/100} | Taking SELL Position In {self.tokenlist[0]} {self.tickerlist[0]} @LTP {bid1} |"""
                            msg2=f"""Trigger Time {datetime.datetime.now()} | broker name {j.get('apiplatform')} |strategyid {j.get('strategyid')} | Client {j.get('client')} | Expiry {j.get('expiry')} | Qty {j.get('qty')} |ST value {self.stvalue} | NIFTYBANK LTP {ltp/100} | Taking SELL Position In {self.tokenlist[1]} {self.tickerlist[1]} @LTP {bid2} |"""
                            if j.get('apiplatform')=='zerodha':
                                self.zerodhaOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(bid1*100),'buysell':2,'booktype':1,'triggerprice':0,'token':int(self.tokenlist[0]),'ticker_code':self.tickerlist[0],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                                self.zerodhaOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(bid2*100),'buysell':2,'booktype':1,'triggerprice':0,'token':int(self.tokenlist[1]),'ticker_code':self.tickerlist[1],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                            if j.get('apiplatform')=='test':
                                self.testOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(bid1*100),'buysell':2,'booktype':1,'triggerprice':0,'token':int(self.tokenlist[0]),'ticker_code':self.tickerlist[0],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                                self.testOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(bid2*100),'buysell':2,'booktype':1,'triggerprice':0,'token':int(self.tokenlist[1]),'ticker_code':self.tickerlist[1],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                            if j.get('apiplatform')=='xts':
                                self.xtsOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(bid1*100),'buysell':2,'booktype':1,'triggerprice':0,'token':int(self.tokenlist[0]),'ticker_code':self.tickerlist[0],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                                self.xtsOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(bid2*100),'buysell':2,'booktype':1,'triggerprice':0,'token':int(self.tokenlist[1]),'ticker_code':self.tickerlist[1],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                            
                            logging.warning(msg)
                            logging.warning(msg2)
                        self.sellflag=1

                elif self.sellflag==1 and self.stvalue<(ask1+ask2):#Buy condition
                    print("checking for buy")
                    for j in list(self.clientDetails.values()):
                        if j.get('status'):
                            print(j)
                            msg=f"""Trigger Time {datetime.datetime.now()} |strategyid {j.get('strategyid')} | Client {j.get('client')} | Expiry {j.get('expiry')} | Qty {j.get('qty')} |ST value {self.stvalue} | NIFTYBANK LTP {ltp/100} | Taking BUY Position In {self.tokenlist[0]} {self.tickerlist[0]} @LTP {ask1} |"""
                            msg2=f"""Trigger Time {datetime.datetime.now()} |strategyid {j.get('strategyid')} | Client {j.get('client')} | Expiry {j.get('expiry')} | Qty {j.get('qty')} |ST value {self.stvalue} | NIFTYBANK LTP {ltp/100} | Taking BUY Position In {self.tokenlist[1]} {self.tickerlist[1]} @LTP {ask2} |"""
                            if j.get('apiplatform')=='zerodha':
                                self.zerodhaOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(ask1*100),'buysell':1,'booktype':1,'triggerprice':0,'token':int(self.tokenlist[0]),'ticker_code':self.tickerlist[0],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                                self.zerodhaOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(ask2*100),'buysell':1,'booktype':1,'triggerprice':0,'token':int(self.tokenlist[1]),'ticker_code':self.tickerlist[1],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                            if j.get('apiplatform')=='test':
                                self.testOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(ask1*100),'buysell':1,'booktype':1,'triggerprice':0,'token':int(self.tokenlist[0]),'ticker_code':self.tickerlist[0],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                                self.testOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(ask2*100),'buysell':1,'booktype':1,'triggerprice':0,'token':int(self.tokenlist[1]),'ticker_code':self.tickerlist[1],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                            if j.get('apiplatform')=='xts':
                                self.xtsOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(ask1*100),'buysell':1,'booktype':1,'triggerprice':0,'token':int(self.tokenlist[0]),'ticker_code':self.tickerlist[0],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                                self.xtsOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(ask2*100),'buysell':1,'booktype':1,'triggerprice':0,'token':int(self.tokenlist[1]),'ticker_code':self.tickerlist[1],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                            
                            logging.warning(msg)
                            logging.warning(msg2)
                        self.sellflag=0
            else:
                print(histdata)
                print('ST value is',self.stvalue)
                    
    def strategyQueueReader(self):
        while self.flag > 0:
            print("Waiting for Message Queuee..............")
            try:
                item = self.strategyQueue.receive()
                print(item)
                item = json.loads(item[0])
                if item.get('event')=='add':
                    item=item.get('data')
                    self.clientDetails[item['strategyid']]=item
                    print("add strategyQueueReader... ",item)
                
                if item.get('event')=='delete':
                    item=item.get('data')
                    self.clientDetails.pop(item['strategyid'],None)
                    print(self.clientDetails)
                    print("delete strategyQueueReader... ",item['strategyid'],item['clientid'])

                if item.get('event')=='start' or item.get('event')=='stop':
                    item=item.get('data')
                    print(item)
                    if self.clientDetails.get(item['strategyid']):
                        self.clientDetails[item['strategyid']]['status']=item.get('status')
                        self.clientDetails[item['strategyid']]['real']=item.get('real')
                    else:
                        print("append***-")
                        self.clientDetails[item['strategyid']]=item

                    print(self.clientDetails)
                    print("start or stop strategyQueueReader... ",item['strategyid'],item['clientid'])

               
                if item.get('event')=='update':
                    item=item.get('data')
                    print(item)
                    if self.clientDetails.get(item['strategyid']):
                        self.clientDetails[item['strategyid']]['qty']=item.get('qty')
                    print(self.clientDetails)
                    print("update strategyQueueReader... ",item['strategyid'],item['clientid'])

            except Exception as e:
                # print(traceback.format_exc())
                print("[Error] in (self,strategyQueueReader) msg: ", str(e))


    def run(self):
        
        #runcount = 0
        while self.flag>0:
            if (datetime.datetime.now().hour * 60 + datetime.datetime.now().minute) >= self.end_time:
                if (datetime.datetime.now().hour * 60 + datetime.datetime.now().minute) >= self.stop_time:
                    print("Auto close @ ",datetime.datetime.now())
                    if len(self.tokenid2list)>0:
                        ltp=self.res.get('ltp')
                        ask1=int(self.read_ticker(self.tokenid2list[0]).get('ask0'))/100
                        ask2=int(self.read_ticker(self.tokenid2list[1]).get('ask0'))/100
                        if self.sellflag==1:
                            for j in list(self.clientDetails.values()):
                                if j.get('status'):
                                    print(j)
                                    msg=f"""Trigger Time {datetime.datetime.now()} Auto Close | broker name {j.get('apiplatform')} |strategyid {j.get('strategyid')} | Client {j.get('client')} | Expiry {j.get('expiry')} | Qty {j.get('qty')} | NIFTYBANK LTP {ltp/100} | Taking BUY Position In {self.tokenlist[0]} {self.tickerlist[0]} @LTP {ask1} |"""
                                    msg2=f"""Trigger Time {datetime.datetime.now()} Auto Close | broker name {j.get('apiplatform')} |strategyid {j.get('strategyid')} | Client {j.get('client')} | Expiry {j.get('expiry')} | Qty {j.get('qty')} | NIFTYBANK LTP {ltp/100} | Taking BUY Position In {self.tokenlist[1]} {self.tickerlist[1]} @LTP {ask2} |"""
                                    if j.get('apiplatform')=='zerodha':
                                        self.zerodhaOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(ask1*100),'buysell':1,'booktype':1,'triggerprice':0,'token':int(self.tokenlist[0]),'ticker_code':self.tickerlist[0],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                                        self.zerodhaOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(ask2*100),'buysell':1,'booktype':1,'triggerprice':0,'token':int(self.tokenlist[1]),'ticker_code':self.tickerlist[1],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                                    if j.get('apiplatform')=='test':
                                        self.testOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(ask1*100),'buysell':1,'booktype':1,'triggerprice':0,'token':int(self.tokenlist[0]),'ticker_code':self.tickerlist[0],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                                        self.testOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(ask2*100),'buysell':1,'booktype':1,'triggerprice':0,'token':int(self.tokenlist[1]),'ticker_code':self.tickerlist[1],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                                    if j.get('apiplatform')=='xts':
                                        self.xtsOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(ask1*100),'buysell':1,'booktype':1,'triggerprice':0,'token':int(self.tokenlist[0]),'ticker_code':self.tickerlist[0],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                                        self.xtsOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(ask2*100),'buysell':1,'booktype':1,'triggerprice':0,'token':int(self.tokenlist[1]),'ticker_code':self.tickerlist[1],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                                    
                                    logging.warning(msg)
                                    logging.warning(msg2)

                    print(sys._getframe().f_lineno, "Trading day closed, time is above stop_time")
                    break

            if (datetime.datetime.now().hour * 60 + datetime.datetime.now().minute) >= self.start_time:
                if time.time() >= self.last_time:
                    self.last_time = time.time() + self.schedule_interval
                    print("\n\n {} Run Count : Time - {} ".format(self.runcount, datetime.datetime.now()))
                    if self.runcount >= 0:
                        try:
                            self.run_trategy()
                        except Exception as e:
                            print("Run error", e)
                    self.runcount = self.runcount + 1
            # else:
            #     print('Waiting...', datetime.datetime.now())
            #     time.sleep(1)

SuperTrendClass()