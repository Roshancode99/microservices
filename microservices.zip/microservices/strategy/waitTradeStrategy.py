from utilities import Utilities
import threading
from datetime import datetime
import time
import pandas as pd
import logging
import sysv_ipc
import json
import os
import traceback
class Strategy(Utilities):
    def __init__(self):
        super().__init__()
        
        try:
            self.logsQueue = sysv_ipc.MessageQueue(self.QKeys.get('logsQueue'),sysv_ipc.IPC_CREX)
        except Exception as e: 
            self.logsQueue = sysv_ipc.MessageQueue(self.QKeys.get('logsQueue'))

        try:
            self.zerodhaOMS = sysv_ipc.MessageQueue(self.QKeys.get('zerodhaOMS'),sysv_ipc.IPC_CREX)
        except Exception as e: 
            self.zerodhaOMS = sysv_ipc.MessageQueue(self.QKeys.get('zerodhaOMS'))
        
        try:
            self.testOMS = sysv_ipc.MessageQueue(self.QKeys.get('testOMS'),sysv_ipc.IPC_CREX)
        except Exception as e: 
            self.testOMS = sysv_ipc.MessageQueue(self.QKeys.get('testOMS'))

        try:
            self.xtsOMS = sysv_ipc.MessageQueue(self.QKeys.get('xtsOMS'),sysv_ipc.IPC_CREX)
        except Exception as e: 
            self.xtsOMS = sysv_ipc.MessageQueue(self.QKeys.get('xtsOMS'))

        try:
            self.strategyQueue = sysv_ipc.MessageQueue(self.QKeys.get('strategyWaitTradeQueue'),sysv_ipc.IPC_CREX)
        except Exception as e: 
            self.strategyQueue = sysv_ipc.MessageQueue(self.QKeys.get('strategyWaitTradeQueue'))

            

        self.ordersList={}

        # if not os.path.exists(f"""Logs/LOG_FILE_{str(datetime.now().strftime('%Y%m%d'))}.log"""):
        logging.basicConfig(filename=f"""Logs/WAITTRADE_LOG_FILE_{str(datetime.now().strftime('%Y%m%d'))}.log""", filemode='a',format='%(asctime)s - %(levelname)s - %(message)s')

        contractfilePath=self.baseDir+'store/contracts/nse_contractfile'+str(datetime.now().strftime('%Y%m%d'))+'.csv'
        self.contracts=pd.read_csv(contractfilePath)
        self.clientDetails={}
        self.flag=1
        self.l1_mark_price=0
        self.l2_mark_price=0

        threading.Thread(target=self.strategyQueueReader).start()
        threading.Thread(target=self.checkStrategy).start()
        threading.Thread(target=self.zerodhaTradeMatchingQueueReader).start()


    def checkStrategy(self):
        while self.flag>0:
            currentTime=datetime.now().strftime('%H:%M:%S')
            # print(currentTime)
            for j in list(self.clientDetails.values()):
                indicesToken=self.contracts.loc[(self.contracts['exchange']=='NSE') & (self.contracts['segment']=='CM') & (self.contracts['contract_name']==j.get('symbol')) ]['tokenid2'].values[0]
                print('indicesToken',indicesToken)
                res=self.read_ticker(indicesToken)
                # res=self.read_ticker(176093919241)
                # print(res)
                ltp=int(res.get('ltp'))
                strikeprice=self.getStrikePrice(ltp,j.get('symbol'))
                strikeprice=strikeprice
                l1=j.get('l1')
                l1['strikeprice']=strikeprice+(l1.get('strikediff')*100)
                l2=j.get('l2')
                l2['strikeprice']=strikeprice+(l2.get('strikediff')*100)
                # print(l1['strikeprice'],l2['strikeprice'],'***********stricke diff ************')

                # print(int(currentTime.replace(':','')),int(j.get('starttime').split('.')[0].replace(':','')))

                if j.get('status'):
                    if int(currentTime.replace(':','')) >=int(j.get('starttime').split('.')[0].replace(':','')):

                        # print(l1['strikeprice'],l2['strikeprice'])
                        temp=self.contracts.loc[(self.contracts['exchange']==j.get('exchange')) & (self.contracts['segment']==j.get('segment')) & (self.contracts['contract_name']==j.get('contract_name')) & (((self.contracts['strike_price']==l1.get('strikeprice')) & (self.contracts['option_type']==l1.get('option_type'))) | ((self.contracts['strike_price']==l2.get('strikeprice')) & (self.contracts['option_type']==l2.get('option_type')))) & (self.contracts['expiry']==j.get('expiry'))  ]
                        print(temp)
                        if temp.shape[0]==2:
                            for i in temp.to_dict('records'):
                                # for leg 1 sell 
                                if i.get('option_type')=='CE':
                                    
                                    legltp=int(self.read_ticker(i.get('tokenid2')).get('ask0'))
                                    if self.l1_mark_price==0:
                                        self.l1_mark_price=legltp
                                        msg=f"""WAITNTRADE | MarkTime {datetime.now()} | {i.get('token')} | {i.get('ticker_code')} | L1 MarkPrice {self.l1_mark_price} """
                                        logging.warning(msg)
                                        self.logsQueue.send(json.dumps({"client":j.get('client'),"msg":str(msg)}))



                                    
                                    if self.l1_mark_price-(self.l1_mark_price*(l1.get('waitntrade')/100))>=legltp:
                                        print("l1 marke price ",self.l1_mark_price,"ltp",legltp,self.l1_mark_price-(self.l1_mark_price*(l1.get('waitntrade')/100)))
                                        if l1.get('sellflag')==0:
                                            sl=legltp-(legltp*(l1.get('sl')/100))
                                            profit_val=legltp+(legltp*(l1.get('profit')/100))

                                            print("l1===============buy",legltp,sl,l1.get('sl'),profit_val)

                                            msg=f"""WAITNTRADE | Trigger Time {datetime.now()} | brokername {j.get('apiplatform')} | L1 markprice {self.l1_mark_price} | profit {profit_val} |strategyid {j.get('strategyid')} | Client {j.get('client')} | Expiry {j.get('expiry')} | Qty {j.get('qty')} | NIFTYBANK LTP {ltp} | Taking BUY Position In {i.get('token')} {i.get('ticker_code')} @LTP {legltp} |  SL @Price {sl} |"""
                                            
                                            if j.get('apiplatform')=='zerodha':
                                                self.zerodhaOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':legltp,'buysell':1,'booktype':1,'triggerprice':0,'token':i.get('token'),'ticker_code':i.get('ticker_code'),'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                                                orderno=int(datetime.timestamp(datetime.now())*1000)
                                                self.ordersList[orderno]={'event':"create",'data':{'apiplatform':j.get('apiplatform'),"profit_val":profit_val,'clientid':j.get('client'),'qty':j.get('qty'),'price':sl,'buysell':2,'booktype':1,'triggerprice':0,'token':i.get('token'),'tokenid2':i.get('tokenid2'),'ticker_code':i.get('ticker_code'),'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}
                                            elif j.get('apiplatform')=='test':
                                                self.testOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':legltp,'buysell':1,'booktype':1,'triggerprice':0,'token':i.get('token'),'ticker_code':i.get('ticker_code'),'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                                                orderno=int(datetime.timestamp(datetime.now())*1000)
                                                self.ordersList[orderno]={'event':"create",'data':{'apiplatform':j.get('apiplatform'),"profit_val":profit_val,'clientid':j.get('client'),'qty':j.get('qty'),'price':sl,'buysell':2,'booktype':1,'triggerprice':0,'token':i.get('token'),'tokenid2':i.get('tokenid2'),'ticker_code':i.get('ticker_code'),'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}
                                            elif j.get('apiplatform')=='xts':
                                                self.xtsOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':legltp,'buysell':1,'booktype':1,'triggerprice':0,'token':i.get('token'),'ticker_code':i.get('ticker_code'),'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                                                orderno=int(datetime.timestamp(datetime.now())*1000)
                                                self.ordersList[orderno]={'event':"create",'data':{'apiplatform':j.get('apiplatform'),"profit_val":profit_val,'clientid':j.get('client'),'qty':j.get('qty'),'price':sl,'buysell':2,'booktype':1,'triggerprice':0,'token':i.get('token'),'tokenid2':i.get('tokenid2'),'ticker_code':i.get('ticker_code'),'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}
                                                  
                                                
                                            logging.warning(msg)
                                            self.logsQueue.send(json.dumps({"client":j.get('client'),"msg":str(msg)}))

                                            j['l1']['sellflag']=1
                                            j['l1']['token']=i.get('token')
                                            self.l1_mark_price=0
                                if i.get('option_type')=='PE':
                                    # for leg 2 sell
                                    legltp=int(self.read_ticker(i.get('tokenid2')).get('ask0'))
                                    if self.l2_mark_price==0:
                                        self.l2_mark_price=legltp
                                        msg=f"""WAITNTRADE | MarkTime {datetime.now()} | {i.get('token')} | {i.get('ticker_code')} | L2 MarkPrice {self.l2_mark_price} """
                                        logging.warning(msg)
                                        self.logsQueue.send(json.dumps({"client":j.get('client'),"msg":str(msg)}))



                                    if self.l2_mark_price-(self.l2_mark_price*(l2.get('waitntrade')/100))>=legltp:
                                        print("l2 marke price ",self.l2_mark_price,"ltp",legltp,self.l2_mark_price-(self.l2_mark_price*(l2.get('waitntrade')/100)))
                                        if l2.get('sellflag')==0:
                                            sl=legltp-(legltp*(l2.get('sl')/100))
                                            profit_val=legltp+(legltp*(l2.get('profit')/100))

                                            print("l2===============buy",legltp,sl,l2.get('sl'),profit_val)

                                            msg=f"""WAITNTRADE | Trigger Time {datetime.now()} | brokername {j.get('apiplatform')} | L2 markprice {self.l2_mark_price} | profit {profit_val} | strategyid {j.get('strategyid')} | Client {j.get('client')} | Expiry {j.get('expiry')} | Qty {j.get('qty')} | NIFTYBANK LTP {ltp} | Taking BUY Position In {i.get('token')} {i.get('ticker_code')} @LTP {legltp} |  SL @Price {sl} |"""
                                            if j.get('apiplatform')=='zerodha':
                                                self.zerodhaOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':legltp,'buysell':1,'booktype':1,'triggerprice':0,'token':i.get('token'),'ticker_code':i.get('ticker_code'),'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                                                orderno=int(datetime.timestamp(datetime.now())*1000)
                                                self.ordersList[orderno]={'event':"create",'data':{'apiplatform':j.get('apiplatform'),"profit_val":profit_val,'clientid':j.get('client'),'qty':j.get('qty'),'price':sl,'buysell':2,'booktype':1,'triggerprice':0,'token':i.get('token'),'tokenid2':i.get('tokenid2'),'ticker_code':i.get('ticker_code'),'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}
                                            elif j.get('apiplatform')=='test':
                                                self.testOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':legltp,'buysell':1,'booktype':1,'triggerprice':0,'token':i.get('token'),'ticker_code':i.get('ticker_code'),'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                                                orderno=int(datetime.timestamp(datetime.now())*1000)
                                                self.ordersList[orderno]={'event':"create",'data':{'apiplatform':j.get('apiplatform'),"profit_val":profit_val,'clientid':j.get('client'),'qty':j.get('qty'),'price':sl,'buysell':2,'booktype':1,'triggerprice':0,'token':i.get('token'),'tokenid2':i.get('tokenid2'),'ticker_code':i.get('ticker_code'),'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}
                                            elif j.get('apiplatform')=='xts':
                                                self.xtsOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':legltp,'buysell':1,'booktype':1,'triggerprice':0,'token':i.get('token'),'ticker_code':i.get('ticker_code'),'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                                                orderno=int(datetime.timestamp(datetime.now())*1000)
                                                self.ordersList[orderno]={'event':"create",'data':{'apiplatform':j.get('apiplatform'),"profit_val":profit_val,'clientid':j.get('client'),'qty':j.get('qty'),'price':sl,'buysell':2,'booktype':1,'triggerprice':0,'token':i.get('token'),'tokenid2':i.get('tokenid2'),'ticker_code':i.get('ticker_code'),'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}
                                              
                                                
                                            logging.warning(msg)
                                            self.logsQueue.send(json.dumps({"client":j.get('client'),"msg":str(msg)}))

                                            j['l2']['sellflag']=1
                                            j['l2']['token']=i.get('token')
                                            self.l2_mark_price=0



                        else:
                            print("couldn't find strike_price price ")
                            logging.error(f"""{datetime.now()} couldn't find strike_price price  !!!""")
               
    def getStrikePrice(self,ltp,contract_name):
        strike1=0
        try:
            if contract_name=='NIFTY 50':
                print("**********",ltp)
                c=ltp%10000
                # print(c)
                d=5000-c
                # print(d)

                if d<2500:
                    strike1=ltp+d
                else:
                    strike1=ltp-c

                print(contract_name,"strike_price===",int(strike1))

            elif contract_name=='NIFTY BANK':

                print("**********",ltp)
                c=ltp%10000
                # print(c)
                d=10000-c
                # print(d)

                if d<5000:
                    strike1=ltp+d
                else:
                    strike1=ltp-c

                print(contract_name,"strike_price===",int(strike1))

            return strike1

        except Exception as e:
            print("error on getStrikePrice")
            return strike1

    def zerodhaTradeMatchingQueueReader(self):
        try:
            while self.flag > 0:
                currentTime=datetime.now().strftime('%H:%M:%S')
                for i in list(self.ordersList.keys()):
                    try:
                        temp=self.ordersList.get(i)
                        item=temp.get('data')
                        # print(item)
                        res=self.read_ticker(item.get('tokenid2'))
                        bid=res.get('bid0')
                        profit_val=item.get('profit_val')
                        # print(bid,profit_val)
                        if bid <=item.get('price'):
                            msg=f"""WAITNTRADE | Trigger Time {datetime.now()} | brokername {item.get('apiplatform')} | profit {profit_val} | Client {item.get('clientid')} | Expiry {item.get('expiry')} | Qty {item.get('qty')} Taking SELL Position In {item.get('token')} {item.get('ticker_code')} @bid {bid} | sl hitt {item.get('price')}"""
                            logging.warning(msg)
                            self.logsQueue.send(json.dumps({"client":item.get('client'),"msg":str(msg)}))

                            if item.get('apiplatform')=='zerodha':
                                self.zerodhaOMS.send(json.dumps(temp))
                                self.ordersList.pop(i,None) 
                            if item.get('apiplatform')=='test':
                                self.testOMS.send(json.dumps(temp))
                                self.ordersList.pop(i,None)
                            if item.get('apiplatform')=='xts':
                                self.xtsOMS.send(json.dumps(temp))
                                self.ordersList.pop(i,None)

                            for j in list(self.clientDetails.values()):
                                print(j.get('l1').get('sellflag'),j.get('l2').get('sellflag'))

                                if (j.get('clientid') ==item.get('clientid')) and (j.get('strategyid') ==item.get('strategyid')) and (j.get('l1').get('token')==item.get('token')):
                                    j['l1']['sellflag']=3
                                    print("l1 SELL",j['l1']['sellflag'])
                                if (j.get('clientid') ==item.get('clientid')) and (j.get('strategyid') ==item.get('strategyid')) and (j.get('l2').get('token')==item.get('token')):
                                    j['l2']['sellflag']=3
                                    print("l2 SELL",j['l2']['sellflag'])


                                if (j.get('l1').get('sellflag')==3) and (j.get('l2').get('sellflag')==3):
                                    if j['cymcleno']>0:
                                        print(j['cymcleno'])
                                        j['cymcleno']=j['cymcleno']-1
                                        msg=f"""WAITNTRADE | {datetime.now()} Cycle rem cycle no {str(j['cymcleno'])}!!!"""
                                        logging.warning(msg)
                                        self.logsQueue.send(json.dumps({"client":j.get('client'),"msg":str(msg)}))

                                        j['l1']['sellflag']=0
                                        j['l2']['sellflag']=0
                                    else:
                                        j['status']=False
                                        msg=f"""WAITNTRADE | {datetime.now()} Cycle completed!!!"""
                                        print(msg)
                                        logging.warning(msg)
                                        self.logsQueue.send(json.dumps({"client":j.get('client'),"msg":str(msg)}))


                        elif bid >=profit_val:
                            temp['data']['price']=bid
                            msg=f"""WAITNTRADE | Trigger Time {datetime.now()} | brokername {item.get('apiplatform')} | profit {profit_val} | Client {item.get('clientid')} | Expiry {item.get('expiry')} | Qty {item.get('qty')} Taking SELL Position In {item.get('token')} {item.get('ticker_code')} @bid {bid} | profit hitt {item.get('profit_val')}"""
                            logging.warning(msg)
                            self.logsQueue.send(json.dumps({"client":item.get('client'),"msg":str(msg)}))

                            if item.get('apiplatform')=='zerodha':
                                self.zerodhaOMS.send(json.dumps(temp))
                                self.ordersList.pop(i,None) 
                            if item.get('apiplatform')=='test':
                                self.testOMS.send(json.dumps(temp))
                                self.ordersList.pop(i,None)
                            if item.get('apiplatform')=='xts':
                                self.xtsOMS.send(json.dumps(temp))
                                self.ordersList.pop(i,None)

                            for j in list(self.clientDetails.values()):
                                print(j.get('l1').get('sellflag'),j.get('l2').get('sellflag'))

                                if (j.get('clientid') ==item.get('clientid')) and (j.get('strategyid') ==item.get('strategyid')) and (j.get('l1').get('token')==item.get('token')):
                                    j['l1']['sellflag']=3
                                    print("l1 SELL",j['l1']['sellflag'])
                                if (j.get('clientid') ==item.get('clientid')) and (j.get('strategyid') ==item.get('strategyid')) and (j.get('l2').get('token')==item.get('token')):
                                    j['l2']['sellflag']=3
                                    print("l2 SELL",j['l2']['sellflag'])


                                if (j.get('l1').get('sellflag')==3) and (j.get('l2').get('sellflag')==3):
                                    if j['cymcleno']>0:
                                        print(j['cymcleno'])
                                        j['cymcleno']=j['cymcleno']-1
                                        msg=f"""WAITNTRADE | {datetime.now()} Cycle rem cycle no {str(j['cymcleno'])}!!!"""
                                        logging.warning(msg)
                                        self.logsQueue.send(json.dumps({"client":j.get('client'),"msg":str(msg)}))

                                        j['l1']['sellflag']=0
                                        j['l2']['sellflag']=0
                                    else:
                                        j['status']=False
                                        msg=f"""WAITNTRADE | {datetime.now()} Cycle completed!!!"""
                                        print(msg)
                                        logging.warning(msg)
                                        self.logsQueue.send(json.dumps({"client":j.get('client'),"msg":str(msg)}))



                        # if currentTime=='15:29:00':
                        if int(currentTime.replace(':','')) >=int(str('15:29:00').replace(':','')):
                            print(int(currentTime.replace(':','')) ,int(str('15:29:00').replace(':','')))
                            temp.get('data')['price']=bid
                            item=temp.get('data')
                            msg=f"""WAITNTRADE | Trigger Time {datetime.now()} | brokername {item.get('apiplatform')} | Client {item.get('clientid')} | Expiry {item.get('expiry')} | Qty {item.get('qty')} CLOSE ALL OPEN Position In {item.get('token')} {item.get('ticker_code')} @bid {bid} |"""
                            logging.warning(msg)
                            self.logsQueue.send(json.dumps({"client":item.get('client'),"msg":str(msg)}))

                            if item.get('apiplatform')=='zerodha':
                                self.zerodhaOMS.send(json.dumps(temp))
                                self.ordersList.pop(i,None) 
                            if item.get('apiplatform')=='test':
                                self.testOMS.send(json.dumps(temp))
                                self.ordersList.pop(i,None)
                            if item.get('apiplatform')=='xts':
                                self.xtsOMS.send(json.dumps(temp))
                                self.ordersList.pop(i,None)
                    
                    except Exception as e:
                        print("Error on dataa",e)
        except Exception as e:
            print("[Error] in (self,zerodhaTradeMatchingQueueReader) msg: ",e)

    def closePositionOnStopStrategy(self,strategyid):
        try:
            for i in list(self.ordersList.keys()):
                try:
                    temp=self.ordersList.get(i)
                    item=temp.get('data')
                    res=self.read_ticker(item.get('tokenid2'))
                    ask=res.get('ask0')
                    temp['data']['price']=ask
                    item=temp.get('data')
                    if item.get('strategyid')==strategyid:
                        msg=f"""BAHUBALI | Trigger Time {datetime.now()} | broker name {item.get('apiplatform')} | Client {item.get('clientid')} | Expiry {item.get('expiry')} | Qty {item.get('qty')} CLOSE Position on Stop Strategy In {item.get('token')} {item.get('ticker_code')} @ask {ask} |"""
                        if item.get('apiplatform')=='zerodha':
                            self.zerodhaOMS.send(json.dumps(temp))
                        if item.get('apiplatform')=='test':
                            self.testOMS.send(json.dumps(temp))
                        if item.get('apiplatform')=='xts':
                            self.xtsOMS.send(json.dumps(temp))
                        logging.warning(msg)
                        self.logsQueue.send(json.dumps({"client":item.get('client'),"msg":str(msg)}))
                        self.ordersList.pop(i,None)
                        time.sleep(0.5)
                except Exception as e:
                    print("Error on reading ticker dataa",e)
        except Exception as e:
            print("[Error] in (self,closePositionOnStopStrategy) msg: ", str(e))

    def strategyQueueReader(self):
        while self.flag > 0:
            print("Waiting for Message Queuee..............")
            try:
                item = self.strategyQueue.receive()
                item = json.loads(item[0])

                print(item)
                if item.get('event')=='add':
                    item=item.get('data')
                    self.clientDetails[item['strategyid']]=item
                    print("add strategyQueueReader... ",item)
                
                if item.get('event')=='delete':
                    item=item.get('data')
                    self.clientDetails.pop(item['strategyid'],None)
                    print(self.clientDetails)
                    print("delete strategyQueueReader... ",item['strategyid'],item['clientid'])

                if item.get('event')=='start':
                    item=item.get('data')
                    print(item)
                    if self.clientDetails.get(item['strategyid']):
                        self.clientDetails[item['strategyid']]['status']=item.get('status')
                        self.clientDetails[item['strategyid']]['real']=item.get('real')
                    else:
                        print("append***-")
                        self.clientDetails[item['strategyid']]=item

                    print(self.clientDetails)
                    print("start strategyQueueReader... ",item['strategyid'],item['clientid'])

                if item.get('event')=='stop':
                    item=item.get('data')
                    print(item)
                    if self.clientDetails.get(item['strategyid']):
                        self.clientDetails[item['strategyid']]['status']=item.get('status')
                        self.clientDetails[item['strategyid']]['real']=item.get('real')

                    print(self.clientDetails)
                    
                    if item.get('status')==False:
                        self.closePositionOnStopStrategy(item['strategyid'])
                        print("close open position ",item['strategyid'])

                    print("stop strategyQueueReader... ",item['strategyid'],item['clientid'])

               
                if item.get('event')=='update':
                    item=item.get('data')
                    print(item)
                    if self.clientDetails.get(item['strategyid']):
                        self.clientDetails[item['strategyid']]['qty']=item.get('qty')
                    print(self.clientDetails)
                    print("update strategyQueueReader... ",item['strategyid'],item['clientid'])

            except Exception as e:
                # print(traceback.format_exc())
                print("[Error] in (self,strategyQueueReader) msg: ", str(e))

Strategy()