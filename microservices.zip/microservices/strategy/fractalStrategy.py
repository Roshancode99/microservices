from utilities import Utilities
import datetime
import pandas as pd
import sys
import os
import time,json
import logging
import sysv_ipc
import threading
import numpy as np
from py5paisa import FivePaisaClient



class FractalClass(Utilities):
    def __init__(self):
        super().__init__()
        self.flag=1
        self.fractalvalue=0
        self.tokenid2list=[]
        self.tokenlist=[]
        self.tickerlist=[]
        self.strikeprice=0

        try:
            self.logsQueue = sysv_ipc.MessageQueue(self.QKeys.get('logsQueue'),sysv_ipc.IPC_CREX)
        except Exception as e: 
            self.logsQueue = sysv_ipc.MessageQueue(self.QKeys.get('logsQueue'))

        # self.logsQueue.send(json.dumps({"clientid":2,"msg":str("testing msg")}))


        try:
            self.zerodhaOMS = sysv_ipc.MessageQueue(self.QKeys.get('zerodhaOMS'),sysv_ipc.IPC_CREX)
        except Exception as e: 
            self.zerodhaOMS = sysv_ipc.MessageQueue(self.QKeys.get('zerodhaOMS'))

        try:
            self.testOMS = sysv_ipc.MessageQueue(self.QKeys.get('testOMS'),sysv_ipc.IPC_CREX)
        except Exception as e: 
            self.testOMS = sysv_ipc.MessageQueue(self.QKeys.get('testOMS'))

        try:
            self.xtsOMS = sysv_ipc.MessageQueue(self.QKeys.get('xtsOMS'),sysv_ipc.IPC_CREX)
        except Exception as e: 
            self.xtsOMS = sysv_ipc.MessageQueue(self.QKeys.get('xtsOMS'))

        try:
            self.fivepaisaOMS = sysv_ipc.MessageQueue(self.QKeys.get('fivepaisaOMS'),sysv_ipc.IPC_CREX)
        except Exception as e: 
            self.fivepaisaOMS = sysv_ipc.MessageQueue(self.QKeys.get('fivepaisaOMS'))

        try:
            self.strategyQueue = sysv_ipc.MessageQueue(self.QKeys.get('strategyFractalQueue'),sysv_ipc.IPC_CREX)
        except Exception as e: 
            self.strategyQueue = sysv_ipc.MessageQueue(self.QKeys.get('strategyFractalQueue'))

            


        # if not os.path.exists(f"""Logs/LOG_FILE_{str(datetime.now().strftime('%Y%m%d'))}.log"""):
        logging.basicConfig(filename=f"""Logs/FRACTAL_LOG_FILE_{str(datetime.datetime.now().strftime('%Y%m%d'))}.log""", filemode='a',format='%(asctime)s - %(levelname)s - %(message)s')

        contractfilePath=self.baseDir+'store/contracts/nse_contractfile'+str(datetime.datetime.now().strftime('%Y%m%d'))+'.csv'
        self.contracts=pd.read_csv(contractfilePath)

        self.clientDetails={}
        self.sellflag=0
        self.res=self.read_ticker(51539633553)
        self.runcount = 0
        self.fractal_period = 5
        self.candlesize = '5m'
        self.start_time = int(9) * 60 + int(20)  # specify in int (hr) and int (min) foramte
        self.end_time = int(15) * 60 + int(25)  # do not place fresh order
        self.stop_time = int(15) * 60 + int(25)  # square off all open positions
        self.last_time = self.start_time
        self.schedule_interval = 300  # run at every 5 min


        apidetails=self.jsonConfigfile.get('fivepaisa_api')
        self.fivepaisa=FivePaisaClient(cred=apidetails.get('cred'))
        self.fivepaisa.access_token = apidetails.get('access_token')
        self.fivepaisa.Jwt_token = apidetails.get('access_token')
        self.fivepaisa.client_code = apidetails.get('client_code')


        # self.gethistoricaldata([39006,39005])
        threading.Thread(target=self.strategyQueueReader).start()
        threading.Thread(target=self.run).start()
        # # threading.Thread(target=self.run_buyPosition).start()

    def fractal_indicator(self,df, period):
        df['center_h'] = df['close'].rolling(period).apply(lambda x : df['close'].iloc[x.index[-3]])
        hh = df['close'].rolling(period).max()
        df['fractal_h'] = hh
        df['fractal']=df['center_h']==df['fractal_h']
        df=df.loc[df['fractal']==True]
        return df

    def getStrikePrice(self,ltp,contract_name):
        strike1=0
        try:
            if contract_name=='NIFTY 50':
                print("**********",ltp)
                c=ltp%10000
                # print(c)
                d=5000-c
                # print(d)

                if d<2500:
                    strike1=ltp+d
                else:
                    strike1=ltp-c

                print(contract_name,"strike_price===",int(strike1))

            elif contract_name=='NIFTY BANK':

                print("**********",ltp)
                c=ltp%10000
                # print(c)
                d=10000-c
                # print(d)

                if d<5000:
                    strike1=ltp+d
                else:
                    strike1=ltp-c

                print(contract_name,"strike_price===",int(strike1))

            return strike1

        except Exception as e:
            print("error on getStrikePrice")
            return strike1

    def gethistoricaldata(self,token):
        print("call gethistoricaldata")

        enddate = datetime.datetime.today()
        startdate = enddate - datetime.timedelta(5)
        df = pd.DataFrame(columns=['datetime', 'open', 'high', 'low', 'close', 'volume'])
        try:
            data1 = self.fivepaisa.historical_data('N','D',token[0],self.candlesize,startdate,enddate)
            # print(data1)
            df1 = pd.DataFrame.from_dict(data1, orient='columns', dtype=None)
            df1.columns = df1.columns.str.lower()

            data2 = self.fivepaisa.historical_data('N','D',token[1],self.candlesize,startdate,enddate)

            df2 = pd.DataFrame.from_dict(data2, orient='columns', dtype=None)
            df2.columns = df2.columns.str.lower()

            df= pd.merge(df1, df2,  how='left', left_on=['datetime'], right_on = ['datetime'])
            df['open']=df['open_x']+df['open_y']
            df['high']=df['high_x']+df['high_y']
            df['low']=df['low_x']+df['low_y']
            df['close']=df['close_x']+df['close_y']
            df['volume']=df['volume_x']+df['volume_y']
            df.drop(['open_x', 'high_x', 'low_x', 'close_x', 'volume_x','open_y', 'high_y', 'low_y', 'close_y', 'volume_y'],axis=1,inplace=True)
            if not df.empty:
                df = df[['datetime', 'open', 'high', 'low', 'close', 'volume']]
                # df['datetime'] = df['datetime'].astype(str).str[:-6]
                df['datetime'] = pd.to_datetime(df['datetime'])
                df=self.fractal_indicator(df,self.fractal_period)
                # print(data.tail(20))
        except Exception as e:
            print("Error in gethistoricaldata", token, e)
        df.to_csv("Logs/FRACTAL_CSV_FILE_"+str(token[0])+" "+str(token[1])+".csv")
        return df

    def run_trategy(self):

        if self.sellflag==0:
            indicesToken=self.contracts.loc[(self.contracts['exchange']=='NSE') & (self.contracts['segment']=='CM') & (self.contracts['contract_name']=="NIFTY BANK") ]['tokenid2'].values[0]
            print('indicesToken',indicesToken)
            self.res=self.read_ticker(indicesToken)

        ltp=self.res.get('ltp')
        if self.strikeprice==0:
            self.strikeprice=self.getStrikePrice(ltp,"NIFTY BANK")
        else:
            print(self.strikeprice)
        temp=self.contracts.loc[(self.contracts['exchange']=='NSE') & (self.contracts['segment']=='FO') & (self.contracts['contract_name']=='BANKNIFTY') & (self.contracts['strike_price']==self.strikeprice) & (self.contracts['expiry']=='04Oct2023')]
        # temp=self.contracts.loc[(self.contracts['exchange']=='NFO') & (self.contracts['segment']=='NFO-OPT') & (self.contracts['contract_name']=='BANKNIFTY') & (self.contracts['strike_price']==self.strikeprice) & (self.contracts['expiry']==j.get('expiry'))  ]
        if temp.shape[0]==2:
            self.tickerlist=temp['ticker_code'].values
            self.tokenlist=temp['token'].values
            self.tokenid2list=temp['tokenid2'].values
            print("ticker list",self.tickerlist,self.tokenlist)
            histdata = self.gethistoricaldata(self.tokenlist)
            if histdata.fractal.values[-1]:
                self.fractalvalue = histdata.fractal_h.values[-1]
            # print(histdata.tail(1))
            ltp1=int(self.read_ticker(self.tokenid2list[0]).get('bid0'))/100
            ltp2=int(self.read_ticker(self.tokenid2list[1]).get('bid0'))/100
            ask1=int(self.read_ticker(self.tokenid2list[0]).get('ask0'))/100
            ask2=int(self.read_ticker(self.tokenid2list[1]).get('ask0'))/100
            print("fractalvalue ",self.fractalvalue,"current price ",ltp1,ltp2,"sum",ltp1+ltp2 , self.sellflag)

            if self.fractalvalue!=0:
                if self.sellflag==0 and self.fractalvalue>(ltp1+ltp2):#sell condition
                    print("checking for sell")
                    for j in list(self.clientDetails.values()):
                        if j.get('status'):
                            print(j)
                            msg=f"""FRACTAL | Trigger Time {datetime.datetime.now()} |strategyid {j.get('strategyid')} | Client {j.get('client')} | Expiry {j.get('expiry')} | Qty {j.get('qty')} |FRACTAL value {self.fractalvalue} | LTP {ltp/100} | Taking SELL Position In {self.tokenlist[0]} {self.tickerlist[0]} @LTP {ltp1} |"""
                            msg2=f"""FRACTAL | Trigger Time {datetime.datetime.now()} |strategyid {j.get('strategyid')} | Client {j.get('client')} | Expiry {j.get('expiry')} | Qty {j.get('qty')} |FRACTAL value {self.fractalvalue} | LTP {ltp/100} | Taking SELL Position In {self.tokenlist[1]} {self.tickerlist[1]} @LTP {ltp2} |"""
                            if j.get('apiplatform')=='zerodha':
                                self.zerodhaOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(ltp1*100),'buysell':2,'booktype':1,'triggerprice':0,'token':int(self.tokenlist[0]),'ticker_code':self.tickerlist[0],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                                self.zerodhaOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(ltp2*100),'buysell':2,'booktype':1,'triggerprice':0,'token':int(self.tokenlist[1]),'ticker_code':self.tickerlist[1],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                            elif j.get('apiplatform')=='test':
                                self.testOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(ltp1*100),'buysell':2,'booktype':1,'triggerprice':0,'token':int(self.tokenlist[0]),'ticker_code':self.tickerlist[0],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                                self.testOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(ltp2*100),'buysell':2,'booktype':1,'triggerprice':0,'token':int(self.tokenlist[1]),'ticker_code':self.tickerlist[1],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                            elif j.get('apiplatform')=='xts':
                                self.xtsOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(ltp1*100),'buysell':2,'booktype':1,'triggerprice':0,'token':int(self.tokenlist[0]),'ticker_code':self.tickerlist[0],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                                self.xtsOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(ltp2*100),'buysell':2,'booktype':1,'triggerprice':0,'token':int(self.tokenlist[1]),'ticker_code':self.tickerlist[1],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                            elif j.get('apiplatform')=='fivepaisa':
                                self.fivepaisaOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(ltp1*100),'buysell':2,'booktype':1,'triggerprice':0,'token':int(self.tokenlist[0]),'ticker_code':self.tickerlist[0],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                                self.fivepaisaOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(ltp2*100),'buysell':2,'booktype':1,'triggerprice':0,'token':int(self.tokenlist[1]),'ticker_code':self.tickerlist[1],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                            
                            logging.warning(msg)
                            logging.warning(msg2)
                            self.logsQueue.send(json.dumps({"clientid":j.get('client'),"msg":str(msg)}))
                            self.logsQueue.send(json.dumps({"clientid":j.get('client'),"msg":str(msg2)}))

                        self.sellflag=1
                elif self.sellflag==1 and self.fractalvalue<(ask1+ask2):#Buy condition
                    print("checking for buy")
                    for j in list(self.clientDetails.values()):
                        if j.get('status'):
                            print(j)
                            msg=f"""FRACTAL | Trigger Time {datetime.datetime.now()} |strategyid {j.get('strategyid')} | Client {j.get('client')} | Expiry {j.get('expiry')} | Qty {j.get('qty')} |FRACTAL value {self.fractalvalue} | LTP {ltp/100} | Taking BUY Position In {self.tokenlist[0]} {self.tickerlist[0]} @LTP {ask1} |"""
                            msg2=f"""FRACTAL | Trigger Time {datetime.datetime.now()} |strategyid {j.get('strategyid')} | Client {j.get('client')} | Expiry {j.get('expiry')} | Qty {j.get('qty')} |FRACTAL value {self.fractalvalue} | LTP {ltp/100} | Taking BUY Position In {self.tokenlist[1]} {self.tickerlist[1]} @LTP {ask2} |"""
                            if j.get('apiplatform')=='zerodha':
                                self.zerodhaOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(ask1*100),'buysell':1,'booktype':1,'triggerprice':0,'token':int(self.tokenlist[0]),'ticker_code':self.tickerlist[0],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                                self.zerodhaOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(ask2*100),'buysell':1,'booktype':1,'triggerprice':0,'token':int(self.tokenlist[1]),'ticker_code':self.tickerlist[1],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                            elif j.get('apiplatform')=='test':
                                self.testOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(ask1*100),'buysell':1,'booktype':1,'triggerprice':0,'token':int(self.tokenlist[0]),'ticker_code':self.tickerlist[0],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                                self.testOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(ask2*100),'buysell':1,'booktype':1,'triggerprice':0,'token':int(self.tokenlist[1]),'ticker_code':self.tickerlist[1],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                            elif j.get('apiplatform')=='xts':
                                self.xtsOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(ask1*100),'buysell':1,'booktype':1,'triggerprice':0,'token':int(self.tokenlist[0]),'ticker_code':self.tickerlist[0],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                                self.xtsOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(ask2*100),'buysell':1,'booktype':1,'triggerprice':0,'token':int(self.tokenlist[1]),'ticker_code':self.tickerlist[1],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                            elif j.get('apiplatform')=='fivepaisa':
                                self.fivepaisaOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(ask1*100),'buysell':1,'booktype':1,'triggerprice':0,'token':int(self.tokenlist[0]),'ticker_code':self.tickerlist[0],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                                self.fivepaisaOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(ask2*100),'buysell':1,'booktype':1,'triggerprice':0,'token':int(self.tokenlist[1]),'ticker_code':self.tickerlist[1],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))

                            logging.warning(msg)
                            logging.warning(msg2)
                            self.logsQueue.send(json.dumps({"clientid":j.get('client'),"msg":str(msg)}))
                            self.logsQueue.send(json.dumps({"clientid":j.get('client'),"msg":str(msg2)}))

                        self.sellflag=0
            else:
                print(histdata)
                msg=f"""FRACTAL | Trigger Time {datetime.datetime.now()} | FRACTAL value is {str(self.fractalvalue)} """
                print(msg)
                logging.warning(msg)
                for j in list(self.clientDetails.values()):
                    if j.get('status'):
                        self.logsQueue.send(json.dumps({"clientid":j.get('client'),"msg":str(msg)}))
         
    def strategyQueueReader(self):
        while self.flag > 0:
            print("Waiting for Message Queuee..............")
            try:
                item = self.strategyQueue.receive()
                print(item)
                item = json.loads(item[0])
                if item.get('event')=='add':
                    item=item.get('data')
                    self.clientDetails[item['strategyid']]=item
                    print("add strategyQueueReader... ",item)
                
                if item.get('event')=='delete':
                    item=item.get('data')
                    self.clientDetails.pop(item['strategyid'],None)
                    print(self.clientDetails)
                    print("delete strategyQueueReader... ",item['strategyid'],item['clientid'])

                if item.get('event')=='start':
                    item=item.get('data')
                    print(item)
                    if self.clientDetails.get(item['strategyid']):
                        self.clientDetails[item['strategyid']]['status']=item.get('status')
                        self.clientDetails[item['strategyid']]['real']=item.get('real')
                    else:
                        print("append***-")
                        self.clientDetails[item['strategyid']]=item

                    print(self.clientDetails)
                    print("start strategyQueueReader... ",item['strategyid'],item['clientid'])

                if item.get('event')=='stop':
                    item=item.get('data')
                    print(item)
                    if self.clientDetails.get(item['strategyid']):
                        self.clientDetails[item['strategyid']]['status']=item.get('status')
                        self.clientDetails[item['strategyid']]['real']=item.get('real')

                    if item.get('status')==False:
                        self.closePositionOnStopStrategy(item)
                        print("close open position ",item['strategyid'])

                    print("stop strategyQueueReader... ",item['strategyid'],item['clientid'])
               
                if item.get('event')=='update':
                    item=item.get('data')
                    print(item)
                    if self.clientDetails.get(item['strategyid']):
                        self.clientDetails[item['strategyid']]['qty']=item.get('qty')
                    print(self.clientDetails)
                    print("update strategyQueueReader... ",item['strategyid'],item['clientid'])

            except Exception as e:
                # print(traceback.format_exc())
                print("[Error] in (self,strategyQueueReader) msg: ", str(e))

    def closePositionOnStopStrategy(self,data):
        try:
            if self.sellflag==1:#Buy condition
                    print("closePositionOnStopStrategy buy")
                    for j in list(self.clientDetails.values()):
                        if j.get('strategyid')== data.get('strategyid') and j.get('client')== data.get('clientid'):
                            print(j)
                            ltp=self.res.get('ltp')
                            ask1=int(self.read_ticker(self.tokenid2list[0]).get('ask0'))/100
                            ask2=int(self.read_ticker(self.tokenid2list[1]).get('ask0'))/100

                            msg=f"""FRACTAL | Trigger Time {datetime.datetime.now()} |strategyid {j.get('strategyid')} | Client {j.get('client')} | Expiry {j.get('expiry')} | Qty {j.get('qty')} |FRACTAL value {self.fractalvalue} | LTP {ltp/100} | Taking BUY Position On Stop Strategy In {self.tokenlist[0]} {self.tickerlist[0]} @LTP {ask1} |"""
                            msg2=f"""FRACTAL | Trigger Time {datetime.datetime.now()} |strategyid {j.get('strategyid')} | Client {j.get('client')} | Expiry {j.get('expiry')} | Qty {j.get('qty')} |FRACTAL value {self.fractalvalue} | LTP {ltp/100} | Taking BUY Position On Stop Strategy In {self.tokenlist[1]} {self.tickerlist[1]} @LTP {ask2} |"""
                            if j.get('apiplatform')=='zerodha':
                                self.zerodhaOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(ask1*100),'buysell':1,'booktype':1,'triggerprice':0,'token':int(self.tokenlist[0]),'ticker_code':self.tickerlist[0],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                                self.zerodhaOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(ask2*100),'buysell':1,'booktype':1,'triggerprice':0,'token':int(self.tokenlist[1]),'ticker_code':self.tickerlist[1],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                            elif j.get('apiplatform')=='test':
                                self.testOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(ask1*100),'buysell':1,'booktype':1,'triggerprice':0,'token':int(self.tokenlist[0]),'ticker_code':self.tickerlist[0],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                                self.testOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(ask2*100),'buysell':1,'booktype':1,'triggerprice':0,'token':int(self.tokenlist[1]),'ticker_code':self.tickerlist[1],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                            elif j.get('apiplatform')=='xts':
                                self.xtsOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(ask1*100),'buysell':1,'booktype':1,'triggerprice':0,'token':int(self.tokenlist[0]),'ticker_code':self.tickerlist[0],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                                self.xtsOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(ask2*100),'buysell':1,'booktype':1,'triggerprice':0,'token':int(self.tokenlist[1]),'ticker_code':self.tickerlist[1],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                            elif j.get('apiplatform')=='fivepaisa':
                                self.fivepaisaOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(ask1*100),'buysell':1,'booktype':1,'triggerprice':0,'token':int(self.tokenlist[0]),'ticker_code':self.tickerlist[0],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                                self.fivepaisaOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(ask2*100),'buysell':1,'booktype':1,'triggerprice':0,'token':int(self.tokenlist[1]),'ticker_code':self.tickerlist[1],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))

                            logging.warning(msg)
                            logging.warning(msg2)
                            self.logsQueue.send(json.dumps({"clientid":j.get('client'),"msg":str(msg)}))
                            self.logsQueue.send(json.dumps({"clientid":j.get('client'),"msg":str(msg2)}))

                        self.sellflag=0

        except Exception as e:
            print("[Error] in (self,closePositionOnStopStrategy) msg: ", str(e))

    def run(self):
        while self.flag>0:
            if (datetime.datetime.now().hour * 60 + datetime.datetime.now().minute) >= self.end_time:
                if (datetime.datetime.now().hour * 60 + datetime.datetime.now().minute) >= self.stop_time:
                    print("checking for Auto close @ ",datetime.datetime.now())
                    ltp=self.res.get('ltp')
                    ltp1=int(self.read_ticker(self.tokenid2list[0]).get('ask0'))/100
                    ltp2=int(self.read_ticker(self.tokenid2list[1]).get('ask0'))/100
                    if self.sellflag==1:
                        for j in list(self.clientDetails.values()):
                            if j.get('status'):
                                print(j)
                                msg=f"""FRACTAL | Trigger Time {datetime.datetime.now()} |strategyid {j.get('strategyid')} | Client {j.get('client')} | Expiry {j.get('expiry')} | Qty {j.get('qty')} | LTP {ltp/100} | Taking BUY Position In {self.tokenlist[0]} {self.tickerlist[0]} @LTP {ltp1} |"""
                                msg2=f"""FRACTAL | Trigger Time {datetime.datetime.now()} |strategyid {j.get('strategyid')} | Client {j.get('client')} | Expiry {j.get('expiry')} | Qty {j.get('qty')} | LTP {ltp/100} | Taking BUY Position In {self.tokenlist[1]} {self.tickerlist[1]} @LTP {ltp2} |"""
                                if j.get('apiplatform')=='zerodha':
                                    self.zerodhaOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(ltp1*100),'buysell':1,'booktype':1,'triggerprice':0,'token':int(self.tokenlist[0]),'ticker_code':self.tickerlist[0],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                                    self.zerodhaOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(ltp2*100),'buysell':1,'booktype':1,'triggerprice':0,'token':int(self.tokenlist[1]),'ticker_code':self.tickerlist[1],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                                elif j.get('apiplatform')=='test':
                                    self.testOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(ltp1*100),'buysell':1,'booktype':1,'triggerprice':0,'token':int(self.tokenlist[0]),'ticker_code':self.tickerlist[0],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                                    self.testOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(ltp2*100),'buysell':1,'booktype':1,'triggerprice':0,'token':int(self.tokenlist[1]),'ticker_code':self.tickerlist[1],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                                elif j.get('apiplatform')=='xts':
                                    self.xtsOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(ltp1*100),'buysell':1,'booktype':1,'triggerprice':0,'token':int(self.tokenlist[0]),'ticker_code':self.tickerlist[0],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                                    self.xtsOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(ltp2*100),'buysell':1,'booktype':1,'triggerprice':0,'token':int(self.tokenlist[1]),'ticker_code':self.tickerlist[1],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                                
                                elif j.get('apiplatform')=='fivepaisa':
                                    self.fivepaisaOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(ltp1*100),'buysell':1,'booktype':1,'triggerprice':0,'token':int(self.tokenlist[0]),'ticker_code':self.tickerlist[0],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                                    self.fivepaisaOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(ltp2*100),'buysell':1,'booktype':1,'triggerprice':0,'token':int(self.tokenlist[1]),'ticker_code':self.tickerlist[1],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                                
                                logging.warning(msg)
                                logging.warning(msg2)
                                self.logsQueue.send(json.dumps({"clientid":j.get('client'),"msg":str(msg)}))
                                self.logsQueue.send(json.dumps({"clientid":j.get('client'),"msg":str(msg2)}))

                                time.sleep(0.5)

                    print(sys._getframe().f_lineno, "Trading day closed, time is above stop_time")
                    break

            if (datetime.datetime.now().hour * 60 + datetime.datetime.now().minute) >= self.start_time:
                if time.time() >= self.last_time:
                    self.last_time = time.time() + self.schedule_interval
                    print("\n\n {} Run Count : Time - {} ".format(self.runcount, datetime.datetime.now()))
                    if self.runcount >= 0:
                        try:
                            self.run_trategy()
                        except Exception as e:
                            print("Run error", e)
                    self.runcount = self.runcount + 1
        

FractalClass()