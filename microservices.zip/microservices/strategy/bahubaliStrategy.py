from utilities import Utilities
import threading
from datetime import datetime
import time
import pandas as pd
import logging
import sysv_ipc
import json
class Strategy(Utilities):
    def __init__(self):
        super().__init__()
        # Run your code here
        print("MAC address is valid. Running the code...")
        try:
            self.logsQueue = sysv_ipc.MessageQueue(self.QKeys.get('logsQueue'),sysv_ipc.IPC_CREX)
        except Exception as e: 
            self.logsQueue = sysv_ipc.MessageQueue(self.QKeys.get('logsQueue'))

        try:
            self.zerodhaOMS = sysv_ipc.MessageQueue(self.QKeys.get('zerodhaOMS'),sysv_ipc.IPC_CREX)
        except Exception as e: 
            self.zerodhaOMS = sysv_ipc.MessageQueue(self.QKeys.get('zerodhaOMS'))

        try:
            self.testOMS = sysv_ipc.MessageQueue(self.QKeys.get('testOMS'),sysv_ipc.IPC_CREX)
        except Exception as e: 
            self.testOMS = sysv_ipc.MessageQueue(self.QKeys.get('testOMS'))

        try:
            self.xtsOMS = sysv_ipc.MessageQueue(self.QKeys.get('xtsOMS'),sysv_ipc.IPC_CREX)
        except Exception as e: 
            self.xtsOMS = sysv_ipc.MessageQueue(self.QKeys.get('xtsOMS'))

        try:
            self.fivepaisaOMS = sysv_ipc.MessageQueue(self.QKeys.get('fivepaisaOMS'),sysv_ipc.IPC_CREX)
        except Exception as e: 
            self.fivepaisaOMS = sysv_ipc.MessageQueue(self.QKeys.get('fivepaisaOMS'))

        try:
            self.strategyQueue = sysv_ipc.MessageQueue(self.QKeys.get('strategyQueue'),sysv_ipc.IPC_CREX)
        except Exception as e: 
            self.strategyQueue = sysv_ipc.MessageQueue(self.QKeys.get('strategyQueue'))
        
        self.ordersList={}
        self.ordercount=1

        # if not os.path.exists(f"""Logs/LOG_FILE_{str(datetime.now().strftime('%Y%m%d'))}.log"""):
        logging.basicConfig(filename=f"""Logs/LOG_FILE_{str(datetime.now().strftime('%Y%m%d'))}.log""", filemode='a',format='%(asctime)s - %(levelname)s - %(message)s')

        contractfilePath=self.baseDir+'store/contracts/nse_contractfile'+str(datetime.now().strftime('%Y%m%d'))+'.csv'
        self.contracts=pd.read_csv(contractfilePath)

        self.clientDetails={}
        # self.clientDetails=[{'strategyid': 25, 'algoname': 'test', 'exchange': 'NFO', 'segment': 'NFO-OPT', 'symbol': 'NIFTY BANK', 'expiry': '16Mar2023', 'contract_name': 'BANKNIFTY', 'qty': 50, 'status': True, 'strategytype': 'BAHUBALI', 'apiplatform': 'zerodha', 'client': 1, 'clientid': 1, 'username': 'jayesh', 'clienttype': 'CLIENT', 'real': 0}]
        
        # dbdata=self._forFetchQuery(f"""SELECT * FROM public."Strategy" ORDER BY id ASC """)
        # # print(dbdata)
        # if dbdata:
        #     self.clientDetails=dbdata

        tempfile=pd.read_csv('bahubaliInputFile.csv')
        dayname=datetime.today().strftime("%A")
        self.closeTime='14:57:00'
        if dayname=='Thursday':
            self.closeTime='15:29:00'

        tempfile=tempfile.loc[tempfile['dayname']==dayname]
        tempfile['tradetime']=tempfile['tradetime'].apply(lambda x : str(datetime.strptime(x,'%H:%M:%S').time()) )
        self.tempfile=tempfile.fillna(0).to_dict('records')
        self.UserInput={}
        for i in self.tempfile:
            self.UserInput[i.get('tradetime')]=i

        # print(self.UserInput)
        self.flag=1
        threading.Thread(target=self.strategyQueueReader).start()
        threading.Thread(target=self.checkStrategy).start()
        threading.Thread(target=self.TradeMatchingQueueReader).start()


    def checkStrategy(self):
        while self.flag>0:
            # print(len(list(self.clientDetails.values())))
            # for k in list(self.clientDetails.values()):
            #     print(k.get('strategyid'))
            #     print("***********")
            currentTime=datetime.now().strftime('%H:%M:%S')
            # print(currentTime)
            if self.UserInput.get(currentTime)!=None:
                temp=self.UserInput.get(currentTime)
                if temp.get('tradeflag')==0:
                    tradetime=temp.get('tradetime')
                    multiplier=float(temp.get('value'))
                    
                    for j in list(self.clientDetails.values()):
                        indicesToken=self.contracts.loc[(self.contracts['exchange']=='NSE') & (self.contracts['segment']=='CM') & (self.contracts['contract_name']==j.get('symbol')) ]['tokenid2'].values[0]
                        print('indicesToken',indicesToken)
                        res=self.read_ticker(indicesToken)
                        # res=self.read_ticker(176093919241)
                        # print(res)
                        ltp=int(res.get('ltp'))
                        strikeprice=self.getStrikePrice(ltp,j.get('symbol'))
                        print(strikeprice)
                        if strikeprice!=0:
                            if j.get('status'):
                                print(j)
                                temp=self.contracts.loc[(self.contracts['exchange']==j.get('exchange')) & (self.contracts['segment']==j.get('segment')) & (self.contracts['contract_name']==j.get('contract_name')) & (self.contracts['strike_price']==strikeprice) & (self.contracts['expiry']==j.get('expiry'))  ]
                                # print(temp.to_dict('records'))
                                if temp.shape[0]==2:
                                    for i in temp.to_dict('records'):
                                        legltp=int(self.read_ticker(i.get('tokenid2')).get('bid0'))
                                        print(legltp)
                                        sl=self.roundPrice(int(legltp*multiplier))
                                        msg=f"""BAHUBALI | Trigger Time {datetime.now()} | broker name {j.get('apiplatform')} |strategyid {j.get('strategyid')} | Client {j.get('client')} | Expiry {j.get('expiry')} | Qty {j.get('qty')} UserInput Time {tradetime} And Value {multiplier} | LTP {ltp} | Taking SELL Position In {i.get('token')} {i.get('ticker_code')} @LTP {legltp} |  SL @Price {sl} |"""
                                        if j.get('apiplatform')=='zerodha':
                                            self.zerodhaOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':legltp,'buysell':2,'booktype':1,'triggerprice':0,'token':i.get('token'),'ticker_code':i.get('ticker_code'),'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                                            orderno=int(self.ordercount)
                                            self.ordersList[orderno]={'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':sl,'buysell':1,'booktype':1,'triggerprice':0,'token':i.get('token'),'tokenid2':i.get('tokenid2'),'ticker_code':i.get('ticker_code'),'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}
                                        elif j.get('apiplatform')=='test':
                                            self.testOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':legltp,'buysell':2,'booktype':1,'triggerprice':0,'token':i.get('token'),'ticker_code':i.get('ticker_code'),'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                                            orderno=int(self.ordercount)
                                            self.ordersList[orderno]={'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':sl,'buysell':1,'booktype':1,'triggerprice':0,'token':i.get('token'),'tokenid2':i.get('tokenid2'),'ticker_code':i.get('ticker_code'),'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}
                                        elif j.get('apiplatform')=='xts':
                                            self.xtsOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':legltp,'buysell':2,'booktype':1,'triggerprice':0,'token':i.get('token'),'ticker_code':i.get('ticker_code'),'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                                            orderno=int(self.ordercount)
                                            self.ordersList[orderno]={'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':sl,'buysell':1,'booktype':1,'triggerprice':0,'token':i.get('token'),'tokenid2':i.get('tokenid2'),'ticker_code':i.get('ticker_code'),'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}
                                        elif j.get('apiplatform')=='fivepaisa':
                                            self.fivepaisaOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':legltp,'buysell':2,'booktype':1,'triggerprice':0,'token':i.get('token'),'ticker_code':i.get('ticker_code'),'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                                            orderno=int(self.ordercount)
                                            self.ordersList[orderno]={'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':sl,'buysell':1,'booktype':1,'triggerprice':0,'token':i.get('token'),'tokenid2':i.get('tokenid2'),'ticker_code':i.get('ticker_code'),'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}
                                        
                                        logging.warning(msg)
                                        self.logsQueue.send(json.dumps({"clientid":j.get('client'),"msg":str(msg)}))
                                        self.ordercount=self.ordercount+1

                                    logging.warning(f"""BAHUBALI | {datetime.now()} Cycle completed !!!""")
                                    self.logsQueue.send(json.dumps({"clientid":j.get('client'),"msg":str(msg)}))

                                else:
                                    print("couldn't find strike_price price ",temp)
                                    msg=f"""{datetime.now()} couldn't find strike_price price  !!!"""
                                    logging.error(msg)
                                    self.logsQueue.send(json.dumps({"clientid":j.get('client'),"msg":str(msg)}))

                            self.UserInput[currentTime]['tradeflag']=1
                        else:
                            print("ltp is 0")
                            msg=f"""{datetime.now()}  ltp is 0 !!!"""
                            logging.error(msg)
                            self.logsQueue.send(json.dumps({"clientid":j.get('client'),"msg":str(msg)}))

    def getStrikePrice(self,ltp,contract_name):
        strike1=0
        try:
            if contract_name=='NIFTY 50':
                print("**********",ltp)
                c=ltp%10000
                # print(c)
                d=5000-c
                # print(d)

                if d<2500:
                    strike1=ltp+d
                else:
                    strike1=ltp-c

                print(contract_name,"strike_price===",int(strike1))

            elif contract_name=='NIFTY BANK':

                print("**********",ltp)
                c=ltp%10000
                # print(c)
                d=10000-c
                # print(d)

                if d<5000:
                    strike1=ltp+d
                else:
                    strike1=ltp-c

                print(contract_name,"strike_price===",int(strike1))

            return strike1

        except Exception as e:
            print("error on getStrikePrice")
            return strike1

    def TradeMatchingQueueReader(self):
        try:
            while self.flag > 0:
                currentTime=datetime.now().strftime('%H:%M:%S')
                for i in list(self.ordersList.keys()):
                    try:
                        temp=self.ordersList.get(i)
                        item=temp.get('data')
                        # print(item)
                        # if item.get('status'):
                        res=self.read_ticker(item.get('tokenid2'))
                        ask=res.get('ask0')
                        # print(ask,item.get('sl'))
                        if ask >=item.get('price'):
                            temp['data']['price']=ask
                            msg=f"""BAHUBALI | Trigger Time {datetime.now()} | brokername {item.get('apiplatform')} | Client {item.get('clientid')} | Expiry {item.get('expiry')} | Qty {item.get('qty')} Taking BUY Position In {item.get('token')} {item.get('ticker_code')} @ask {ask} |"""

                            if item.get('apiplatform')=='zerodha':
                                self.zerodhaOMS.send(json.dumps(temp))
                            if item.get('apiplatform')=='test':
                                self.testOMS.send(json.dumps(temp))
                            if item.get('apiplatform')=='xts':
                                self.xtsOMS.send(json.dumps(temp))
                            if item.get('apiplatform')=='fivepaisa':
                                self.fivepaisaOMS.send(json.dumps(temp))

                            logging.warning(msg)
                            self.logsQueue.send(json.dumps({"clientid":item.get('clientid'),"msg":str(msg)}))

                            self.ordersList.pop(i,None)
                        if currentTime==self.closeTime:
                            temp['data']['price']=ask
                            item=temp.get('data')
                            msg=f"""BAHUBALI | Trigger Time {datetime.now()} | broker name {item.get('apiplatform')} | Client {item.get('clientid')} | Expiry {item.get('expiry')} | Qty {item.get('qty')} CLOSE ALL OPEN Position In {item.get('token')} {item.get('ticker_code')} @ask {ask} |"""
                            if item.get('apiplatform')=='zerodha':
                                self.zerodhaOMS.send(json.dumps(temp))
                            if item.get('apiplatform')=='test':
                                self.testOMS.send(json.dumps(temp))
                            if item.get('apiplatform')=='xts':
                                self.xtsOMS.send(json.dumps(temp))
                            if item.get('apiplatform')=='fivepaisa':
                                self.fivepaisaOMS.send(json.dumps(temp))
                            logging.warning(msg)
                            self.logsQueue.send(json.dumps({"clientid":item.get('clientid'),"msg":str(msg)}))
                            self.ordersList.pop(i,None)
                            time.sleep(0.5)
                    except Exception as e:
                        print("Error on reading ticker dataa",e)
        except Exception as e:
            print("[Error] in (self,TradeMatchingQueueReader) msg: ", str(e))

    def closePositionOnStopStrategy(self,data):
        try:
            for i in list(self.ordersList.keys()):
                try:
                    item=self.ordersList.get(i)
                    if item.get('data').get('strategyid')==data.get('strategyid') and item.get('data').get('clientid')==data.get('clientid'):
                        res=self.read_ticker(item.get('data').get('tokenid2'))
                        ask=res.get('ask0')
                        item['data']['price']=ask

                        msg=f"""BAHUBALI | Trigger Time {datetime.now()} | Strategyid {str(item.get('data').get('strategyid'))} |broker name {item.get('data').get('apiplatform')} | Client {item.get('data').get('clientid')} | Expiry {item.get('data').get('expiry')} | Qty {item.get('data').get('qty')} CLOSE Position on Stop Strategy In {item.get('data').get('token')} {item.get('data').get('ticker_code')} @ask {ask} |"""
                        print("item.get('data')*******************************",item)
                        if item.get('data').get('apiplatform')=='zerodha':
                            self.zerodhaOMS.send(json.dumps(item))
                        if item.get('data').get('apiplatform')=='test':
                            self.testOMS.send(json.dumps(item))
                        if item.get('data').get('apiplatform')=='xts':
                            self.xtsOMS.send(json.dumps(item))
                        if item.get('data').get('apiplatform')=='fivepaisa':
                            self.fivepaisaOMS.send(json.dumps(item))

                        logging.warning(msg)
                        self.logsQueue.send(json.dumps({"clientid":item.get('data').get('clientid'),"msg":str(msg)}))
                        self.ordersList.pop(i,None)
                        time.sleep(0.5)

                except Exception as e:
                    print(i)
                    print("Error on closePositionOnStopStrategy reading ticker dataa",e)

        except Exception as e:
            print("[Error] in (self,closePositionOnStopStrategy) msg: ", str(e))

    def strategyQueueReader(self):
        while self.flag > 0:
            print("StrategyQueueReader Waiting for Data  ............. ")
            try:
                item = self.strategyQueue.receive()
                print(item)
                item = json.loads(item[0])
                if item.get('event')=='add':
                    item=item.get('data')
                    self.clientDetails[item['strategyid']]=item
                    print("add strategyQueueReader... ",item)
                
                if item.get('event')=='delete':
                    item=item.get('data')
                    self.clientDetails.pop(item['strategyid'],None)
                    print(self.clientDetails)
                    print("delete strategyQueueReader... ",item['strategyid'],item['clientid'])

                if item.get('event')=='start':
                    item=item.get('data')
                    print(item)
                    if self.clientDetails.get(item['strategyid']):
                        self.clientDetails[item['strategyid']]['status']=item.get('status')
                        self.clientDetails[item['strategyid']]['real']=item.get('real')
                    else:
                        print("append***-")
                        self.clientDetails[item['strategyid']]=item

                    print(self.clientDetails)
                    print("start strategyQueueReader... ",item['strategyid'],item['clientid'])

                if item.get('event')=='stop':
                    item=item.get('data')
                    print(item)
                    if self.clientDetails.get(item['strategyid']):
                        self.clientDetails[item['strategyid']]['status']=item.get('status')
                        self.clientDetails[item['strategyid']]['real']=item.get('real')

                    # print(self.clientDetails)
                    
                    if item.get('status')==False:
                        self.closePositionOnStopStrategy(item)
                        print("close open position ",item['strategyid'])

                    print("stop strategyQueueReader... ",item['strategyid'],item['clientid'])

               
                if item.get('event')=='update':
                    item=item.get('data')
                    print(item)
                    if self.clientDetails.get(item['strategyid']):
                        self.clientDetails[item['strategyid']]['qty']=item.get('qty')
                    print(self.clientDetails)
                    print("update strategyQueueReader... ",item['strategyid'],item['clientid'])

            except Exception as e:
                print("[Error] in (self,strategyQueueReader) msg: ", str(e))

Strategy()