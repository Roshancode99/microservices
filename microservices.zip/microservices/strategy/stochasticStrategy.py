from utilities import Utilities
import datetime
import pandas as pd
import sys
import os
import time,json
import logging
import sysv_ipc
import threading,traceback
import numpy as np
from py5paisa import FivePaisaClient



class stochasticClass(Utilities):
    def __init__(self):
        super().__init__()
        self.flag=1
        self.buy_pos_flag=dict()
        self.stochasticvalue=0
        self.tokenid2list=[]
        self.tokenlist=[]
        self.tickerlist=[]
        self.strikeprice=0

        self.logsQueue = sysv_ipc.MessageQueue(self.QKeys.get('logsQueue'),sysv_ipc.IPC_CREAT)
        self.zerodhaOMS = sysv_ipc.MessageQueue(self.QKeys.get('zerodhaOMS'),sysv_ipc.IPC_CREAT)
        self.testOMS = sysv_ipc.MessageQueue(self.QKeys.get('testOMS'),sysv_ipc.IPC_CREAT)
        self.xtsOMS = sysv_ipc.MessageQueue(self.QKeys.get('xtsOMS'),sysv_ipc.IPC_CREAT)
        self.fivepaisaOMS = sysv_ipc.MessageQueue(self.QKeys.get('fivepaisaOMS'),sysv_ipc.IPC_CREAT)
        self.strategyQueue = sysv_ipc.MessageQueue(self.QKeys.get('strategyStochasticQueue'),sysv_ipc.IPC_CREAT)


        logging.basicConfig(filename=f"""Logs/stochastic_LOG_FILE_{str(datetime.datetime.now().strftime('%Y%m%d'))}.log""", filemode='a',format='%(asctime)s - %(levelname)s - %(message)s')

        contractfilePath=self.baseDir+'store/contracts/nse_contractfile'+str(datetime.datetime.now().strftime('%Y%m%d'))+'.csv'
        self.contracts=pd.read_csv(contractfilePath)

        self.clientDetails={}
        self.runcount = 0
        self.stochastic_factor = 3
        self.stochastic_period = 14
        self.candlesize = '5m'
        self.ordersList={}
        self.ordercount=1
        self.buy_flag=0
        self.start_time = int(9) * 60 + int(20)  # specify in int (hr) and int (min) foramte
        self.end_time = int(15) * 60 + int(25)  # do not place fresh order
        self.stop_time = int(15) * 60 + int(25)  # square off all open positions
        self.last_time = self.start_time
        self.schedule_interval = 300  # run at every 5 min


        apidetails=self.jsonConfigfile.get('fivepaisa_api')
        self.fivepaisa=FivePaisaClient(cred=apidetails.get('cred'))
        self.fivepaisa.access_token = apidetails.get('access_token')
        self.fivepaisa.Jwt_token = apidetails.get('access_token')
        self.fivepaisa.client_code = apidetails.get('client_code')

        threading.Thread(target=self.strategyQueueReader).start()
        threading.Thread(target=self.run).start()
        threading.Thread(target=self.checkingForClosePosition).start()

    def getStrikePrice(self,ltp,contract_name):
        strike1=0
        try:
            if contract_name=='NIFTY 50':
                print("**********",ltp)
                c=ltp%10000
                d=5000-c
                if d<2500:
                    strike1=ltp+d
                else:
                    strike1=ltp-c
                print(contract_name,"strike_price===",int(strike1))
            elif contract_name=='NIFTY BANK':
                print("**********",ltp)
                c=ltp%10000
                d=10000-c
                if d<5000:
                    strike1=ltp+d
                else:
                    strike1=ltp-c
                print(contract_name,"strike_price===",int(strike1))
            return strike1

        except Exception as e:
            print("error on getStrikePrice")
            return strike1

    def gethistoricaldata(self,token):
        print(token)
        enddate = datetime.datetime.today()
        startdate = enddate - datetime.timedelta(14)
        df = pd.DataFrame(columns=['datetime', 'open', 'high', 'low', 'close', 'volume'])
        try:
            data1 = self.fivepaisa.historical_data('N','C',token[0],self.candlesize,startdate,enddate)
            df = pd.DataFrame.from_dict(data1, orient='columns', dtype=None)
            df.columns = df.columns.str.lower()

            if not df.empty:
                df = df[['datetime', 'open', 'high', 'low', 'close', 'volume']]
                df['datetime'] = pd.to_datetime(df['datetime'])
                df=self.stochastic_indicator(df)
                df.loc[df['Signal']=='Buy','buy']='CE'
                df.loc[df['Signal']=='Sell','buy']='PE'
                df.loc[df['Signal']=='','buy']='NAN'
                df.to_csv('stochastic_file.csv')
                print(df.tail(10))
                df=df.tail(1)
                
        except Exception as e:
            print("Error in gethistoricaldata", token, e)
        return df.reset_index()
    
    def stochastic_indicator(self,data):
        data = self.calculate_stochastic_oscillator(data, k_period=self.stochastic_period, d_period=self.stochastic_factor)
        data['Signal'] = self.generate_signals(data)
        data=data.tail(1)
        print(data)
        return data

    def calculate_stochastic_oscillator(self,data, k_period, d_period):
        data['Lowest_Low'] = data['low'].rolling(window=k_period).min()
        data['Highest_High'] = data['high'].rolling(window=k_period).max()
        data['%K'] = ((data['close'] - data['Lowest_Low']) / (data['Highest_High'] - data['Lowest_Low'])) * 100
        data['%D'] = data['%K'].rolling(window=d_period).mean()
        
        return data

    def generate_signals(self,data):
        signals = []
        for i in range(len(data)):
            if data['%K'][i] > data['%D'][i] and data['%K'][i - 1] <= data['%D'][i - 1]:
                signals.append('Buy')
            elif data['%K'][i] < data['%D'][i] and data['%K'][i - 1] >= data['%D'][i - 1]:
                signals.append('Sell')
            else:
                signals.append('')
        return signals

    def stochastic_indicator(self,data):
        # Calculate the %K and %D values for the stochastic oscillator
        data['lowest_low'] = data['low'].rolling(self.stochastic_period).min()
        data['highest_high'] = data['high'].rolling(self.stochastic_period).max()
        data['%K'] = ((data['close'] - data['lowest_low']) / (data['highest_high'] - data['lowest_low'])) * 100
        data['%D'] = data['%K'].rolling(self.stochastic_factor).mean()
        # Define buy and sell signals based on the stochastic oscillator
        data['buy_signal'] = (data['%K'] > data['%D']) & (data['%K'] < 20)
        data['sell_signal'] = (data['%K'] < data['%D']) & (data['%K'] > 80)
        # Execute the strategy
        positions = []
        for i in range(len(data)):
            if data['buy_signal'].iloc[i]:
                positions.append(1)  # Buy
            elif data['sell_signal'].iloc[i]:
                positions.append(-1)  # Sell
            else:
                positions.append(0)  # Hold
        data['position'] = positions
        data['returns'] = data['position'].shift(1) * data['close'].pct_change()
        data['cumulative_returns'] = (1 + data['returns']).cumprod()
        return data

    def checkStrategy(self):

        for j in list(self.clientDetails.values()):
            try:
                if j.get('status'):
                    print("*******************",self.buy_pos_flag.get(str(j.get('client'))))
                    if self.buy_pos_flag.get(str(j.get('client')))==0 or self.buy_pos_flag.get(str(j.get('client')))==None:
                        indicesToken=self.contracts.loc[(self.contracts['exchange']=='NSE') & (self.contracts['segment']=='CM') & (self.contracts['contract_name']==j.get('symbol')) ]['tokenid2'].values[0]
                        res=self.read_ticker(indicesToken)
                        ltp=res.get('ltp')
                        strikeprice=self.getStrikePrice(ltp,j.get('symbol'))

                        token=self.contracts.loc[(self.contracts['exchange']=='NSE') & (self.contracts['segment']=='CM') & (self.contracts['contract_name']==j.get('symbol')) ]['token'].values[0]
                        df=self.gethistoricaldata([str(token)])

                        if j.get('symbol')=='NIFTY 50':
                            df=self.gethistoricaldata(['999920000'])
                        elif j.get('symbol')=='NIFTY BANK':
                            df=self.gethistoricaldata(['999920005'])

                        if df.shape[0]:
                            print(df['buy'].values[0])

                            temp=self.contracts.loc[(self.contracts['exchange']==j.get('exchange')) & (self.contracts['segment']==j.get('segment')) & (self.contracts['contract_name']==j.get('contract_name')) & (self.contracts['strike_price']==strikeprice) & (self.contracts['expiry']==j.get('expiry')) & (self.contracts['option_type']=='CE')]

                            temp=self.contracts.loc[(self.contracts['exchange']==j.get('exchange')) & (self.contracts['segment']==j.get('segment')) & (self.contracts['contract_name']==j.get('contract_name')) & (self.contracts['strike_price']==strikeprice) & (self.contracts['expiry']==j.get('expiry')) & (self.contracts['option_type']==df['buy'].values[0])]
                            print(temp)
                            if temp.shape[0]==1:
                                print(df)
                                print(temp)
                                print(j)
                                ask1=int(self.read_ticker(temp['tokenid2'].values[0]).get('ask0'))/100
                                sl=ask1-j.get('sl')
                                profit_val=ask1+j.get('profit_val')
                                orderno=int(self.ordercount)

                                if j.get('apiplatform')=='zerodha':
                                    self.zerodhaOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(ask1*100),'buysell':1,'booktype':1,'triggerprice':0,'token':int(temp['token'].values[0]),'ticker_code':temp['ticker_code'].values[0],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                                    self.ordersList[orderno]={'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(sl*100),'profit_val':int(profit_val*100),'buysell':2,'booktype':1,'triggerprice':0,'token':int(temp['token'].values[0]),'tokenid2':int(temp['tokenid2'].values[0]),'ticker_code':temp['ticker_code'].values[0],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}
                                elif j.get('apiplatform')=='test':
                                    self.testOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(ask1*100),'buysell':1,'booktype':1,'triggerprice':0,'token':int(temp['token'].values[0]),'ticker_code':temp['ticker_code'].values[0],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                                    self.ordersList[orderno]={'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(sl*100),'profit_val':int(profit_val*100),'buysell':2,'booktype':1,'triggerprice':0,'token':int(temp['token'].values[0]),'tokenid2':int(temp['tokenid2'].values[0]),'ticker_code':temp['ticker_code'].values[0],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}
                                elif j.get('apiplatform')=='xts':
                                    self.xtsOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(ask1*100),'buysell':1,'booktype':1,'triggerprice':0,'token':int(temp['token'].values[0]),'ticker_code':temp['ticker_code'].values[0],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                                    self.ordersList[orderno]={'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(sl*100),'profit_val':int(profit_val*100),'buysell':2,'booktype':1,'triggerprice':0,'token':int(temp['token'].values[0]),'tokenid2':int(temp['tokenid2'].values[0]),'ticker_code':temp['ticker_code'].values[0],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}
                                elif j.get('apiplatform')=='fivepaisa':
                                    self.fivepaisaOMS.send(json.dumps({'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(ask1*100),'buysell':1,'booktype':1,'triggerprice':0,'token':int(temp['token'].values[0]),'ticker_code':temp['ticker_code'].values[0],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                                    self.ordersList[orderno]={'event':"create",'data':{'apiplatform':j.get('apiplatform'),'clientid':j.get('client'),'qty':j.get('qty'),'price':int(sl*100),'profit_val':int(profit_val*100),'buysell':2,'booktype':1,'triggerprice':0,'token':int(temp['token'].values[0]),'tokenid2':int(temp['tokenid2'].values[0]),'ticker_code':temp['ticker_code'].values[0],'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}
                                self.ordercount=self.ordercount+1
                                print(df['buy'].values[0],"buy in nearest strike price in " ,temp['ticker_code'].values[0],int(ask1*100),'profit',int(profit_val*100),'SL',int(sl*100))
                                self.buy_pos_flag[str(j.get('client'))]=1
            except Exception as e:
                print(traceback.format_exc(e))

    def checkingForClosePosition(self):
        while self.flag>0:
            for i in list(self.ordersList.keys()):
                try:
                    temp=self.ordersList.get(i)
                    item=temp.get('data')
                    res=self.read_ticker(item.get('tokenid2'))
                    bid=res.get('bid0')
                    print(bid,item.get('price'),item.get('profit_val'))

                    if bid <=item.get('price'):
                        print("sl hittt",bid,item.get('price'))
                        temp['data']['price']=bid
                        print(json.dumps(temp))

                        if item.get('apiplatform')=='zerodha':
                            self.zerodhaOMS.send(json.dumps(temp))
                        elif item.get('apiplatform')=='test':
                            self.testOMS.send(json.dumps(temp))
                        elif item.get('apiplatform')=='xts':
                            self.xtsOMS.send(json.dumps(temp))
                        elif item.get('apiplatform')=='fivepaisa':
                            self.fivepaisaOMS.send(json.dumps(temp))

                        self.ordersList.pop(i,None)
                        self.buy_pos_flag[str(item.get('clientid'))]=0

                    elif bid >=item.get('profit_val'):
                        print("profit hittt",bid,item.get('profit_val'))
                        temp['data']['price']=bid
                        print(json.dumps(temp))
                        if item.get('apiplatform')=='zerodha':
                            self.zerodhaOMS.send(json.dumps(temp))
                        elif item.get('apiplatform')=='test':
                            self.testOMS.send(json.dumps(temp))
                        elif item.get('apiplatform')=='xts':
                            self.xtsOMS.send(json.dumps(temp))
                        elif item.get('apiplatform')=='fivepaisa':
                            self.fivepaisaOMS.send(json.dumps(temp))
                        self.ordersList.pop(i,None)
                        self.buy_pos_flag[str(item.get('clientid'))]=0


                except Exception as e:
                    print(temp)
                    print("Error on checkingForClosePosition",e)

    def run(self):
        while self.flag>0:
            if (datetime.datetime.now().hour * 60 + datetime.datetime.now().minute) >= self.end_time:
                if (datetime.datetime.now().hour * 60 + datetime.datetime.now().minute) >= self.stop_time:
                    print("checking for Auto close @ ",datetime.datetime.now())
                    for i in list(self.ordersList.keys()):
                        try:
                            temp=self.ordersList.get(i)
                            item=temp.get('data')
                            res=self.read_ticker(item.get('tokenid2'))
                            bid=res.get('bid0')
                            temp['data']['price']=bid
                            print(json.dumps(temp))
                            if item.get('apiplatform')=='zerodha':
                                self.zerodhaOMS.send(json.dumps(temp))
                            elif item.get('apiplatform')=='test':
                                self.testOMS.send(json.dumps(temp))
                            elif item.get('apiplatform')=='xts':
                                self.xtsOMS.send(json.dumps(temp))
                            elif item.get('apiplatform')=='fivepaisa':
                                self.fivepaisaOMS.send(json.dumps(temp))
                            self.ordersList.pop(i,None)
                        except Exception as e:
                            print(temp)
                            print("Error on Auto close",e)

                    print(sys._getframe().f_lineno, "Trading day closed, time is above stop_time")
                    break

            if (datetime.datetime.now().hour * 60 + datetime.datetime.now().minute) >= self.start_time:
                if time.time() >= self.last_time:
                    self.last_time = time.time() + self.schedule_interval
                    print("\n\n {} Run Count : Time - {} ".format(self.runcount, datetime.datetime.now()))
                    if self.runcount >= 0:
                        try:
                            self.checkStrategy()
                        except Exception as e:
                            print("Run error", e)
                    self.runcount = self.runcount + 1

    def strategyQueueReader(self):
        print("StrategyQueueReader Waiting for Data  ............. ")
        while self.flag > 0:
            try:
                item = self.strategyQueue.receive()
                # print(item)
                item = json.loads(item[0])
                print(item)
                data = item.get('data')
                event = data.get('event')  # Retrieve the 'event' key from the dictionary
                print("event", event)

                if event == 'add':
                    data = item.get('data')
                    self.clientDetails[data['strategyid']] = data
                    print("----------------Added Operations ------------------ ")
                    print("Added Strategy :", data)

                if event == 'delete': 
                    strategy_id = data.get('strategyid')  
                    print("----------------Deleted Operations ------------------ ")
                    if strategy_id in self.clientDetails:
                        self.clientDetails.pop(strategy_id)
                        print("Deleted Strategy with ID:", strategy_id)
                    else:
                        print("Strategy with ID", strategy_id, "not found in clientDetails")
            
                if event == 'start':
                    data = item.get('data')
                    print("----------------Strated Operations ------------------ ")
          
                    if self.clientDetails.get(data['strategyid']):
                        self.clientDetails[data['strategyid']]['status'] = data.get('status')
                        self.clientDetails[data['strategyid']]['real'] = data.get('real')
                        self.clientDetails[data['strategyid']]['profit_val'] = 3.5
                        self.clientDetails[data['strategyid']]['sl'] = 2
                    else:
                        print("append***-")
                        self.clientDetails[data['strategyid']] = data
                        self.clientDetails[data['strategyid']]['profit_val'] = 3.5
                        self.clientDetails[data['strategyid']]['sl'] = 2

                    print(self.clientDetails)
                    
                    print("Completed the  StrategyQueueReader  : ", data['strategyid'], data['client'])

                if event == 'stop':
                    data = item.get('data')
                    print("----------------Stop Operations ------------------ ")
                    print(data)
                    if self.clientDetails.get(data['strategyid']):
                        self.clientDetails[data['strategyid']]['status'] = data.get('status')
                        self.clientDetails[data['strategyid']]['real'] = data.get('real')
                        self.clientDetails[data['strategyid']]['profit_val'] = 3.5
                        self.clientDetails[data['strategyid']]['sl'] = 2

                        if data.get('status') == False:
                            self.clientDetails[data['strategyid']]['profit_val'] = 3.5
                            self.clientDetails[data['strategyid']]['sl'] = 2
                            self.closePositionOnStopStrategy(data)
                            print("close open position ", data['strategyid'])

                    print("stop strategyQueueReader... ", data['strategyid'], data['client'])
               
                if event == 'update':
                    item=item.get('data')
                    print("----------------Updated Operations ------------------ ")
                   
                    if self.clientDetails.get(item['strategyid']):
                        self.clientDetails[item['strategyid']]['qty']=item.get('qty')
                    print(self.clientDetails)
                    
                    print("Updated StrategyQueueReader... ",item['strategyid'],item['client'])

            except Exception as e:
                # print(traceback.format_exc())
                print("[Error] in (self,strategyQueueReader) msg: ", str(e))

    def closePositionOnStopStrategy(self,data):
        try:
            for i in list(self.ordersList.keys()):
                try:
                    temp=self.ordersList.get(i)
                    item=temp.get('data')
                    if item.get('strategyid')== data.get('strategyid') and item.get('client')== data.get('clientid'):
                        res=self.read_ticker(item.get('tokenid2'))
                        bid=res.get('bid0')
                        temp['data']['price']=bid
                        print(json.dumps(temp))
                        if item.get('apiplatform')=='zerodha':
                            self.zerodhaOMS.send(json.dumps(temp))
                        elif item.get('apiplatform')=='test':
                            self.testOMS.send(json.dumps(temp))
                        elif item.get('apiplatform')=='xts':
                            self.xtsOMS.send(json.dumps(temp))
                        elif item.get('apiplatform')=='fivepaisa':
                            self.fivepaisaOMS.send(json.dumps(temp))
                        self.ordersList.pop(i,None)
                except Exception as e:
                    print(temp)
                    print("Error on checkingForClosePosition",e)

        except Exception as e:
            print("[Error] in (self,closePositionOnStopStrategy) msg: ", str(e))  

stochasticClass()