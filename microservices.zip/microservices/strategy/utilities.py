from dbconnection import DBCon
import json,os,csv
import datetime
import pandas as pd
from kiteconnect import KiteConnect,KiteTicker
import SharedArray
import re
import uuid

class Utilities(DBCon):
    
    def __init__(self):
        super().__init__()
        self.license_mac_address='02:35:e3:43:a3:6e'
        self.license_expire='OCTOBER312023'
        self.baseDir = self.jsonConfigfile.get('settings').get('baseDir')+'/'
        self.QKeys = self.jsonConfigfile.get('queueKey')

        self.contractSettings = self.jsonConfigfile.get("contractSettings")
        self.listOfExchanges=self.contractSettings.keys()
        self.contract=dict()
        try:
            for ind,t in enumerate(self.listOfExchanges):
                temp=json.load(open(self.baseDir+'store/contracts/nse_contractfile'+str(datetime.datetime.now().strftime('%Y%m%d'))+'.json'))
                self.contract[t] =  temp
        except FileNotFoundError as e:
            print(e)
        
        tempTransCode=self._forFetchQuery(f"""SELECT "Code","Status" FROM public."TransactionCode";""")
        tempTransCode=pd.DataFrame(tempTransCode)
        self.transCode = dict(zip(tempTransCode.code, tempTransCode.status))
            
        # self.API_KEY=self.jsonConfigfile.get('api').get('api_key')
        # self.API_SECRET=self.jsonConfigfile.get('api').get('api_secret')
        # self.ACCESS_TOKEN=self.jsonConfigfile.get('api').get('access_token')
        # self.kite = KiteConnect(api_key=self.API_KEY)
        # self.kite.set_access_token(self.ACCESS_TOKEN)

        # self.kws = KiteTicker(self.API_KEY, self.ACCESS_TOKEN)

    def concateDecToDec(self,a):
        try:
            exchange = int(str(a)[:2])
            token = int(str(a)[2:])
            # print("concatedecttodec====",exchange,token)
            hex_exchange = hex(exchange).replace("0x","")
            hex_token = hex(token).replace("0x","")
            decimalNo = hex_exchange+'0'*(8-(len(hex_token)))+hex_token
            return int(decimalNo,16)
        except Exception as e:
            print('error on concateDecToDec',e)
            return 0

    def concateContractDetails(self,data,token):
        # print("heyyyy")
        try:
            tokenid2=self.concateDecToDec(token)
            # print(token,tokenid2)
            status=self.transCode.get(data['transcode'])
            if status:
                data['status']=status
            else:
                data['status']='NONE'

            contra=dict()
            for i in self.listOfExchanges:
                if self.contract[i].get(str(tokenid2)):
                    contra=self.contract[i].get(str(tokenid2))
                    break
            if contra:
                data['security_type']=contra['security_type']
                data['option_type']=contra['option_type']
                data['strike_price']=contra['strike_price']
                data['symbol']=contra['contract_name']
                data['segment']=contra['segment']
                data['expirydate']=contra['expiry']
                data['tokenid2']=contra['tokenid2']
                data['divider']=contra['divider']
                data['multiplier']=contra['multiplier']
                data['currency']=contra['currency']
            else:
                data['security_type']=''
                data['option_type']=''
                data['strike_price']=0
                data['symbol']=''
                data['segment']=''
                data['expirydate']=''
                data['tokenid2']=0
                data['divider']=0
                data['multiplier']=0
                data['currency']=''

            return data
        except Exception as e:
            print('error on concateContractDetails',e)
            return {}
        
    def lower_dict(self,d):
        return dict((k.lower(), v) for k, v in d.items()) 

    
    def jsonWriter(self, data, folder, pkcolumnName):
        path = f"""{self.baseDir}clients/{str(data.get('client'))}"""
        try:
            os.makedirs(path+'/'+folder)
        except FileExistsError as e:
            pass

        try:
            filedirect = os.path.join(f"""{path}/{folder}/{folder}{data.get('entrydatetime')[:10].replace('-','')}.json""")
            with open(filedirect, "w+") as file:
                temp = {}
                temp[data.get(pkcolumnName)] = data
                json.dump(temp, file)
        except Exception as e:
            print(e)

    # @timer
    def jsonToCSV(self, data, folder, pkcolumnName):
        path = f"""{self.baseDir}clients/{str(data.get('client'))}"""

        try:
            os.makedirs(path+'/'+folder)
        except FileExistsError as e:
            pass

        filedirect = os.path.join(f"""{path}/{folder}/{folder}{data.get('entrydatetime')[:10].replace('-','')}.csv""")

        if not os.path.exists(filedirect):
            try:
                data_file = open(filedirect, 'a', newline='')
                csv_writer = csv.writer(data_file)
                header = data.keys()
                csv_writer.writerow(header)
                data_file.close()
            except Exception as e:
                pass

        
        data_file = open(filedirect, 'a', newline='')
        # create the csv writer object
        csv_writer = csv.writer(data_file)

        csv_writer.writerow(data.values())
        data_file.close()

    def read_ticker(self,token): 
        # print(self.baseDir[1:][:-1])
        # print(f"file://{self.baseDir[1:][:-1]}{self.jsonConfigfile.get('settings').get('fileLocation').get('tickers')}{token}")
        message = {}        
        try :
            sa = SharedArray.attach(f"file://{self.baseDir[:-1]}{self.jsonConfigfile.get('settings').get('fileLocation').get('tickers')}{token}",ro=True)
            message = dict( (value,sa[i]) for i,value in enumerate(self.jsonConfigfile.get('marketdata').get("packet")))
            # print(message)
            return message
        except Exception as e :
            print("Error on read_ticker",e)
            return {'ltp':0}

    def writerPID(self,pid,exename,user='jayesh'):
        path = f"""{self.baseDir}settings/pid.json"""
        print("call",path)
        try:
            if not os.path.exists(path):
                print("file not exist..")
                with open(path, "w+") as file:
                    json.dump({}, file)
            filedirect = os.path.join(f"""{path}""")
            with open(filedirect, "r+") as file:
                temp = json.load(file)
                temp[str(user)+"_"+str(exename)] = str(pid) 
                file.seek(0)
                json.dump(temp, file)
                print("temp",type(temp),temp)
        except Exception as e:
            print("Error on writerPID",e)


    def roundPrice(self,num,multiple=10):
        return round(num / multiple) * multiple
    
    def is_valid_mac(self):
        mac_address = ':'.join(re.findall('..', '%012x' % uuid.getnode()))
        print(self.license_mac_address)
        # mac_pattern = r'^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$'
        # return re.match(mac_pattern, mac_address) is not None
        return True if mac_address==self.license_mac_address else False
    
    def is_valid_expiry(self):
        current_month = (datetime.datetime.now().strftime("%B%Y")).upper()
        print(self.license_expire)
        # mac_pattern = r'^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$'
        # return re.match(mac_pattern, mac_address) is not None
        return True if current_month==self.license_expire.upper() else False
            
# Utilities()