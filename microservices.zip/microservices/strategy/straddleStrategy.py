from utilities import Utilities
import threading
from datetime import datetime
import time
import pandas as pd
import logging
import sysv_ipc
import json
import os
import traceback
class Strategy(Utilities):
    def __init__(self):
        super().__init__()
        

        try:
            self.zerodhaOMS = sysv_ipc.MessageQueue(self.QKeys.get('zerodhaOMS'),sysv_ipc.IPC_CREX)
        except Exception as e: 
            self.zerodhaOMS = sysv_ipc.MessageQueue(self.QKeys.get('zerodhaOMS'))

        try:
            self.strategyQueue = sysv_ipc.MessageQueue(self.QKeys.get('strategyStraddleQueue'),sysv_ipc.IPC_CREX)
        except Exception as e: 
            self.strategyQueue = sysv_ipc.MessageQueue(self.QKeys.get('strategyStraddleQueue'))

            

        self.ordersList={}

        # if not os.path.exists(f"""Logs/LOG_FILE_{str(datetime.now().strftime('%Y%m%d'))}.log"""):
        logging.basicConfig(filename=f"""Logs/STRADDLE_LOG_FILE_{str(datetime.now().strftime('%Y%m%d'))}.log""", filemode='a',format='%(asctime)s - %(levelname)s - %(message)s')

        contractfilePath=self.baseDir+'store/contracts/zerodha_contractfile'+str(datetime.now().strftime('%Y%m%d'))+'.csv'
        self.contracts=pd.read_csv(contractfilePath)
        self.clientDetails=[]
        # self.clientDetails=[{'strategyid': 102, 'algoname': 'test', 'exchange': 'NFO', 'segment': 'NFO-OPT', 'symbol': 'NIFTY BANK', 'expiry': '06Apr2023', 
        #                      'contract_name': 'BANKNIFTY', 'qty': 50, 'cymcleno': 2, 'starttime': '09:15:00', 'squareofftime': '15:15:00', 'period': 5, 
        #                      'status': True, 'cmbslflag': False, 'cmbsl': 10, 'cmbtrsl': 5, 'cmbreenteryflag': True, 'cmbreentery': 10, 'cmbsellflag': 0, 
        #                      'cmbwaitntrade': 10, 'trslin': 'PERCENT', 'reenteryin': 'PERCENT', 'waitntradein': 'PERCENT', 'waitntradeflag': False, 'waitntradeinterval': 3, 
        #                      'l1': {'option_type': 'CE', 'strikediff': 100, 'sl': 0.5, 'trsl': 5, 'reenteryflag': True, 'reentery': 10, 'sellflag': 0, 'waitntrade': 10},
        #                      'l2': {'option_type': 'PE', 'strikediff': -100, 'sl': 0.5, 'trsl': 5, 'reenteryflag': True, 'reentery': 10, 'sellflag': 0, 'waitntrade': 10},
        #                        'strategytype': 'STRADDLE', 'apiplatform': 'zerodha', 'client': 1, 'clientid': 1, 'username': 'jayesh', 'clienttype': 'CLIENT', 'real': 0}
        #                        ]
   

        self.flag=1
        threading.Thread(target=self.strategyQueueReader).start()
        threading.Thread(target=self.checkStrategy).start()
        threading.Thread(target=self.zerodhaTradeMatchingQueueReader).start()


    def checkStrategy(self):
        while self.flag>0:
            currentTime=datetime.now().strftime('%H:%M:%S')
            # print(currentTime)
            for j in self.clientDetails:
                indicesToken=self.contracts.loc[(self.contracts['exchange']=='NSE') & (self.contracts['segment']=='INDICES') & (self.contracts['contract_name']==j.get('symbol')) ]['tokenid2'].values[0]
                # print('indicesToken',indicesToken)
                res=self.read_ticker(indicesToken)
                # res=self.read_ticker(176093919241)
                # print(res)
                ltp=int(res.get('ltp'))
                strikeprice=self.getStrikePrice(ltp)
                strikeprice=strikeprice
                l1=j.get('l1')
                l1['strikeprice']=strikeprice+(l1.get('strikediff')*100)
                l2=j.get('l2')
                l2['strikeprice']=strikeprice+(l2.get('strikediff')*100)

                # print(int(currentTime.replace(':','')),int(j.get('starttime').split('.')[0].replace(':','')))
                if j.get('status'):
                    if int(currentTime.replace(':','')) >=int(j.get('starttime').split('.')[0].replace(':','')):
                        # print(l1['strikeprice'],l2['strikeprice'])
                        temp=self.contracts.loc[(self.contracts['exchange']==j.get('exchange')) & (self.contracts['segment']==j.get('segment')) & (self.contracts['contract_name']==j.get('contract_name')) & (((self.contracts['strike_price']==l1.get('strikeprice')) & (self.contracts['option_type']==l1.get('option_type'))) | ((self.contracts['strike_price']==l2.get('strikeprice')) & (self.contracts['option_type']==l2.get('option_type')))) & (self.contracts['expiry']==j.get('expiry'))  ]
                        # print(temp.to_dict('records'))
                        if temp.shape[0]==2:
                            for i in temp.to_dict('records'):
                                # for leg 1 sell 
                                if i.get('option_type')=='CE':
                                    if l1.get('sellflag')==0:
                                        legltp=int(self.read_ticker(i.get('tokenid2')).get('bid0'))
                                        sl=legltp+(legltp*(l1.get('sl')/100))
                                        print("l1===============sell",legltp,sl,l1.get('sl'))

                                        if j.get('apiplatform')=='zerodha':
                                            msg=f"""Trigger Time {datetime.now()} |strategyid {j.get('strategyid')} | Client {j.get('client')} | Expiry {j.get('expiry')} | Qty {j.get('qty')} | NIFTYBANK LTP {ltp} | Taking SELL Position In {i.get('token')} {i.get('ticker_code')} @LTP {legltp} |  SL @Price {sl} |"""
                                            self.zerodhaOMS.send(json.dumps({'event':"create",'data':{'real':j.get('real'),'clientid':j.get('client'),'qty':j.get('qty'),'price':legltp,'buysell':2,'booktype':1,'triggerprice':0,'token':i.get('token'),'ticker_code':i.get('ticker_code'),'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                                            orderno=int(datetime.timestamp(datetime.now())*1000)
                                            self.ordersList[orderno]={'event':"create",'data':{'real':j.get('real'),'clientid':j.get('client'),'qty':j.get('qty'),'price':sl,'buysell':1,'booktype':1,'triggerprice':0,'token':i.get('token'),'tokenid2':i.get('tokenid2'),'ticker_code':i.get('ticker_code'),'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}
                                            logging.warning(msg)
                                            j['l1']['sellflag']=1
                                            j['l1']['token']=i.get('token')
                                if i.get('option_type')=='PE':
                                    # for leg 2 sell
                                    if l2.get('sellflag')==0:
                                        legltp=int(self.read_ticker(i.get('tokenid2')).get('bid0'))
                                        sl=legltp+(legltp*(l2.get('sl')/100))
                                        print("l2===============sell",legltp,sl,l2.get('sl'))

                                        if j.get('apiplatform')=='zerodha':
                                            msg=f"""Trigger Time {datetime.now()} |strategyid {j.get('strategyid')} | Client {j.get('client')} | Expiry {j.get('expiry')} | Qty {j.get('qty')} | NIFTYBANK LTP {ltp} | Taking SELL Position In {i.get('token')} {i.get('ticker_code')} @LTP {legltp} |  SL @Price {sl} |"""
                                            self.zerodhaOMS.send(json.dumps({'event':"create",'data':{'real':j.get('real'),'clientid':j.get('client'),'qty':j.get('qty'),'price':legltp,'buysell':2,'booktype':1,'triggerprice':0,'token':i.get('token'),'ticker_code':i.get('ticker_code'),'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}))
                                            orderno=int(datetime.timestamp(datetime.now())*1000)
                                            self.ordersList[orderno]={'event':"create",'data':{'real':j.get('real'),'clientid':j.get('client'),'qty':j.get('qty'),'price':sl,'buysell':1,'booktype':1,'triggerprice':0,'token':i.get('token'),'tokenid2':i.get('tokenid2'),'ticker_code':i.get('ticker_code'),'segment':j.get('segment'),'exchange':j.get('exchange'),'strategyid':j.get('strategyid')}}
                                            logging.warning(msg)
                                            j['l2']['sellflag']=1
                                            j['l2']['token']=i.get('token')



                        else:
                            print("couldn't find strike_price price ")
                            logging.error(f"""{datetime.now()} couldn't find strike_price price  !!!""")
               
    def getStrikePrice(self,ltp):
        strike1=0
        try:
            # print("**********",ltp)
            c=ltp%10000
            # print(c)
            d=10000-c
            # print(d)

            if d<5000:
                strike1=ltp+d
            else:
                strike1=ltp-c

            # print("strike_price===",int(strike1))
            return strike1

        except Exception as e:
            print("error on getStrikePrice")
            return strike1

    def zerodhaTradeMatchingQueueReader(self):
        try:
            while self.flag > 0:
                currentTime=datetime.now().strftime('%H:%M:%S')
                for i in list(self.ordersList.keys()):
                    try:
                        temp=self.ordersList.get(i)
                        item=temp.get('data')
                        res=self.read_ticker(item.get('tokenid2'))
                        ask=res.get('ask0')
                        # print(ask,item.get('sl'))
                        if ask >=item.get('price'):
                            msg=f"""Trigger Time {datetime.now()} | Client {item.get('clientid')} | Expiry {item.get('expiry')} | Qty {item.get('qty')} Taking BUY Position In {item.get('token')} {item.get('ticker_code')} @ask {ask} |"""
                            logging.warning(msg)

                            self.zerodhaOMS.send(json.dumps(temp))
                            self.ordersList.pop(i,None)
                            for j in self.clientDetails:
                                print(j.get('l1').get('sellflag'),j.get('l2').get('sellflag'))

                                if (j.get('clientid') ==item.get('clientid')) and (j.get('strategyid') ==item.get('strategyid')) and (j.get('l1').get('token')==item.get('token')):
                                    j['l1']['sellflag']=3
                                    print("l1 BUY",j['l1']['sellflag'])
                                if (j.get('clientid') ==item.get('clientid')) and (j.get('strategyid') ==item.get('strategyid')) and (j.get('l2').get('token')==item.get('token')):
                                    j['l2']['sellflag']=3
                                    print("l2 BUY",j['l2']['sellflag'])


                                if (j.get('l1').get('sellflag')==3) and (j.get('l2').get('sellflag')==3):
                                    if j['cymcleno']>0:
                                        print(j['cymcleno'])
                                        j['cymcleno']=j['cymcleno']-1
                                        logging.warning(f"""{datetime.now()} Cycle rem cycle no {str(j['cymcleno'])}!!!""")
                                    else:
                                        j['status']=False
                                        print(f"""{datetime.now()} Cycle completed!!!""")
                                        logging.warning(f"""{datetime.now()} Cycle completed!!!""")




                        if currentTime=='15:29:00':
                            temp.get('data')['price']=ask
                            item=temp.get('data')
                            msg=f"""Trigger Time {datetime.now()} | Client {item.get('clientid')} | Expiry {item.get('expiry')} | Qty {item.get('qty')} CLOSE ALL OPEN Position In {item.get('token')} {item.get('ticker_code')} @ask {ask} |"""
                            logging.warning(msg)
                            self.zerodhaOMS.send(json.dumps(temp))
                            self.ordersList.pop(i,None)
                    except Exception as e:
                        print("Error on zerodhaTradeMatchingQueueReader dataa",traceback.format_exc(e))
        except Exception as e:
            print("[Error] in (self,zerodhaTradeMatchingQueueReader) msg: ", str(e))

    def strategyQueueReader(self):
        while self.flag > 0:
            print("Waiting for Message Queuee..............")
            try:
                item = self.strategyQueue.receive()
                print(item)
                item = json.loads(item[0])
                if item.get('event')=='add':
                    item=item.get('data')
                    if item.get('strategytype')=='STRADDLE':
                        self.clientDetails.append(item)
                        # data=item.get('data')
                        # self.writeTradebook(data)  # i have confused here ...
                        print("add strategyQueueReader... ",item)
                
                if item.get('event')=='delete':
                    item=item.get('data')
                    for index,i in enumerate(self.clientDetails):
                        if i['strategyid']==item['strategyid'] and i['client']==item['clientid']:
                            self.clientDetails.pop(index)
                    print(self.clientDetails)
                    print("delete strategyQueueReader... ",item['strategyid'],item['clientid'])

                if item.get('event')=='start' or item.get('event')=='stop':
                    item=item.get('data')
                    print(item)
                    if self.clientDetails:
                        for index,i in enumerate(self.clientDetails):
                            if i['strategyid']==item['strategyid'] and i['client']==item['clientid']:
                                self.clientDetails[index]['status']=item.get('status')
                                self.clientDetails[index]['real']=item.get('real')

                            # else:
                            #     print("append***-")
                            #     self.clientDetails.append(item)
                    else:
                        print("append***-")
                        self.clientDetails.append(item)
                    print(self.clientDetails)
                    print("start or stop strategyQueueReader... ",item['strategyid'],item['clientid'])

               
                if item.get('event')=='update':
                    item=item.get('data')
                    print(item)
                    for index,i in enumerate(self.clientDetails):
                        if i['strategyid']==item['strategyid'] and i['client']==item['clientid']:
                            self.clientDetails[index]['qty']=item.get('qty')
                            # self.clientDetails.append(item)
                    print(self.clientDetails)
                    print("update strategyQueueReader... ",item['strategyid'],item['clientid'])

            except Exception as e:
                # print(traceback.format_exc())
                print("[Error] in (self,strategyQueueReader) msg: ", str(e))
Strategy()