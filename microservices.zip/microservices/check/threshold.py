import socket
import json
import sysv_ipc
import threading

MESSAGE_QUEUE_KEY = 1234

try:
    message_queue = sysv_ipc.MessageQueue(MESSAGE_QUEUE_KEY, sysv_ipc.IPC_CREX)
    print("Message queue created successfully.")
except sysv_ipc.ExistentialError:
    message_queue = sysv_ipc.MessageQueue(MESSAGE_QUEUE_KEY)
    print("Message queue already exists.")
