import socket
import json
from ctypes import *
import sysv_ipc
import threading

MESSAGE_QUEUE_KEY = 1234

try:
    message_queue = sysv_ipc.MessageQueue(MESSAGE_QUEUE_KEY, sysv_ipc.IPC_CREX)
    print("Message queue created successfully.")
except sysv_ipc.ExistentialError:
    message_queue = sysv_ipc.MessageQueue(MESSAGE_QUEUE_KEY)
    print("Message queue already exists.")

class St_Mbp_Info(Structure):
    _pack_ = 1
    _fields_ = [("qty", c_int32),
                ("price", c_int32),
                ("order_count", c_uint16),
                ]

class Message_Structure(Structure):
    _pack_ = 1
    _fields_ = [("id", c_int32),
                ("highDpr", c_int32),
                ("lowDpr", c_int32),
                ("freezeQuan", c_int32),
                ("ltp", c_int32),
                ("ltq", c_int32),
                ("volume_traded_today", c_int32),
                ("highExecBand", c_int32),
                ("lowExecBand", c_int32),
                ("strikePrice", c_int32),
                ("expiryDate", c_int32),
                ("lotSize", c_int16),
                ("tickSize", c_int16),
                ("enabled", c_int16),
                ("flags", c_uint16),
                ("instrument_type", c_int16),
                ("option_type", c_uint16),
                ("bid_mbp", St_Mbp_Info*5),
                ("ask_mbp", St_Mbp_Info*5),
                ('symbol', c_char*11),
                ('instrument', c_char*26),
                ('open_interest', c_int32),
                ('netchangeindicator', c_char),
                ('netpricechangefromclosing', c_int32),
                ('averagetradeprice', c_int32),
                ('lasttradetime', c_int32),
                ('tradingstatus', c_int16),
                ('openprice', c_int32),
                ('closingprice', c_int32),
                ('highprice', c_int32),
                ('lowprice', c_int32)
                ]


MCAST_GRP = '226.1.1.1'
MCAST_PORT = 3333    # for fetching the fno nse
MCAST_PORT2 = 4444   # for fetching the fno data 

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
sock.bind((MCAST_GRP, MCAST_PORT))
mreq = socket.inet_aton(MCAST_GRP) + socket.inet_aton('127.0.0.1')

sock.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)

sock1 = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
sock1.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
sock1.bind((MCAST_GRP, MCAST_PORT2))
mreq1 = socket.inet_aton(MCAST_GRP) + socket.inet_aton('127.0.0.1')

sock1.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)

def SendData3333():
    while True:
        data, addr = sock.recvfrom(sizeof(Message_Structure))
        data_in = Message_Structure.from_buffer_copy(data)

        response_data = {
            "id": data_in.id,
            "bid_mbp_price": [entry.price for entry in data_in.bid_mbp],
            "ask_mbp_price": [entry.price for entry in data_in.ask_mbp],
            "ltp": data_in.ltp,
            "ltq": data_in.ltq,
            "volume_traded_today": data_in.highExecBand,
            "highExecBand": data_in.highExecBand,
            "lowExecBand": data_in.lowExecBand,
            "strikePrice": data_in.strikePrice,
            "expiryDate": data_in.expiryDate,
            "lotSize": data_in.lotSize,
            "tickSize": data_in.tickSize,
            "enabled": data_in.enabled,
            "flags": data_in.flags,
            "instrument_type": data_in.instrument_type,
            "option_type": data_in.option_type,
            # "symbol": data_in.symbol,
            # "instrument": data_in.instrument,
            "open_interest": data_in.open_interest,
            # "netchangeindicator": data_in.netchangeindicator,
            "netpricechangefromclosing": data_in.netpricechangefromclosing,
            "averagetradeprice": data_in.averagetradeprice,
            "lasttradetime": data_in.lasttradetime,
            "tradingstatus": data_in.tradingstatus,
            "openprice": data_in.openprice,
            "closingprice": data_in.closingprice,
            "highprice": data_in.highprice,
            "lowprice": data_in.lowprice,
        }
        response_json = json.dumps(response_data)
        print(response_json)
        message_queue.send(response_json)


def SendData4444():
    while True:
        data1, addr1 = sock1.recvfrom(sizeof(Message_Structure))
        data_in1 = Message_Structure.from_buffer_copy(data1)

        response_data1 = {
            "id": data_in1.id,
            "bid_mbp_price": [entry.price for entry in data_in1.bid_mbp],
            "ask_mbp_price": [entry.price for entry in data_in1.ask_mbp],
            "ltp": data_in1.ltp,
            "ltq": data_in1.ltq,
            "volume_traded_today": data_in1.highExecBand,
            "highExecBand": data_in1.highExecBand,
            "lowExecBand": data_in1.lowExecBand,
            "strikePrice": data_in1.strikePrice,
            "expiryDate": data_in1.expiryDate,
            "lotSize": data_in1.lotSize,
            "tickSize": data_in1.tickSize,
            "enabled": data_in1.enabled,
            "flags": data_in1.flags,
            "instrument_type": data_in1.instrument_type,
            "option_type": data_in1.option_type,
            # "symbol": data_in.symbol,
            # "instrument": data_in.instrument,
            "open_interest": data_in1.open_interest,
            # "netchangeindicator": data_in.netchangeindicator,
            "netpricechangefromclosing": data_in1.netpricechangefromclosing,
            "averagetradeprice": data_in1.averagetradeprice,
            "lasttradetime": data_in1.lasttradetime,
            "tradingstatus": data_in1.tradingstatus,
            "openprice": data_in1.openprice,
            "closingprice": data_in1.closingprice,
            "highprice": data_in1.highprice,
            "lowprice": data_in1.lowprice,
        }
        response_json1 = json.dumps(response_data1)
        print(response_json1)
        message_queue.send(response_json1)


def startThread():
    threading.Thread(target = SendData3333).start()
    threading.Thread(target = SendData4444).start()
    

startThread()