
import socket,time
import sys
from ctypes import *

class St_Mbp_Info(Structure):
    _pack_ = 1
    _fields_ = [("qty", c_int32),
                ("price", c_int32),# daily price range
                ("order_count", c_uint16),
                ]

class Message_Structure(Structure):
    _pack_ = 1
    _fields_ = [("id", c_int32),
                ("highDpr", c_int32),# daily price range
                ("lowDpr", c_int32),
                ("freezeQuan", c_int32),
                ("ltp", c_int32),
                ("ltq", c_int32),
                
                ("volume_traded_today", c_int32),
                ("highExecBand", c_int32),#?
                ("lowExecBand", c_int32),
                ("strikePrice", c_int32),
                ("expiryDate", c_int32),
                ("lotSize", c_int16),
                ("tickSize", c_int16),
                ("enabled", c_int16),

                ("flags", c_uint16),
                ("instrument_type", c_int16),
                ("option_type", c_uint16),
                ("bid_mbp", St_Mbp_Info*5),
                ("ask_mbp", St_Mbp_Info*5),
                ('symbol', c_char*11),
                ('instrument', c_char*26),
                ('open_interest', c_int32),

                ('netchangeindicator', c_char),
                ('netpricechangefromclosing', c_int32),
                ('averagetradeprice', c_int32),
                ('lasttradetime', c_int32),
                ('tradingstatus', c_int16),
                ('openprice', c_int32),
                ('closingprice', c_int32),
                ('highprice', c_int32),
                ('lowprice', c_int32) 
            
            ]



MCAST_GRP = '226.1.1.1'
# MCAST_PORT = 3333   # --> for fno

MCAST_PORT = 4444   # --> for nse

sock = socket.socket(socket.AF_INET,socket.SOCK_DGRAM,socket.IPPROTO_UDP)
sock.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
sock.bind((MCAST_GRP, MCAST_PORT))
# mreq = socket.inet_aton(MCAST_GRP) + socket.inet_aton('192.168.1.5')
# mreq = socket.inet_aton(MCAST_GRP) + socket.inet_aton('192.168.100.36')
# 127.0.0.1
mreq = socket.inet_aton(MCAST_GRP) + socket.inet_aton('127.0.0.1')

sock.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)

# sock.sendto(b'hi',(MCAST_GRP,MCAST_PORT))

while True:
        # print("Waiting for client...")
        # data,addr = sock.recvfrom(1024)         #receive data from client
        # print("Received Messages:",data," from",addr)
        data,addr = sock.recvfrom(sizeof(Message_Structure)) 
        # message = message[72:sys.getsizeof(message)]
        data_in = Message_Structure.from_buffer_copy(data)

       # if(data_in.id == 26009 or data_in.id == 26074 or data_in.id == 1333 or data_in.id == 54354 or data_in.id == 54355):
        print(data_in.id,data_in.bid_mbp[0].price,data_in.ask_mbp[0].price,data_in.ltp,data_in.ltq)
        if data_in.id == 81573:
            print("optionstrike matched")
            break
