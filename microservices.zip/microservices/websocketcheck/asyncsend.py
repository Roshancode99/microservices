import asyncio
import websockets
import socket
import json
from ctypes import *
import sysv_ipc

MESSAGE_QUEUE_KEY = 1234

try:
    message_queue = sysv_ipc.MessageQueue(MESSAGE_QUEUE_KEY, sysv_ipc.IPC_CREX)
    print("Message queue created successfully.")
except sysv_ipc.ExistentialError:
    message_queue = sysv_ipc.MessageQueue(MESSAGE_QUEUE_KEY)
    print("Message queue already exists.")
    
    
# Function to continuously emit data to connected clients

async def emit_data(websocket, path):
    while True:
        message, message_type = message_queue.receive()
        print(message.decode())
        await websocket.send(message.decode())

start_server = websockets.serve(emit_data, "localhost", 8765)  

asyncio.get_event_loop().run_until_complete(start_server)
asyncio.get_event_loop().run_forever()
