import pandas as pd
import os

class Madara():
    def __init__(self):
        self.roshanpath = "/home/centos/SeperateRoshan"
        self.contract = "contract.txt"
        self.output_directory = "/home/centos/SeperateRoshan/rms-be/microservices/check"
        
        contract_data = self.read_contract_data()
        
        if contract_data is not None:
            self.save_contract_data(contract_data)

    def read_contract_data(self):
        try:
            contract_file_path = os.path.join(self.roshanpath, self.contract)
            
            column_names = ['token', 'security_type', 'contract_name', 'expiry', 'strike_price', 
                            'option_type', 'permitted_to_trade', 'lot_size', 'tick_size', 'ticker_code']
            
            contract_data = pd.read_csv(contract_file_path, sep="|", low_memory=False, 
                                        usecols=[0, 2, 3, 6, 7, 8, 11, 31, 32, 53],
                                        names=column_names, skiprows=1)
            
            contract_data = contract_data[['token', 'security_type', 'ticker_code',
                                           'strike_price', 'option_type', 'permitted_to_trade',
                                           'lot_size', 'tick_size', 'expiry', 'contract_name']]
            
            return contract_data
        except Exception as e:
            print(f"Error reading contract data: {e}")
            return None
        
    def save_contract_data(self , contract_data):
        try:
            output_file_path = os.path.join(self.output_directory , "contract11.csv")
            contract_data.to_csv(output_file_path , index = False)
            print(f"Contract data  saved as CSV : {output_file_path}")
        except Exception as e:
            print(f"error saving the contract data : {e}")

madara = Madara()


