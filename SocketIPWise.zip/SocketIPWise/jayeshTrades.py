
import threading
import multiprocessing,json,time
import sys,os
from websocket import create_connection
from os.path import expanduser

import logging 
import SharedArray as sa
import time
import zmq,sys
from generalCon import generalCon
import datetime,signal,traceback
import threading,sysv_ipc
from generalCon import generalCon
from utils import resetJsonWriter,writerPID



generalSettingFile = sys.argv[1]
manualTradeSettings = sys.argv[2]


class jayeshTrades(generalCon):
    def __init__(self):
        super().__init__()
        self.flag = 1
        self.setGeneralConData(generalSettingFile)
        self.setTradingCodeData(manualTradeSettings)
        self.setTradingServerConData(generalSettingFile,'Jayesh')
        self.initializeQueue()

        # writerPID(self.baseDir,os.getpid(),'jayeshTrades','vishal')
        writerPID(self.baseDir,os.getpid(),'jayeshTrades',f"""source  /home/techteam/Vishal/myvenv/bin/activate\npython jayeshTrades.py /home/techteam/sharedMemory/settings/generalSettings.json /home/techteam/sharedMemory/settings/manualTradeSettings.json""",'vishal')


        

    def initializeQueue(self):
        try :
            self.sendJayeshTrades = sysv_ipc.MessageQueue(self.sendJayeshTradesNum,sysv_ipc.IPC_CREX)
        except Exception as e:     
            self.sendJayeshTrades = sysv_ipc.MessageQueue(self.sendJayeshTradesNum)   
        
        self.TradingQueueList = multiprocessing.Queue(self.tradingMaxsizeQueue)
        self.setInitialManualDic(self.TradingDic)
        self.websocketConnect()
        self.TrapAllSignals()



    def startJayeshThread(self):
        threading.Thread(target = self.receiveManualTrades).start()
        threading.Thread(target = self.sendManualTrades).start()
        threading.Thread(target = self.receiveManualTradesResponse).start()


    def setInitialManualDic(self,data):
        for i in data:
            self.TradingQueueList.put(data[i])


    def receiveManualTrades(self):
        while True:
            try:
                rawData = self.sendJayeshTrades.receive()
                data  = json.loads(rawData[0].decode())
                key = str(data['clientid'])+str(data['exchange'])
            
                print("receiveManualTrades",data)
                if(self.validateRequest_ID(key,data['exchange'])):

                    if data['event'] == 'create':
                        print("key",self.TradingIDDic)

                        if(key in self.TradingIDDic):
                            self.TradingIDDic[key] = self.TradingIDDic[key]+1
                        else:
                            self.TradingIDDic[key] = self.serverMapDetailsJson[str(data['exchange']).upper()]['request_id']
                        
                        data['request_id'] = self.TradingIDDic[key]
                    
                    else:
                        data['request_id'] = data['uidnum']
                    
                    print("JAYESH DATA-----------",self.TradingIDDic)
                    self.TradingDic[str(data['clientid'])+str(data['request_id'])] = data
                    self.TradingQueueList.put(data)

                else:
                    self.sendOrderErrorLogs(data)
                    print("request_id Exceed!!")
            except Exception as e:
                # traceback.print_exc()
                print("receiveManualTrades Exception ---",e)  



    def sendOrderErrorLogs(self,item):
            data = {"event": "ordererrorlogs","eventtime":datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f'), 
                "date": datetime.date.today().strftime("%Y%m%d"), "client": str(item.get('clientid')),"orderno": "1234","data":item}
            print(data)
            try:
                self.broadCastServiceCon.send(json.dumps(data))
            except Exception as e:
                self.websocketConnect()
                self.broadCastServiceCon.send(json.dumps(data))
                print("sendOrderErrorLogs Exception ----",e) 
                    

    def sendManualTrades(self):
        while self.flag > 0:
            try:
                QueueData = self.TradingQueueList.get()
                data = self.TradingDic[str(QueueData['clientid'])+str(QueueData['request_id'])]
                print("mt5TradeData",data,self.socket)
                self.socket.send_string(json.dumps(data))
            except Exception as e:
                print("sendManualTrades Exception--------",e) 


    def receiveManualTradesResponse(self):
        while self.flag > 0:
            try:
                message = self.socket.recv()
                data = json.loads(message)
                print(data)
                if(data['event'] == 'traderesponse'):
                    responseData = data['data']
                    transaction_code = responseData['transaction_code']
                    clientid = responseData['clientid']
                    request_id = responseData['request_id']

                    print(responseData['clientid'],responseData['request_id'],responseData['transaction_code'])

                    if((self.OMS_API_TRANS_CODES[str(transaction_code)] == "OMS_ORDER_CANCELLED"            #5555
                        or self.OMS_API_TRANS_CODES[str(transaction_code)] == "OMS_TRADE")                  #6666
                        or (self.OMS_API_TRANS_CODES[str(transaction_code)] == "OMS_REQ_REJ"                #7777
                        and self.TradingDic[str(clientid)+str(request_id)]['event']=='create')):
                            
                        self.TradingDic.pop(str(clientid)+str(request_id), None)
                        print("TradingDic Popup ------------",self.TradingDic,str(clientid)+str(request_id))

            except Exception as e:
                print("receiveManualTradesResponse",e)   
   

    def jsonWriter(self,data,filedirect,pkcolumnName):
        try:
            if not os.path.exists(filedirect):
                print("file not exist..")
                with open(filedirect, "w+") as file:
                    json.dump({}, file)

            with open(filedirect, "r+") as file:
                temp = json.load(file)
                temp[pkcolumnName] = data
                # print(temp)
                file.seek(0)
                json.dump(temp, file)

        except Exception as e:
            print("jsonWriter ==========",str(e))


    def systemBreak(self,signum,stack):
        print("systemBreak",signum,stack)
        try:
            for i in self.exchangeListJson['Jayesh']:
                Trades_filePath = str(self.baseDir)+str(self.tradingPath)+str(i)+'_Trades.json'
                TradesID_filePath = str(self.baseDir)+str(self.tradingPath)+str(i)+'_TradesID.json'

                print("systemBreak self.TradingDic",self.TradingDic)
                print("systemBreak self.TradingIDDic",self.TradingIDDic)

                if len(self.TradingDic) > 0:
                    for key, value in self.TradingDic.items():
                        if(value['exchange'] == i ):
                            self.jsonWriter(value,Trades_filePath,key)
                else:
                    print("inside else")
                    resetJsonWriter(Trades_filePath)

                print("length",len(self.TradingIDDic))
                if len(self.TradingIDDic) > 0:
                    for key, value in self.TradingIDDic.items():
                        print("key, value",key, value,i)

                        if i in key:
                            self.jsonWriter(value,TradesID_filePath,key)

            pid = os.getpid()
            os.system("kill -9 "+str(pid))
        except Exception as e:
            pid = os.getpid()
            os.system("kill -9 "+str(pid))
            print("systemBreak",e)


    def TrapAllSignals(self):
        # uncatchable = ['SIG_DFL','SIGSTOP','SIGKILL']
        skipSignal = ['SIGWINCH']

        for i in [x for x in dir(signal) if x.startswith("SIG")]:
            try:
                if getattr(signal,i):
                    if(not i in skipSignal):
                        signum = getattr(signal,i)
                        signal.signal(signum,self.systemBreak)
            except (OSError) as m: #OSError for Python3, RuntimeError for 2
                print ("Skipping {}",i)


    def validateRequest_ID(self,key,exchange):
        flag = True
        if(self.TradingIDDic.get(key)):
            serverMap_lastRequest_id = self.serverMapDetailsJson[str(exchange).upper()]['lastRequest_id']
            if(int(self.TradingIDDic[key]) >= int(serverMap_lastRequest_id)):
                flag = False
        return flag



# jayeshobj = jayeshTrades(generalSettingFile,manualTradeSettings)
jayeshobj = jayeshTrades()
jayeshobj.startJayeshThread()

