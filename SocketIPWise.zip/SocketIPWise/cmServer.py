# import SharedArray as sa
import threading
import multiprocessing,json,time
import sys,os
from websocket import create_connection
from os.path import expanduser

import logging 
import SharedArray as sa
import time
import zmq,sys
from CStruct import NSE_Message_Structure
from generalCon import generalCon
from datetime import date,datetime,timedelta
from utils import writerPID
import sysv_ipc
import traceback


"""Get Params From Input Ex : python pythonfileName.py FileName  """
generalSettingFile = sys.argv[1]
cmSettingFile = sys.argv[2]


class cmServer(generalCon) :

    def __init__(self):
        super().__init__()

        self.flag = 1
        self.tokenIDKeyMapDict = dict()
        self.printCounter = 0
        
        self.starttime = datetime.now()
                
        self.setGeneralConData(generalSettingFile)
        self.setServerConData(cmSettingFile)
        self.initializeQueue()

        # writerPID(self.baseDir,os.getpid(),'cmServer','vishal')

        # writerPID(self.baseDir,os.getpid(),'cmServer',f"""source  /home/techteam/Vishal/myvenv/bin/activate\npython cmServer.py /home/techteam/sharedMemory/settings/generalSettings.json /home/techteam/sharedMemory/settings/cmSettings.json""",'vishal')


    def initializeQueue(self):
        self.websocketConnect()
        self.getContractFile()

        
        try :
            self.BloombergparityQueue = sysv_ipc.MessageQueue(self.bloombergParityQueueNum,sysv_ipc.IPC_CREX)
        except Exception as e:     
            self.BloombergparityQueue = sysv_ipc.MessageQueue(self.bloombergParityQueueNum)

        try :
            self.AnalysisDataQueue = sysv_ipc.MessageQueue(self.AnalysisDataQueueNum,sysv_ipc.IPC_CREX)
        except Exception as e:     
            self.AnalysisDataQueue = sysv_ipc.MessageQueue(self.AnalysisDataQueueNum)

      
    def startThread(self):
        threading.Thread(target=self.broadCastData).start()
        threading.Thread(target=self.startTCPServer).start()
        

    def getContractFile(self):
        filePath =self.baseDir+self.bodPathPath+self.exchange.lower()+'_contractfile'+self.todayDate+'.csv'
        if(os.path.exists(filePath)):
            print(filePath)
            self.tokenIDKeyMapDict = self.getTokenIDKeyContractFile(filePath,self.exchange,self.segment)
            # print(self.tokenIDKeyMapDict )
        else:
            cur_date = datetime.strptime(self.todayDate, "%Y%m%d").date()
            pre_date = str(cur_date+ timedelta(days=-1)).replace('-','')
            self.todayDate = pre_date
            self.getContractFile()


   
    def saveBroadcast(self,item):
        msg = dict()
        try:
            tokenID2 = self.tokenIDKeyMapDict.get(item.id)
            if(tokenID2):
                tokenID2 = tokenID2.get('tokenID2')

            filePath = str(self.baseDir)+str(self.tickersPath)+str(tokenID2)

            if(os.path.exists(filePath) and (tokenID2 != None)):
                
                # if(item.id == "26009" or item.id == 26009):
                #     print("broadcast",str(item.ltp))

                # print("item.id",item.id,tokenID2,item.bid_mbp[0].price,item.ask_mbp[0].price)

                sharedTokenArray = sa.attach("file://"+filePath)
                sharedTokenArray[self.marketDataStruct.get('tokenid2')] = tokenID2
                sharedTokenArray[self.marketDataStruct.get('bid0')] = item.bid_mbp[0].price
                sharedTokenArray[self.marketDataStruct.get('bidqty0')] = item.bid_mbp[0].qty
                sharedTokenArray[self.marketDataStruct.get('ask0')] = item.ask_mbp[0].price
                sharedTokenArray[self.marketDataStruct.get('askqty0')] = item.ask_mbp[0].qty

                sharedTokenArray[self.marketDataStruct.get('bid1')] = item.bid_mbp[1].price
                sharedTokenArray[self.marketDataStruct.get('bidqty1')] = item.bid_mbp[1].qty
                sharedTokenArray[self.marketDataStruct.get('ask1')] = item.ask_mbp[1].price
                sharedTokenArray[self.marketDataStruct.get('askqty1')] = item.ask_mbp[1].qty

                sharedTokenArray[self.marketDataStruct.get('bid2')] = item.bid_mbp[2].price
                sharedTokenArray[self.marketDataStruct.get('bidqty2')] = item.bid_mbp[2].qty
                sharedTokenArray[self.marketDataStruct.get('ask2')] = item.ask_mbp[2].price
                sharedTokenArray[self.marketDataStruct.get('askqty2')] = item.ask_mbp[2].qty

                sharedTokenArray[self.marketDataStruct.get('bid3')] = item.bid_mbp[3].price
                sharedTokenArray[self.marketDataStruct.get('bidqty3')] = item.bid_mbp[3].qty
                sharedTokenArray[self.marketDataStruct.get('ask3')] = item.ask_mbp[3].price
                sharedTokenArray[self.marketDataStruct.get('askqty3')] = item.ask_mbp[3].qty

                sharedTokenArray[self.marketDataStruct.get('bid4')] = item.bid_mbp[4].price
                sharedTokenArray[self.marketDataStruct.get('bidqty4')] = item.bid_mbp[4].qty
                sharedTokenArray[self.marketDataStruct.get('ask4')] = item.ask_mbp[4].price
                sharedTokenArray[self.marketDataStruct.get('askqty4')] = item.ask_mbp[4].qty

                sharedTokenArray[self.marketDataStruct.get('ltp')] = item.ltp
                sharedTokenArray[self.marketDataStruct.get('ltq')] = item.ltq

                sharedTokenArray[self.marketDataStruct.get('vtt')] = item.volume_traded_today
                sharedTokenArray[self.marketDataStruct.get('openinterest')] = item.open_interest
                if(item.netchangeindicator == b'-'):
                    sharedTokenArray[self.marketDataStruct.get('netchangeindicator')] = 0
                else:
                    sharedTokenArray[self.marketDataStruct.get('netchangeindicator')] = 1

                sharedTokenArray[self.marketDataStruct.get('averagetradeprice')] = item.averagetradeprice
                sharedTokenArray[self.marketDataStruct.get('lasttradetime')] = item.lasttradetime
                sharedTokenArray[self.marketDataStruct.get('tradingstatus')] = item.tradingstatus

                sharedTokenArray[self.marketDataStruct.get('openprice')] = item.openprice
                sharedTokenArray[self.marketDataStruct.get('closingprice')] = item.closingprice
                sharedTokenArray[self.marketDataStruct.get('highprice')] = item.highprice
                sharedTokenArray[self.marketDataStruct.get('lowprice')] = item.lowprice


                """ delete a instance """
                del sharedTokenArray
                # print("saveBroadcast Saveee",str(tokenID2))

                msg = {"event":"broadcast","token":str(tokenID2) }
                # print(msg)
                return msg

        except Exception as e:
            print(traceback.print_exc())
            print("[Error] in (self,saveBroadcast) msg: ",str(e))   
            return msg


    def startTCPServer(self):
        print("server up and running!!!!") 
        while self.flag>0 :
            try :
                message = self.socket.recv()
                # print(message)
                message = message[72:sys.getsizeof(message)]
                # print("message size" ,sys.getsizeof( message))
                data_in = NSE_Message_Structure.from_buffer_copy(message)

                if(data_in.id == 26000 ):
                    print(data_in.id,data_in.bid_mbp[0].price,data_in.ask_mbp[0].price,data_in.ltp,data_in.lasttradetime,data_in.openprice)
                # print(data_in.id,data_in.symbol,data_in.bid_mbp.price,data_in.ask_mbp.price,data_in.ltp,data_in.ltq)

                self.broadCastQueueList.put(data_in)
            except Exception as e :
                # logging.basicConfig(filename=f"{self.logFileDir}/startTCPServer.log",  format='%(asctime)s %(message)s',  filemode='w')  
                # self.logger.error(str(e))
                print("[Error] in (self,startTCPServer) msg: ",str(e))  


    def broadCastData(self):
        try:    
            while  self.flag>0:
                item = self.broadCastQueueList.get()
                # print("before size ============",self.broadCastQueueList.qsize())
                endtime = datetime.now()

                # if((endtime-self.starttime).seconds > 1):
                self.starttime = datetime.now()

                result_df = self.BloombergData[self.BloombergData["TokenId"] == item.id]

                if(result_df.shape[0] > 0):
                    print(result_df)

                    divider = self.tokenIDKeyMapDict.get(item.id).get('divider')
                    # print(divider)

                    temp = result_df.to_dict('records')[0]
                    temp['bid'] = item.bid_mbp[0].price/divider
                    temp['ask'] = item.ask_mbp[0].price/divider
                    temp['ltp'] = item.ltp/divider
                    # print(temp)

                    self.BloombergparityQueue.send(json.dumps(temp))
                    # self.AnalysisDataQueue.send(json.dumps(temp))
             
                # print("*******************",(endtime-self.starttime).seconds)
                msg = self.saveBroadcast(item)
                

                if(msg):
                    try:
                        # print(msg)
                        self.broadCastServiceCon.send(json.dumps(msg))
                    except Exception as e:
                        self.websocketConnect()
                        self.broadCastServiceCon.send(json.dumps(msg))
                    
                    self.printCounter = self.printCounter + 1

                if(self.printCounter == 100):
                    # print(msg)
                    self.printCounter = 0
                # print("after size =========",self.broadCastQueueList.qsize())

        except Exception as e:
            print("[Error] in (self,broadCastData) msg: ",str(e))   


cmServerobj = cmServer()
cmServerobj.startThread()

