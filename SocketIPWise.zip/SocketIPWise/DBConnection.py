import pyodbc,os

class DBConnection:

    def __init__(self):
        pass

    def _dbConnection(self):
        conn=pyodbc.connect('Driver={/opt/microsoft/msodbcsql18/lib64/libmsodbcsql-18.2.so.1.1};'
                        'Server=192.168.25.36;'
                        'Database=RMS;'
                        'UID=sa;'
                        'PWD=Admin@4321;'
                        'TrustServerCertificate=yes;'
                        'Trusted_Connection=No;') 
        return conn

    # FOR EXECUTING DATA
    def _forFetchingData(self,sqlQuery): 
        data = []
        try :
            conn = self._dbConnection()    
            cursor = conn.cursor()  
            cursor.execute(sqlQuery)
            data = cursor.fetchall()      
            cursor.close()
            conn.close()
        except Exception as e :
            print("[Error] in (SQLDATA,forFetchingData) msg: ",str(e))   
        return data
     

    def _forInsertingData(self,sqlQuery):
        try :
            # print(sqlQuery)
            conn = self._dbConnection()
            conn.execute(sqlQuery)
            conn.commit()
            conn.close()
        except Exception as e :
            print("[Error] in (SQLDATA,forInsertingData) msg: ",str(e))   



            

