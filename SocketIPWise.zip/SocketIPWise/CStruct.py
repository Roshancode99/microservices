from ctypes import *

class St_Mbp_Info(Structure):
    _pack_ = 1
    _fields_ = [("qty", c_int32),
                ("price", c_int32),# daily price range
                ("order_count", c_uint16),
                ]

class NSE_Message_Structure(Structure):
    _pack_ = 1
    _fields_ = [("id", c_int32),
                ("highDpr", c_int32),# daily price range
                ("lowDpr", c_int32),
                ("freezeQuan", c_int32),
                ("ltp", c_int32),
                ("ltq", c_int32),
                
                ("volume_traded_today", c_int32),
                ("highExecBand", c_int32),#?
                ("lowExecBand", c_int32),
                ("strikePrice", c_int32),
                ("expiryDate", c_int32),
                ("lotSize", c_int16),
                ("tickSize", c_int16),
                ("enabled", c_int16),

                ("flags", c_uint16),
                ("instrument_type", c_int16),
                ("option_type", c_uint16),
                ("bid_mbp", St_Mbp_Info*5),
                ("ask_mbp", St_Mbp_Info*5),
                ('symbol', c_char*11),
                ('instrument', c_char*26),
                ('open_interest', c_int32),

                ('netchangeindicator', c_char),
                ('netpricechangefromclosing', c_int32),
                ('averagetradeprice', c_int32),
                ('lasttradetime', c_int32),
                ('tradingstatus', c_int16),
                ('openprice', c_int32),
                ('closingprice', c_int32),
                ('highprice', c_int32),
                ('lowprice', c_int32) 
            
            ]



                
class SGX_Message_Structure(Structure):
    _pack_ = 1
    _fields_ = [
                ("id", c_int32),
                ("highDpr", c_int32),# daily price range
                ("lowDpr", c_int32),
                ("freezeQuan", c_int32),
                ("ltp", c_int32),
                ("ltq", c_int32),
                ("volume_traded_today", c_int32),
                ("highExecBand", c_int32),#?
                ("lowExecBand", c_int32),
                ("strikePrice", c_int32),
                ("expiryDate", c_int32),
                ("lotSize", c_int16),
                ("tickSize", c_int16),
                ("enabled", c_int16),
                ("flags", c_uint16),
                ("instrument_type", c_int16),
                ("option_type", c_uint16),
                ("bid_mbp", St_Mbp_Info),
                ("ask_mbp", St_Mbp_Info),
                ('symbol', c_char*11),
                ('instrument', c_char*26),
                ('open_interest', c_int32),
                
                # ('netchangeindicator', c_char),
                # ('averagetradeprice', c_int32),
                # ('lasttradetime', c_int32),
                # ('tradingstatus', c_int16),
                # ('openprice', c_int32),
                # ('closingprice', c_int32),
                # ('highprice', c_int32),
                # ('lowprice', c_int32)
            ]


class CLIENT_IDENTIFIER_Structure(Structure):
    _pack_ = 1
    _fields_ = [
                ("strategy_id", c_char),
                ("client_id", c_int32 ),
                ("request_id", c_int32 )
            ]

print("CLIENT_IDENTIFIER_Structure",sizeof(CLIENT_IDENTIFIER_Structure))
              
class ORDER_FLAGS_Structure(Structure):
    _pack_ = 1
    _fields_ = [
                ("order_type", c_bool*4), #1 limit 2 ioc   0001 0010
                ("order_side",  c_bool*2), #1 buy 2 sell 01  10
                ("product_type",  c_bool*3), #1 market 2 limit // 001 010 price_type
                ("pro_client",  c_bool*2), #1 client 2 pro // 01 10
                ("reserved", c_bool*21) 
            ]

# class NewToken_Structure(Structure):
#     _pack_ = 1
#     _fields_ = [
#                 ("token",  c_int32), #1 2 -last digit
#                 ("exchange", c_int32), #1 1-2 
#             ]

# print("NewToken_Structure",sizeof(NewToken_Structure))

# 11 71296

# 11680 

# B00011680 HEX

# 47244711552 DEC

class UIHeader_Structure(Structure):
    _pack_=1
    _fields_=[
        ("message_code", c_uint32),
        ("component_id", c_uint32),
        ("message_length", c_uint32),
        ("interface_id", c_uint32),
        ("timestamp", c_uint32),
    ]


print("UIHeader_Structure",sizeof(UIHeader_Structure))

              
class OMS_API_BODY_Structure(Structure):
    _pack_ = 1
    _fields_ = [
                ("product_id_", c_uint64*3),
                ("price_", c_int32*3),# daily price range
                ("quantity_", c_int32*3),
                ("flags_", c_int32*3),
                ("exchange_order_id", c_uint64),
                ("exchange_error_code", c_int32),
                ("exchange_response_code", c_int32),
                ("client_id", c_int32),#?
                ("oms_id", c_int32),
                ("algo_id", c_int32),
                ("exchange_fill_id", c_int32),
                ("token1_status", c_uint16 )        #Mine
          
                ]


print("OMS_API_BODY_Structure",sizeof(OMS_API_BODY_Structure))

class OMS_API_HEADER_Structure(Structure):
    _pack_ = 1
    _fields_ = [
                ("transaction_code", c_int32),
                ("uid_", CLIENT_IDENTIFIER_Structure),# daily price range struct
                ("error_code",  c_int32),
                ("reason_code",  c_int32),
                ("trigger_timestamp", c_uint64) ,
                ("event_timestamp", c_uint64) ,
                ("exchange_timestamp", c_uint64) 

            ]

print("OMS_API_HEADER_Structure",sizeof(OMS_API_HEADER_Structure))


class OMS_TRANSACTION_Structure(Structure):
    _pack_ = 1
    _fields_ = [
                ("uihdr_", UIHeader_Structure),
                ("hdr_", OMS_API_HEADER_Structure),
                ("packet_", OMS_API_BODY_Structure )
            ]

print("OMS_TRANSACTION_Structure",sizeof(OMS_TRANSACTION_Structure))


class Strategy_Param_Structure(Structure):
    _pack_ = 1

    _fields_ = [
                ("uihdr_", UIHeader_Structure),
                ("client_id", c_int32 ),            #Mine
                ("strategy_id", c_int32 ),          #Mine
                ("strategy_type", c_int32 ),        #Mine
                ("strategymode", c_int32 ),  
                                                    #Mine
                ("token1", c_uint64 ),              #Mine
                ("token2", c_uint64 ),              #Mine
                ("token3", c_uint64 ),              #Mine
                ("token4", c_uint64 ),              #Mine

                ("buylive", c_int64 ),
                ("selllive", c_int64 ),
                ("buyspread", c_int64 ),            #Mine
                ("sellspread", c_int64 ),           #Mine

                ("status",  c_char*20 ),            #Mine
                # ("RatioNsetoSgx", c_int32 ),      #Mine
                ("tlots", c_int32 ),                #Mine
                ("nlots", c_int32 ),                #Mine
                ("tradedlots", c_int32 ),

                ("buyavg", c_uint64 ),          
                ("sellavg", c_uint64 ),

                ("buytargetavg", c_uint64 ),
                ("selltargetavg", c_uint64 ),

                ("avgdisparity", c_uint64 ),
                ("pnl", c_uint64 ),

                ("token1qty", c_int32 ),
                ("token2qty", c_int32 ),
                ("token3qty", c_int32 ),
                ("token4qty", c_int32 ),

                ("tc", c_int32 ),
                ("usdinr", c_int32 ),
                ("strategy_name", c_char*50 ),

                ("token1_status", c_uint16 ),        #Mine
                ("token2_status", c_uint16 ),        #Mine
                ("token3_status", c_uint16 ),        #Mine
                ("token4_status", c_uint16 ),        #Mine

                # ("BuyQtyNSE", c_int32 ),
                # ("SellQtyNSE", c_int32 ),

                # ("BuyQtySGX", c_int32 ),
                # ("SellQtySGX", c_int32 ),
                # ("ATPBuyNse", c_int32 ),
                # ("ATPSellNse", c_int32 ),
                # ("ATPBuySGX", c_int32 ),
                # ("ATPSellSGX", c_int32 ),
                # ("Token3", c_int32 ),
                # ("Token4", c_int32 ),
                # ("StrategyType", c_int32 ),


                # ("BuyQty3", c_int32 ),
                # ("SellQty3", c_int32 ),
                # ("BuyQty4", c_int32 ),
                # ("SellQty4", c_int32 ),
                # ("ATPBuy3", c_int32 ),
                # ("ATPSell3", c_int32 ),
                # ("ATPBuy4", c_int32 ),
                # ("ATPSell4", c_int32 ),

        ]

# print("OMS_TRANSACTION_Structure",sizeof(OMS_TRANSACTION_Structure))



# struct __attribute__ ((packed)) StrategyParamfromGui
# {   
#     ("client_id", c_int32 ),
#     # ("strategy_id", c_char),
#     int  Id=0;     #client incremental str id
#     int  Token1=0; 
#     int  Token2=0;
#     char Status[20];
#     int  RatioNsetoSgx=0;
#     int  TotalTradingLots=0;
#     double BuySpread=0;
#     double SellSpread=0;

#     double MKTBuySpread=0;
#     double MKTSellSpread=0;
#     double TradedSpread=0;
#     double Pnl=0;
#     int NiftyQty=0;
#     int SgxQty=0;
#     int NiftyQty3=0;
#     int NiftyQty4=0;
#     int TC=0;
#     int USDINR=0;
#     int BuyQtyNSE=0;
#     int SellQtyNSE=0;


#     int BuyQtySGX=0;
#     int SellQtySGX=0;
#     int ATPBuyNse=0;
#     int ATPSellNse=0;
#     int ATPBuySGX=0;
#     int ATPSellSGX=0;
#     int Token3=0;
#     int Token4=0;
#     int StrategyType=0;

#     int BuyQty3=0;
#     int SellQty3=0;
#     int BuyQty4=0;
#     int SellQty4=0;
#     int ATPBuy3=0;
#     int ATPSell3=0;
#     int ATPBuy4=0;
#     int ATPSell4=0;

#     # ("strategy_name", c_char),


    
# };

# print (sizeof (SGX_Message_Structure))

# # MCAST_GRP = '239.70.70.45'
# # MCAST_PORT = 17745
# MCAST_GRP = '226.1.1.1'
# MCAST_PORT = 5000


# sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
# sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
# sock.bind((MCAST_GRP, MCAST_PORT))  # use MCAST_GRP instead of '' to listen only
# # to MCAST_GRP, not all groups on MCAST_PORT
# mreq = socket.inet_aton(MCAST_GRP) + socket.inet_aton('192.168.25.34')

# sock.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)
# watchlist_token = [23456, 4567]

# while True:
#     message = sock.recv(sizeof(Message_Structure))
#     message_in = Message_Structure.from_buffer_copy(message)
#     print(message)
    # print(message_in.ltp, message_in.symbol)
    # print("Token LTP", message_in.id, message_in.ltp)
    # if message_in.id in watchlist_token:
    #    print("Token LTP", message_in.ltp/100)
       




# struct __attribute__((packed)) product_data {
#     int32_t product_id_{0}; /*!< unique token number*/
#     int32_t high_dpr_{0}; /*!< High DPR Limit*/
#     int32_t low_dpr_{0}; /*!< Low DPR Limit*/
#     int32_t freeze_qty_{0}; /*!< Freeze Quantity*/
#     int32_t ltp_{0}; /*!< Last Traded Price*/
#     int32_t ltq_{0}; /*!< Last Traded Qty*/
#     int32_t volume_traded_today_{0};
#     int32_t highExecBand_{0}; /*!< High TER Limit*/
#     int32_t lowExecBand_{0}; /*!< Low TER Limit*/
#     int32_t strike_price_{-1}; /*!< Strike Price*/
#     int32_t expiry_date_{0}; /*!< Expiry Date of asset/instrument*/
#     int16_t lot_size_{0}; /*!< Minimum lot size*/
#     int16_t tick_size_{5}; /*!< Tick size*/
#     int16_t enabled_{1}; /*!< Product Enabled / Disabled */
#     uint16_t flags_{0}; /*!< Event Flags eg. TER_UPDATE_EVENT | MBP_UPDATE_EVENT*/
#     INSTRUMENT_TYPE instru_type_; /*!< Instrument Type */
#     OPTION_TYPE opt_type_; /*!< Option Type */
#     aef::infra::mbp_book::st_mbp_info bid_mbp[5]; /*!< BID Touchline */
#     aef::infra::mbp_book::st_mbp_info ask_mbp[5]; /*!< ASK Touchline */
#     char symbol[11];/*!< Symbol*/
#     char instrumentName[26];/*!< Complete Name*/
#     int32_t open_interest; /*!< Open Interest */
#     char NetChangeIndicator;
#     int NetPriceChangeFromClosingPrice;
#     int AverageTradePrice;
#     int LastTradeTime;
#     int16_t TradingStatus;
#     int OpenPrice;
#     int ClosingPrice;
#     int HighPrice;
#     int LowPrice;



if False: '''


       for items in watchlist['watchlist0']:
            if items['Token'] == message_in.id:
                items['LTP'] = message_in.ltp / 100
                items['LTQ'] = message_in.ltq
                items['LTQ'] = message_in.bid_mbp[0].qty
                items['Bid_Qty1'] = message_in.bid_mbp[0].qty
                items['Bid_Price1'] = message_in.bid_mbp[0].price
                items['Bid_Order_Count1'] = message_in.bid_mbp[0].order_count
                items['Bid_Qty2'] = message_in.bid_mbp[1].qty
                items['Bid_Price2'] = message_in.bid_mbp[1].price
                items['Bid_Order_Count2'] = message_in.bid_mbp[1].order_count
                items['Bid_Qty3'] = message_in.bid_mbp[2].qty
                items['Bid_Price3'] = message_in.bid_mbp[2].price
                items['Bid_Order_Count3'] = message_in.bid_mbp[2].order_count
                items['Bid_Qty4'] = message_in.bid_mbp[3].qty
                items['Bid_Price4'] = message_in.bid_mbp[3].price
                items['Bid_Order_Count4'] = message_in.bid_mbp[3].order_count
                items['Bid_Qty5'] = message_in.bid_mbp[4].qty
                items['Bid_Price5'] = message_in.bid_mbp[4].price
                items['Bid_Order_Count5'] = message_in.bid_mbp[4].order_count
                items['Sell_Qty1'] = message_in.ask_mbp[0].qty
                items['Sell_Price1'] = message_in.ask_mbp[0].price
                items['Sell_Order_Count1'] = message_in.ask_mbp[0].order_count
                items['Sell_Qty2'] = message_in.ask_mbp[1].qty
                items['Sell_Price2'] = message_in.ask_mbp[1].price
                items['Sell_Order_Count2'] = message_in.ask_mbp[1].order_count
                items['Sell_Qty3'] = message_in.ask_mbp[2].qty
                items['Sell_Price3'] = message_in.ask_mbp[2].price
                items['Sell_Order_Count3'] = message_in.ask_mbp[2].order_count

                items['Sell_Qty4'] = message_in.ask_mbp[3].qty
                items['Sell_Price4'] = message_in.ask_mbp[3].price
                items['Sell_Order_Count4'] = message_in.ask_mbp[3].order_count

                items['Sell_Qty5'] = message_in.ask_mbp[4].qty
                items['Sell_Price5'] = message_in.ask_mbp[4].price
                items['Sell_Order_Count5'] = message_in.ask_mbp[4].order_count
'''
#  time.sleep(2)

# configData = {
#    "PRO_MARKET_BUY_LIMIT" :1105,
#     "PRO_MARKET_SELL_LIMIT" :561,

#     "PRO_LIMIT_BUY_LIMIT" :1169,
#     "PRO_LIMIT_SELL_LIMIT" :1185,

#    "PRO_MARKET_BUY_IOC" :1106,
#     "PRO_MARKET_SELL_IOC" :1122,

#    "PRO_LIMIT_BUY_IOC" :1170,
#    "PRO_LIMIT_SELL_IOC" :1186,

#    "CLIENT_MARKET_BUY_LIMIT" :593,
#     "CLIENT_MARKET_SELL_LIMIT" :609,

#     "CLIENT_LIMIT_BUY_LIMIT" :657,
#     "CLIENT_LIMIT_SELL_LIMIT" :673,

#     "CLIENT_MARKET_BUY_IOC" :594,
#     "CLIENT_MARKET_SELL_IOC" :610,

#     "CLIENT_LIMIT_BUY_IOC" :658,
#     "CLIENT_LIMIT_SELL_IOC" :674,

#     "CREATE" :1111 ,
#     "MODIFTY" :1112 ,
#     "CANCEL" :1113 
# }
