# import SharedArray as sa
import threading
import multiprocessing,json,time
import sys,os
from websocket import create_connection
# import socket	
from os.path import expanduser
import SharedArray as sa
import logging 
import sysv_ipc
from utils import loadJsonData
from datetime import date,datetime,timedelta
import traceback,signal
from generalCon import generalCon
from utils import setStrategyLeg,writerPID


"""Get Params From Input Ex : python pythonfileName.py FileName  """
generalSettingFile = sys.argv[1]
manualTradeSettings = sys.argv[2]


class strategyLive(generalCon):
    
    def __init__(self):
        super().__init__()

        self.flag = 1
        self.printCounter = 0

        self.strLiveBroadCastQueueList = multiprocessing.Queue(5000)
        self.setGeneralConData(generalSettingFile)
        self.strategyLiveQueue = None
        self.initializeQueue()

        # writerPID(self.baseDir,os.getpid(),'spreadLive','vishal')
        writerPID(self.baseDir,os.getpid(),'spreadLive',f"""source  /home/techteam/Vishal/myvenv/bin/activate\npython strategyLive.py /home/techteam/sharedMemory/settings/generalSettings.json /home/techteam/sharedMemory/settings/manualTradeSettings.json""",'vishal')



    def initializeQueue(self):
        self.websocketConnect()

        try :
            self.strategyLiveQueue = sysv_ipc.MessageQueue(self.strategyLiveQueueNum,sysv_ipc.IPC_CREX)
        except Exception as e:     
            self.strategyLiveQueue = sysv_ipc.MessageQueue(self.strategyLiveQueueNum)   
        
  
    def startThread(self) :
        threading.Thread(target=self.recvStrategyLive).start()
        threading.Thread(target=self.sendStrategyLive).start()

    
    def saveBroadcast(self,item):
        msg = dict()
        try:
            filePath = str(self.baseDir)+'/clients/'+str(item['client_id'])+'/strategylive/'+str(item['strategy_id'])

            if(os.path.exists(filePath)):
                # print(item['client_id'],item['strategy_id'],item['buylive'],item['selllive'])
                
                sharedTokenArray = sa.attach("file://"+filePath)
                sharedTokenArray[self.strategyLiveDataPacket.get('client_id')] = item['client_id']
                sharedTokenArray[self.strategyLiveDataPacket.get('strategy_id')] = item['strategy_id']
                sharedTokenArray[self.strategyLiveDataPacket.get('buylive')] = item['buylive']
                sharedTokenArray[self.strategyLiveDataPacket.get('selllive')] = item['selllive']

                sharedTokenArray[self.strategyLiveDataPacket.get('buyspread')] = item['buyspread']
                sharedTokenArray[self.strategyLiveDataPacket.get('sellspread')] = item['sellspread']

                sharedTokenArray[self.strategyLiveDataPacket.get('tradedlots')] = item['tradedlots']

                sharedTokenArray[self.strategyLiveDataPacket.get('buyavg')] = item['buyavg']
                sharedTokenArray[self.strategyLiveDataPacket.get('sellavg')] = item['sellavg']
                sharedTokenArray[self.strategyLiveDataPacket.get('buytargetavg')] = item['buytargetavg']
                sharedTokenArray[self.strategyLiveDataPacket.get('selltargetavg')] = item['selltargetavg']

                sharedTokenArray[self.strategyLiveDataPacket.get('avgdisparity')] = item['avgdisparity']
                sharedTokenArray[self.strategyLiveDataPacket.get('pnl')] = item['pnl']
                sharedTokenArray[self.strategyLiveDataPacket.get('token1qty')] = item['token1qty']
                sharedTokenArray[self.strategyLiveDataPacket.get('token2qty')] = item['token2qty']

                sharedTokenArray[self.strategyLiveDataPacket.get('token3qty')] = item['token3qty']
                sharedTokenArray[self.strategyLiveDataPacket.get('token4qty')] = item['token4qty']
                sharedTokenArray[self.strategyLiveDataPacket.get('tc')] = item['tc']
                sharedTokenArray[self.strategyLiveDataPacket.get('usdinr')] = item['usdinr']
                # sharedTokenArray[17] = item['status']

            
                """ delete a instance """
                del sharedTokenArray

                msg = {"event":"strategylive","clientid":str(item['client_id']) ,"strategyid":str(item['strategy_id'])}
                return msg

        except Exception as e:
            print("[Error] in (self,saveBroadcast) msg: ",str(e))  
            return msg


    # @timer
    def recvStrategyLive(self):
        while True:
            try:
                data = self.strategyLiveQueue.receive()
                rawData  = json.loads(data[0].decode())
                # print(rawData['client_id'])
                self.strLiveBroadCastQueueList.put(rawData)
            except Exception as e :
                # logging.basicConfig(filename=f"{self.logFileDir}/recvStrategyLive.log",  format='%(asctime)s %(message)s',  filemode='w')  
                self.logger.error(str(e))
                print("[Error] in (recvStrategyLive) msg: ",str(e))   


    def sendStrategyLive(self):
        # WS client example
        try:
            while  self.flag>0:
                item = self.strLiveBroadCastQueueList.get()
                # print(item)
                # print(item['client_id'],item['strategy_id'],item['buylive'],item['selllive'])
                # print("before size ============",self.strLiveBroadCastQueueList.qsize())
                msg = self.saveBroadcast(item)
                if(msg):
                    try:
                        # print(item['client_id'],item['strategy_id'],msg)
                        self.broadCastServiceCon.send(json.dumps(msg))
                    except Exception as e:
                        print("disconneted",e)
                        self.websocketConnect()
                        self.broadCastServiceCon.send(json.dumps(msg))
                    
                    self.printCounter = self.printCounter + 1
                
                if(self.printCounter == 100):
                    print(item)
                    self.printCounter = 0
                # print("after size ============",self.strLiveBroadCastQueueList.qsize())
        except Exception as e:
            print("[Error] in (self,sendStrategyLive) msg: ",str(e))   


strategyLiveobj = strategyLive()
strategyLiveobj.startThread()

