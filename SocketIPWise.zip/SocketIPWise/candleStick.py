import threading
import multiprocessing,json,time
import sys,os
from websocket import create_connection
from os.path import expanduser
import SharedArray as sa
from ctypes import sizeof
import logging ,traceback
from datetime import date,datetime,timedelta

from generalCon import generalCon
from utils import writerPID
import sysv_ipc


"""Get Params From Input Ex : python pythonfileName.py FileName  """
generalSettingFile = sys.argv[1]

class candleStickNseServer(generalCon) :
    
    def __init__(self):
        super().__init__()

        """ self.nsecandleStickQueueList : Declare multiProcessing  Queue
        self.flag : Declare Flag as 1 for Infinite Loop """

        self.flag = 1
        self.tokenIDKeyMapDict = dict()
        self.printCounter = 0
        self.count = 0

        self.NseTimeDiff = 315513000 

        self.candleDuration = 30
        self.candleStickQueueList = multiprocessing.Queue(10000)
                
        self.setGeneralConData(generalSettingFile)
        self.initializeQueue()
        self.prevTime = time.time()

        # writerPID(self.baseDir,os.getpid(),'candleStickNseServer',f"""source  /home/techteam/Vishal/myvenv/bin/activate\npython candleStickNseServer.py /home/techteam/sharedMemory/settings/generalSettings.json /home/techteam/sharedMemory/settings/nseSettings.json""",'vishal')



    def initializeQueue(self):
        self.websocketConnect()
        self.getContractFile()
        
        try :
            self.candleStickQueue = sysv_ipc.MessageQueue(self.candleStickQueueNum,sysv_ipc.IPC_CREX)
        except Exception as e:     
            self.candleStickQueue = sysv_ipc.MessageQueue(self.candleStickQueueNum)   


    def startThread(self):
        threading.Thread(target=self.broadCastData).start()
        threading.Thread(target=self.startCandleStickServer).start()


    def getContractFile(self):
        filePath =self.baseDir+self.bodPathPath+'nse_contractfile'+self.todayDate+'.csv'
        if(os.path.exists(filePath)):
            print(filePath)
            self.tokenIDKeyMapDict = self.getTokenIDKeyContractFile(filePath,'NSE','FO')
            # print(self.tokenIDKeyMapDict )
        else:
            cur_date = datetime.strptime(self.todayDate, "%Y%m%d").date()
            pre_date = str(cur_date+ timedelta(days=-1)).replace('-','')
            self.todayDate = pre_date
            self.getContractFile()

    

    def saveBroadcast(self,item):
        msg = dict()
        try:
            tokenID2 = self.tokenIDKeyMapDict.get(item.id)
            if(tokenID2):
                tokenID2 = tokenID2.get('tokenID2')

            # tokenID2 = self.tokenIDKeyMapDict.get(item.get('token'))['tokenID2']

            filePath = str(self.baseDir)+str(self.candleStickPath)+str(tokenID2)
            # print(self.tokenIDKeyMapDict)
            if(os.path.exists(filePath) and (tokenID2 != None)):
                # print(self.marketDataStruct.get('tokenid2'))

                # print("item.id",tokenID2)
                
                sharedTokenArray = sa.attach("file://"+filePath)
                sharedTokenArray[self.candleStickdataPacket.get('open')] = tokenID2
                sharedTokenArray[self.candleStickdataPacket.get('high')] = item.bid_mbp[0].price
                sharedTokenArray[self.candleStickdataPacket.get('low')] = item.bid_mbp[0].qty
                sharedTokenArray[self.candleStickdataPacket.get('close')] = item.ask_mbp[0].price
                sharedTokenArray[self.candleStickdataPacket.get('bit')] = item.ask_mbp[0].qty

                sharedTokenArray[self.candleStickdataPacket.get('sit')] = item.bid_mbp[1].price
                sharedTokenArray[self.candleStickdataPacket.get('volume')] = item.bid_mbp[1].qty

                """ delete a instance """
                del sharedTokenArray
                # print("saveBroadcast Saveee",str(tokenID2))

                msg = {"event":"broadcast","token":str(tokenID2) }
                return msg

        except Exception as e:
            # traceback.print_exc()
            print("[Error] in (self,saveBroadcast) msg: ",str(e))   
            return msg


    # @timer
    def startCandleStickServer(self):
        print("server up and running!!!!") 
        while self.flag>0 :
            try :
                queueData = self.candleStickQueue.receive()
                rawData  = json.loads(queueData[0].decode())
                self.candleStickQueueList.put(rawData)

                # if(data_in.id==48757):
                #     print(data_in.id,data_in.bid_mbp[0].price,data_in.ask_mbp[0].price,data_in.ltp,data_in.ltq)
            except Exception as e :
                # logging.basicConfig(filename=f"{self.logFileDir}/startCandleStickServer.log",  format='%(asctime)s %(message)s',  filemode='w')  
                # self.logger.error(str(e))
                print("[Error] in (self,startCandleStickServer) msg: ",str(e))   



    def broadCastData(self):
        # WS client example
        try:
            while  self.flag>0:
                item = self.candleStickQueueList.get()
                try:
                    msg = self.createData(item)
                    if(msg):
                        # print("msg",msg)
                        try:
                            self.broadCastServiceCon.send(json.dumps(msg))
                        except Exception as e:
                            self.websocketConnect()
                            self.broadCastServiceCon.send(json.dumps(msg))
                except Exception as e:
                    print(e)
                
        except Exception as e:
            print("[Error] in (self,broadCastData) msg: ",str(e))   




    def createData(self,data):
        msg = dict()
        cur = data['ltt'] + self.NseTimeDiff
        # cur = time.time()

        try:
            tokenID2 = self.tokenIDKeyMapDict.get(data['id'] )
            if(tokenID2):
                tokenID2 = tokenID2.get('tokenID2')

            filePath = str(self.baseDir)+str(self.candleStickPath)+str(tokenID2)

            if(os.path.exists(filePath) and (tokenID2 != None)):
                candleArray = sa.attach("file://"+filePath)
                duration = candleArray[self.candleStickdataPacket.get('duration')]

                o = candleArray[self.candleStickdataPacket.get('open')]
                h = candleArray[self.candleStickdataPacket.get('high')]
                l = candleArray[self.candleStickdataPacket.get('low')]
                c = candleArray[self.candleStickdataPacket.get('close')]
                vtt_temp = candleArray[self.candleStickdataPacket.get('vtt_temp')]
                bit_temp = candleArray[self.candleStickdataPacket.get('bit_temp')]
                sit_temp = candleArray[self.candleStickdataPacket.get('sit_temp')]


                if(o == 0):
                    candleArray[self.candleStickdataPacket.get('open')] = data['ltp']
                    # vol = data['vtt']

                if(data['vtt'] != vtt_temp):
                    vtt_diff = data['vtt'] - vtt_temp

                    # print("vtt_diff",data['vtt'] , vtt_temp)

                    if( data['ltp'] >= (data['bid']+data['ask'])/2 ):
                        print("bit",data['ltp'] , data['ask'],vtt_diff,bit_temp)
                        bit_temp = bit_temp + vtt_diff

                    elif( data['ltp'] <= (data['bid']+data['ask'])/2 ):
                        print("sit",data['ltp'] , data['ask'],vtt_diff,sit_temp)
                        sit_temp = sit_temp + vtt_diff

                # candleArray[self.candleStickdataPacket.get('vtt_temp')] = data['vtt']

                
                if( data['ltp'] > h  ):
                    candleArray[self.candleStickdataPacket.get('high')] = data['ltp']
                if( data['ltp'] < l ):
                    candleArray[self.candleStickdataPacket.get('low')] = data['ltp']

                print(data['bid'],data['ask'],data['ltp'])
                # if(cur - self.prevTime > duration):
                candleArray[self.candleStickdataPacket.get('vtt_temp')] = data['vtt'] 

                if(cur - self.prevTime > self.candleDuration):
                    # print("bit_temp",bit_temp,sit_temp)

                    
                    self.prevTime = cur

                    # vtt = data['vtt'] - vol 
                    candleArray[self.candleStickdataPacket.get('close')] = data['ltp']
                    candleArray[self.candleStickdataPacket.get('bit')] = bit_temp
                    candleArray[self.candleStickdataPacket.get('sit')] = sit_temp

                    time = self.prevTime
                    op = candleArray[self.candleStickdataPacket.get('open')]
                    hi = candleArray[self.candleStickdataPacket.get('high')]
                    lo = candleArray[self.candleStickdataPacket.get('low')]
                    cl = candleArray[self.candleStickdataPacket.get('close')]
                    bi = candleArray[self.candleStickdataPacket.get('bit')]
                    si = candleArray[self.candleStickdataPacket.get('sit')]
                    vo = candleArray[self.candleStickdataPacket.get('volume')]

                    candleArray[self.candleStickdataPacket.get('open')] = 0
                    candleArray[self.candleStickdataPacket.get('high')] = 0
                    candleArray[self.candleStickdataPacket.get('low')] = 1000000000
                    candleArray[self.candleStickdataPacket.get('bit_temp')] = 0
                    candleArray[self.candleStickdataPacket.get('sit_temp')] = 0

                    print("op",op,"hi",hi)
                    msg = {
                            "event":"candlestick","token":str(tokenID2),
                            "timestamp":time,"duration":self.candleDuration,"open":op,
                            "high":hi,"low":lo,"close":cl,"bit":bi,"sit":si,"volume":vo
                            }
                    """ delete a instance """
                    print("msg",msg)
                    del candleArray
                    return msg

        except Exception as e:
            print(traceback.print_exc())
            return msg


candleStickNseServerobj = candleStickNseServer()
candleStickNseServerobj.startThread()
