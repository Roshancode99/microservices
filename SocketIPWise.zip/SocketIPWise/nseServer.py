import threading
import multiprocessing,json,time
import sys,os
from websocket import create_connection
from os.path import expanduser
import SharedArray as sa
from ctypes import sizeof
import logging ,traceback
from datetime import date,datetime,timedelta

from generalCon import generalCon
from CStruct import NSE_Message_Structure
from utils import writerPID
import sysv_ipc

"""Get Params From Input Ex : python pythonfileName.py FileName  """
generalSettingFile = sys.argv[1]
nseSettingFile = sys.argv[2]


class nseServer(generalCon) :
    
    def __init__(self):
        super().__init__()

        """ self.nseBroadcastQueueList : Declare multiProcessing  Queue
        self.flag : Declare Flag as 1 for Infinite Loop """

        self.flag = 1
        self.tokenIDKeyMapDict = dict()
        self.printCounter = 0
                
        self.setGeneralConData(generalSettingFile)
        self.setServerConData(nseSettingFile)
        self.initializeQueue()

        # writerPID(self.baseDir,os.getpid(),'nseServer','vishal')

        writerPID(self.baseDir, os.getpid(), 'nseServer', f"""python /home/centos/Jayesh/Vishal/SocketIPWise/nseServer.py /home/centos/sharedMemory/settings/generalSettings.json /home/centos/sharedMemory/settings/nseSettings.json""", 'vishal')


    def initializeQueue(self):
        self.websocketConnect()
        self.getContractFile()

        try :
            self.candleStickQueue = sysv_ipc.MessageQueue(self.candleStickQueueNum,sysv_ipc.IPC_CREX)
        except Exception as e:     
            self.candleStickQueue = sysv_ipc.MessageQueue(self.candleStickQueueNum)   

        try :
            self.BloombergparityQueue = sysv_ipc.MessageQueue(self.bloombergParityQueueNum,sysv_ipc.IPC_CREX)
        except Exception as e:     
            self.BloombergparityQueue = sysv_ipc.MessageQueue(self.bloombergParityQueueNum)


        try :
            self.AnalysisDataQueue = sysv_ipc.MessageQueue(self.AnalysisDataQueueNum,sysv_ipc.IPC_CREX)
        except Exception as e:     
            self.AnalysisDataQueue = sysv_ipc.MessageQueue(self.AnalysisDataQueueNum)




    def startThread(self):
        threading.Thread(target=self.broadCastData).start()
        threading.Thread(target=self.startTCPServer).start()


    def getContractFile(self):
        filePath =self.baseDir+self.bodPathPath+self.exchange.lower()+'_contractfile'+self.todayDate+'.csv'
        if(os.path.exists(filePath)):
            # print(filePath)
            self.tokenIDKeyMapDict = self.getTokenIDKeyContractFile(filePath,self.exchange,self.segment)
            # print(self.tokenIDKeyMapDict )
        else:
            cur_date = datetime.strptime(self.todayDate, "%Y%m%d").date()
            pre_date = str(cur_date+ timedelta(days=-1)).replace('-','')
            self.todayDate = pre_date
            self.getContractFile()

    

    def saveBroadcast(self,item):
        msg = dict()
        try:

            tokenID2 = self.tokenIDKeyMapDict.get(item.id)
            print("item.id",item.id,tokenID2.get('tokenID2'))
            if(tokenID2):
                tokenID2 = tokenID2.get('tokenID2')

            filePath = str(self.baseDir)+str(self.tickersPath)+str(tokenID2)
            # print(self.tokenIDKeyMapDict)
            if(os.path.exists(filePath) and (tokenID2 != None)):
                
                # print(self.marketDataStruct.get('tokenid2'))

                
                sharedTokenArray = sa.attach("file://"+filePath)
                sharedTokenArray[self.marketDataStruct.get('tokenid2')] = tokenID2
                sharedTokenArray[self.marketDataStruct.get('bid0')] = item.bid_mbp[0].price
                sharedTokenArray[self.marketDataStruct.get('bidqty0')] = item.bid_mbp[0].qty
                sharedTokenArray[self.marketDataStruct.get('ask0')] = item.ask_mbp[0].price
                sharedTokenArray[self.marketDataStruct.get('askqty0')] = item.ask_mbp[0].qty

                sharedTokenArray[self.marketDataStruct.get('bid1')] = item.bid_mbp[1].price
                sharedTokenArray[self.marketDataStruct.get('bidqty1')] = item.bid_mbp[1].qty
                sharedTokenArray[self.marketDataStruct.get('ask1')] = item.ask_mbp[1].price
                sharedTokenArray[self.marketDataStruct.get('askqty1')] = item.ask_mbp[1].qty

                sharedTokenArray[self.marketDataStruct.get('bid2')] = item.bid_mbp[2].price
                sharedTokenArray[self.marketDataStruct.get('bidqty2')] = item.bid_mbp[2].qty
                sharedTokenArray[self.marketDataStruct.get('ask2')] = item.ask_mbp[2].price
                sharedTokenArray[self.marketDataStruct.get('askqty2')] = item.ask_mbp[2].qty

                sharedTokenArray[self.marketDataStruct.get('bid3')] = item.bid_mbp[3].price
                sharedTokenArray[self.marketDataStruct.get('bidqty3')] = item.bid_mbp[3].qty
                sharedTokenArray[self.marketDataStruct.get('ask3')] = item.ask_mbp[3].price
                sharedTokenArray[self.marketDataStruct.get('askqty3')] = item.ask_mbp[3].qty

                sharedTokenArray[self.marketDataStruct.get('bid4')] = item.bid_mbp[4].price
                sharedTokenArray[self.marketDataStruct.get('bidqty4')] = item.bid_mbp[4].qty
                sharedTokenArray[self.marketDataStruct.get('ask4')] = item.ask_mbp[4].price
                sharedTokenArray[self.marketDataStruct.get('askqty4')] = item.ask_mbp[4].qty

                sharedTokenArray[self.marketDataStruct.get('ltp')] = item.ltp
                sharedTokenArray[self.marketDataStruct.get('ltq')] = item.ltq

                sharedTokenArray[self.marketDataStruct.get('vtt')] = item.volume_traded_today
                sharedTokenArray[self.marketDataStruct.get('openinterest')] = item.open_interest
                if(item.netchangeindicator == b'-'):
                    sharedTokenArray[self.marketDataStruct.get('netchangeindicator')] = 0
                else:
                    sharedTokenArray[self.marketDataStruct.get('netchangeindicator')] = 1

                sharedTokenArray[self.marketDataStruct.get('averagetradeprice')] = item.averagetradeprice
                sharedTokenArray[self.marketDataStruct.get('lasttradetime')] = item.lasttradetime
                sharedTokenArray[self.marketDataStruct.get('tradingstatus')] = item.tradingstatus

                sharedTokenArray[self.marketDataStruct.get('openprice')] = item.openprice
                sharedTokenArray[self.marketDataStruct.get('closingprice')] = item.closingprice
                sharedTokenArray[self.marketDataStruct.get('highprice')] = item.highprice
                sharedTokenArray[self.marketDataStruct.get('lowprice')] = item.lowprice


                """ delete a instance """
                del sharedTokenArray
                # print("saveBroadcast Saveee",str(tokenID2))

                temp = {'ContractName':'NSEFO','tokenid':item.id,'tokenid2':str(tokenID2),'bid':item.bid_mbp[0].price,
                'ask':item.ask_mbp[0].price,'ltt':item.lasttradetime,'ltp':item.ltp,'vtt':item.volume_traded_today}

                # self.AnalysisDataQueue.send(json.dumps(temp))

                msg = {"event":"broadcast","token":str(tokenID2) }

                return msg

        except Exception as e:
            print("[Error] in (self,saveBroadcast) msg: ",str(e))   
            return msg


    # @timer
    def startTCPServer(self):
        print("server up and running!!!!") 
        while self.flag>0 :
            try :
                message = self.socket.recv()
                # print("+++++",message)
                message = message[72:sys.getsizeof(message)]
                data_in = NSE_Message_Structure.from_buffer_copy(message)
                # print(data_in)

                # if(data_in.id==37833):
                #     print(data_in.id,data_in.bid_mbp[0].price,data_in.ask_mbp[0].price,data_in.ltp,data_in.ltq)


                self.broadCastQueueList.put(data_in)
            except Exception as e :
                # logging.basicConfig(filename=f"{self.logFileDir}/startTCPServer.log",  format='%(asctime)s %(message)s',  filemode='w')  
                # self.logger.error(str(e))
                print("[Error] in (self,startTCPServer) msg: ",str(e))   



    def broadCastData(self):
        # WS client example
        try:
            while  self.flag>0:
                item = self.broadCastQueueList.get()
                # print("item.id",item.id,item.bid_mbp[0].price)
                candleData = {
                                'id':item.id,'bid':item.bid_mbp[0].price,
                                'ask':item.ask_mbp[0].price,
                                'ltt':item.lasttradetime,
                                'ltp':item.ltp,'vtt':item.volume_traded_today
                            }

                # print(candleData)
                # self.candleStickQueue.send(json.dumps(candleData))

                result_df = self.BloombergData[self.BloombergData["TokenId"] == item.id]
                
                if(result_df.shape[0] > 0):
                    divider = self.tokenIDKeyMapDict.get(item.id).get('divider')
                    # print(divider)
                    temp = result_df.to_dict('records')[0]
                    temp['bid'] = item.bid_mbp[0].price/divider
                    temp['ask'] = item.ask_mbp[0].price/divider
                    temp['ltp'] = item.ltp/divider
                    # print(temp)

                    self.BloombergparityQueue.send(json.dumps(temp))
                 

                msg = self.saveBroadcast(item)
                # print(msg)
                if(msg):
                    try:
                        self.broadCastServiceCon.send(json.dumps(msg))

                    except Exception as e:
                        self.websocketConnect()
                        self.broadCastServiceCon.send(json.dumps(msg))

                    self.printCounter = self.printCounter + 1
                        
                if(self.printCounter == 100):
                    print(msg)
                    self.printCounter = 0
        except Exception as e:
            print("[Error] in (self,broadCastData) msg: ",str(e))   


nseServerobj = nseServer()
nseServerobj.startThread()
