
import threading
import multiprocessing,json,time
import sys,os
from websocket import create_connection
import logging 
import SharedArray as sa
from generalCon import generalCon
import datetime,sysv_ipc,traceback
from utils import writerPID

generalSettingFile = sys.argv[1]

class centralCode(generalCon) :
    def __init__(self):
        super().__init__()
        self.flag = 1
        self.setGeneralConData(generalSettingFile)
        self.initializeQueue()

        # writerPID(self.baseDir,os.getpid(),'centralCode','vishal')
        writerPID(self.baseDir,os.getpid(),'centralCode',f"""source  /home/techteam/Vishal/myvenv/bin/activate\npython centralCode.py /home/techteam/sharedMemory/settings/generalSettings.json""",'vishal')

        
    def initializeQueue(self):
        try :
            self.strategylive = sysv_ipc.MessageQueue(self.strategyLiveQueueNum,sysv_ipc.IPC_CREX)
        except Exception as e:     
            self.strategylive = sysv_ipc.MessageQueue(self.strategyLiveQueueNum)   
                
        try :
            self.manualTrade = sysv_ipc.MessageQueue(self.manualTradeQueueNum,sysv_ipc.IPC_CREX)
        except Exception as e:     
            self.manualTrade = sysv_ipc.MessageQueue(self.manualTradeQueueNum) 

        try :
            self.strategyTrade = sysv_ipc.MessageQueue(self.strategyQueueNum,sysv_ipc.IPC_CREX)
        except Exception as e:     
            self.strategyTrade = sysv_ipc.MessageQueue(self.strategyQueueNum) 

        try :
            self.sendJayeshTrades = sysv_ipc.MessageQueue(self.sendJayeshTradesNum,sysv_ipc.IPC_CREX)
        except Exception as e:     
            self.sendJayeshTrades = sysv_ipc.MessageQueue(self.sendJayeshTradesNum)   
     
        try :
            self.sendDeepakTrades = sysv_ipc.MessageQueue(self.sendDeepakTradesNum,sysv_ipc.IPC_CREX)
        except Exception as e:     
            self.sendDeepakTrades = sysv_ipc.MessageQueue(self.sendDeepakTradesNum)   
      
        try :
            self.sendDeepakStrategy = sysv_ipc.MessageQueue(self.sendDeepakStrategyNum,sysv_ipc.IPC_CREX)
        except Exception as e:     
            self.sendDeepakStrategy = sysv_ipc.MessageQueue(self.sendDeepakStrategyNum) 


    def startCentralCodeThread(self):
        threading.Thread(target = self.readManualTradeQueue).start()
        threading.Thread(target = self.readStrategyTradeQueue).start()


    def readManualTradeQueue(self):
        while self.flag > 0:
            try:
                data = self.manualTrade.receive()
                
                rawData  = json.loads(data[0].decode())
                data = rawData['data']
                data['event'] = rawData['event']
            
                if data['event'] == 'cancel':
                    data['qty'] = data['vol']

                if(data['exchange'] in self.exchangeListJson['Deepak']):
                    print("deepak exchange",data)
                    self.sendDeepakTrades.send(json.dumps(data))

                if(data['exchange'] in self.exchangeListJson['Jayesh']):
                    print("jayesh exchange",data)
                    self.sendJayeshTrades.send(json.dumps(data))

            except Exception as e:
                # print(traceback.format_exc())
                print("readManualTradeQueue Error---------------------------",e)


    def readStrategyTradeQueue(self):
        while self.flag > 0:
            try:
                rawData = self.strategyTrade.receive()
                data  = json.loads(rawData[0].decode())
                print("readStrategyTradeQueue",data)
                self.sendDeepakStrategy.send(json.dumps(data))

            except Exception as e:
                print("readStrategyTradeQueue Error---------------------------",e)


            
centralCodeobj = centralCode()
centralCodeobj.startCentralCodeThread()
