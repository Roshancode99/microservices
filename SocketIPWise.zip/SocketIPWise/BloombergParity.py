

import websockets
import threading
import time
from datetime import datetime
import asyncio,json
import sysv_ipc
from DBConnection import DBConnection
import time

class BloombergParity:
    def __init__(self):
        self.DbObj = DBConnection()
        self.ParityData = None
        self.bloombergParityQueueNum = 9900

        try :
            self.BloombergparityQueue = sysv_ipc.MessageQueue(self.bloombergParityQueueNum,sysv_ipc.IPC_CREX)
        except Exception as e:     
            self.BloombergparityQueue = sysv_ipc.MessageQueue(self.bloombergParityQueueNum)   

        threading.Thread(target = self.updateUsdRate).start()
        
        asyncio.get_event_loop().run_until_complete(websockets.serve(self.echo, '192.168.10.103', 1900))
        asyncio.get_event_loop().run_forever()


        
    def updateUsdRate(self):
        while True:
            try:
                if(self.ParityData):
                    if(self.ParityData['TokenName'] == 'USDINR'):
                        if(self.ParityData['ltp'] < 100):
                            self.DbObj._forInsertingData(f"update NseTrade.dbo.tbbroadcast set ltp ={self.ParityData['ltp']} where scripcode ='999'")
                time.sleep(5)
            except Exception as e :        
                print("updateUsdRate",e)   


    async def echo(self,websocket, path):   
        try :            
            while True:   
                data = self.BloombergparityQueue.receive()
                jsonData = json.loads(data[0])

                if(jsonData['TokenName'] == 'USDINR' and jsonData['ltp'] > 100):
                    print(jsonData)
                else:
                    self.ParityData = jsonData
                    await websocket.send(str(json.dumps({'data':jsonData})))        
                    await asyncio.sleep(0.00000001) 
                # time.sleep(1)
        except Exception as e :        
            print(e)  

BloombergParity()