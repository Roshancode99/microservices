# import SharedArray as sa
import threading
import json,time
import sys
from websocket import create_connection

import logging 
import SharedArray as sa
import time,os
import sys,traceback,sysv_ipc
from generalCon import generalCon
from datetime import date,datetime,timedelta
from utils import writerPID


"""  Get Params From Input Ex : python pythonfileName.py FileName  """
generalSettingFile = sys.argv[1]
mt5SettingFile = sys.argv[2]



class mt5Server(generalCon) :

    def __init__(self):
        super().__init__()

        self.flag = 1
        self.tokenIDKeyMapDict = dict()
        self.mt5ResponseQueue = None
        self.printCounter = 0

        self.setGeneralConData(generalSettingFile)
        self.setServerConData(mt5SettingFile)
        self.initializeQueue()

        # writerPID(self.baseDir,os.getpid(),'mt5Server','vishal')

        writerPID(self.baseDir,os.getpid(),'mt5Server',f"""source  /home/techteam/Vishal/myvenv/bin/activate\npython /home/techteam/Vishal/SocketIPWise/mt5Server.py /home/techteam/sharedMemory/settings/generalSettings.json /home/techteam/sharedMemory/settings/mt5Settings.json""",'vishal')

        


    def initializeQueue(self):
        try :
            self.mt5ResponseQueue = sysv_ipc.MessageQueue(self.mt5ResponseQueueNum,sysv_ipc.IPC_CREX)
        except Exception as e:     
            self.mt5ResponseQueue = sysv_ipc.MessageQueue(self.mt5ResponseQueueNum)  

        self.websocketConnect()
        self.getContractFile()

      
    def startThread(self) :
        threading.Thread(target=self.broadCastData).start()
        threading.Thread(target=self.startMT5Server).start()


    def getContractFile(self):
        filePath =self.baseDir+self.bodPathPath+self.exchange.lower()+'_contractfile'+self.todayDate+'.csv'
        if(os.path.exists(filePath)):
            print(filePath)
            self.tokenIDKeyMapDict = self.getTokenIDKeyContractFile(filePath,self.exchange,self.segment)
            # print(self.tokenIDKeyMapDict )
        else:
            cur_date = datetime.strptime(self.todayDate, "%Y%m%d").date()
            pre_date = str(cur_date+ timedelta(days=-1)).replace('-','')
            self.todayDate = pre_date
            self.getContractFile()
            
      
    def saveBroadcast(self,item):
            msg = dict()
            try:
                tokenID2 = self.tokenIDKeyMapDict.get(item.get('token'))
                if(tokenID2):
                    tokenID2 = tokenID2.get('tokenID2')
                
                filePath = str(self.baseDir)+str(self.tickersPath)+str(tokenID2)
                # print(tokenID2,item['bid'],item['ask'] )
                # print("file://"+filePath)
                if(os.path.exists(filePath) and (tokenID2 != None)):
                    sharedTokenArray = sa.attach("file://"+filePath)

                    sharedTokenArray[self.marketDataStruct.get('tokenid2')] = tokenID2      #tokenid2
                    sharedTokenArray[self.marketDataStruct.get('bid0')] = item['bid']       #bid
                    sharedTokenArray[self.marketDataStruct.get('bidqty0')] = 0              #bidqty
                    sharedTokenArray[self.marketDataStruct.get('ask0')] = item['ask']       #ask
                    sharedTokenArray[self.marketDataStruct.get('askqty0')] = 0              #askqty
                    sharedTokenArray[self.marketDataStruct.get('ltp')] = 0                  #ltp
                    sharedTokenArray[self.marketDataStruct.get('ltq')] = 0                  #ltq
                
                    """ delete a instance """
                    del sharedTokenArray

                    msg = {"event":"broadcast","token":str(tokenID2) }
                    return msg

            except Exception as e:
                print("[Error] in (self,saveBroadcast) msg: ",str(e))  

                return msg


    def startMT5Server(self):
        print("server up and running!!!!") 
        while self.flag>0 :
            try :
                data_in = self.socket.recv()
                self.broadCastQueueList.put(data_in)
                    
            except Exception as e :
                # logging.basicConfig(filename=f"{self.logFileDir}/startMT5Server.log",  format='%(asctime)s %(message)s',  filemode='w')  
                # self.logger.error(str(e))
                print("[Error] in (self,startMT5Server) msg: ",str(e))  


    def broadCastData(self):
        try:    
            data = dict()
            while  self.flag>0:
                try:
                    item = self.broadCastQueueList.get()
                    data = json.loads(item)
                except Exception as e:
                    print("Error self.broadCastQueueList",str(e))

                if(data.get('event') == 'broadcaster'):
                    token = data.get('data')

                    # if(token.get('token') == 6765):
                    #     print(token.get('token'))
                    # print(str(self.tokenIDKeyMapDict.get(token.get('token'))))

                    msg = self.saveBroadcast(data.get('data'))
                    if(msg):
                        try:
                            self.broadCastServiceCon.send(json.dumps(msg))
                        except Exception as e:
                            self.websocketConnect()
                            self.broadCastServiceCon.send(json.dumps(msg))
                        
                        self.printCounter = self.printCounter + 1
                        
                    if(self.printCounter == 100):
                        print(msg)
                        self.printCounter = 0
                elif(data.get('event') == 'traderesponse'):
                    self.mt5ResponseQueue.send(json.dumps(msg))
                        
        except Exception as e:
            # print(traceback.print_exc())
            time.sleep(1)
            print("[Error] in (self,broadCastData) msg: ",str(e))   

    
mt5Serverobj = mt5Server()
mt5Serverobj.startThread()

        