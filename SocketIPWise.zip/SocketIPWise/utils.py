
from functools import wraps
import time,json
from os.path import exists as file_exists
import zmq,os
import ast,traceback

def timer(func):
    """helper function to estimate view execution time"""
    @wraps(func)  # used for copying func metadata
    def wrapper(*args, **kwargs):
        # record start time
        start = time.time()

        # func execution
        result = func(*args, **kwargs)
        
        duration = (time.time() - start) * 1000
        # output execution time to console
        print('======== [PERF TIME FOR ] ======= [ VIEW ] : {} || EXECUTION takes {:.2f} ms'.format(
            func.__name__, 
            duration
            ))
        return result
    return wrapper

def loadJsonData(path,flag):
    try:
        data = {}
        if(file_exists(path)):
            with open(path, "r") as jsonfile:
                data = json.load(jsonfile)
        else:
            if(flag =='create'):
                with open(path, "w") as f:
                    json.dump({}, f)
        return data
    except Exception as e:
        print(e)


def checkIFKeyExist(data,key):
    if key in data:
        return data[key]
    else:
        return 0
    
def setStrategyLeg(legdetails,dic,key,val):
    data = 0
    for k in dic.keys():
        if k.startswith(key):
            if (k in dic and val in legdetails):
                id = str(k)[-1]
                if legdetails[val] == str(dic["exchange"+id])+str(dic[k]):
                    data =  dic["token"+id]
                    # print(str(dic["exchange"+id])+str(dic[k]),id)
    # print(key,val,data)
    return data

def setSocketInstance(host,port):
        context = zmq.Context()
        socket = context.socket(zmq.PAIR)
        socket.connect("tcp://"+str(host)+":"+str(port))
        return socket

def valfilter(x):
    if int(x)!=0:
        return x


        
        
""" Create createJson File """

def createJson(path,name,data):
    # print("createJson",path)
    filename = (f"""{path}/{name}.json""")
    print("filename",filename)
    try:
        if(not os.path.exists(filename)):
            with open(filename,"w") as file :
                json.dump(data,file) 
    except Exception as e:
        print("createJson",e)
        

""" Create sharedMemory Folder """

def createFolder(path,folderName):
    sharedMemoryDir =  path+"/"+folderName
    try:
        os.makedirs(sharedMemoryDir)
    except Exception as e:
        pass

    
def resetJsonWriter(filedirect):
    try:
        with open(filedirect, "w+") as file:
            json.dump({}, file)
    except Exception as e:
        print("resetJsonWriter ==========",str(e))


def writerPID(baseDir,pid,exename,cmd,user):
    path = f"""{baseDir}/settings/pid.json"""
    try:
        if not os.path.exists(path):
            print("file not exist..")
            with open(path, "w+") as file:
                json.dump({}, file)

        filedirect = os.path.join(f"""{path}""")
        with open(filedirect, "r+") as file:
            temp = json.load(file)
            temp[str(user)+"_"+str(exename)] = {"pid":str(pid),"cmd":f"""{str(cmd)}"""} 
            # temp[str(user)+"_"+str(exename)] = str(pid) 
            file.seek(0)
            json.dump(temp, file)
            print("temp",type(temp),temp)

    except Exception as e:
        # print(traceback.print_exc())
        print("Error on writerPID",e)



        