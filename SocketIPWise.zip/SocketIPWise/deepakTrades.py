import multiprocessing
import zmq,sys,os
from CStruct import *
from ctypes import *
import sysv_ipc,json
import threading
import signal
from os.path import exists as file_exists
# from mt5Server import mt5Server
from utils import *
import traceback
from generalCon import generalCon
import datetime
from utils import resetJsonWriter,writerPID


generalSettingFile = sys.argv[1]
manualTradeSettings = sys.argv[2]

class deepakTrade(generalCon):
    def __init__(self):
        super().__init__()
        self.flag = 1
        self.setGeneralConData(generalSettingFile)
        self.setTradingCodeData(manualTradeSettings)
        self.setTradingServerConData(generalSettingFile,'Deepak')
        self.initializeQueue()


        # writerPID(self.baseDir,os.getpid(),'deepakTrades','vishal')
        writerPID(self.baseDir,os.getpid(),'deepakTrades',f" deepakTrades.py /home/centos/sharedMemory/settings/manualTradeSettings.json",'vishal') 
        # writerPID(self.baseDir,os.getpid(),'deepakTrades',f"""source  /home/techteam/Vishal/myvenv/bin/activate\python deepakTrades.py /home/centos/manualTradeSettings.json""",'vishal') 
        


    def initializeQueue(self):

        self.TradingQueueList = multiprocessing.Queue(self.tradingMaxsizeQueue)
        self.strategyTradeQueueList = multiprocessing.Queue(self.tradingMaxsizeQueue)

        try :
            self.sendDeepakTrades = sysv_ipc.MessageQueue(self.sendDeepakTradesNum,sysv_ipc.IPC_CREX)
        except Exception as e:     
            self.sendDeepakTrades = sysv_ipc.MessageQueue(self.sendDeepakTradesNum)  

        try :
            self.sendDeepakStrategy = sysv_ipc.MessageQueue(self.sendDeepakStrategyNum,sysv_ipc.IPC_CREX)
        except Exception as e:     
            self.sendDeepakStrategy = sysv_ipc.MessageQueue(self.sendDeepakStrategyNum)  
        
        try :
            self.strategylive = sysv_ipc.MessageQueue(self.strategyLiveQueueNum,sysv_ipc.IPC_CREX)
        except Exception as e:     
            self.strategylive = sysv_ipc.MessageQueue(self.strategyLiveQueueNum)  

              
        try :
            self.spreadLive = sysv_ipc.MessageQueue(self.spreadLiveQueueNum,sysv_ipc.IPC_CREX)
        except Exception as e:     
            self.spreadLive = sysv_ipc.MessageQueue(self.spreadLiveQueueNum) 

            
        try :
            self.buySellSpreadAvg = sysv_ipc.MessageQueue(self.buySellSpreadAvgQueueNum,sysv_ipc.IPC_CREX)
        except Exception as e:     
            self.buySellSpreadAvg = sysv_ipc.MessageQueue(self.buySellSpreadAvgQueueNum)  

        
        self.setInitialManualDic(self.TradingDic)
        self.websocketConnect()
        self.TrapAllSignals()

    def setInitialManualDic(self,data):
        for i in data:
            self.TradingQueueList.put(data[i])

    def startDeepakThread(self):
        
        threading.Thread(target = self.receiveManualTrades).start()
        threading.Thread(target = self.sendManulaTrades).start()
        threading.Thread(target = self.recvTradeResponse).start()

        threading.Thread(target = self.receiveStrategyTrades).start()
        threading.Thread(target = self.sendStrategyTradeConnection).start()
        threading.Thread(target = self.receivebuySellSpreadAvg).start()

   
   
    def receiveManualTrades(self):
        while True:
            try:
                rawData = self.sendDeepakTrades.receive()
                data  = json.loads(rawData[0].decode())
                key = str(data['clientid'])+str(data['exchange'])
            
                # print("receiveManualTrades",data)
                if(self.validateRequest_ID(key,data['exchange'])):

                    if data['event'] == 'create':
                        print("key",self.TradingIDDic)

                        if(key in self.TradingIDDic):
                            self.TradingIDDic[key] = self.TradingIDDic[key]+1
                        else:
                            self.TradingIDDic[key] = self.serverMapDetailsJson[str(data['exchange']).upper()]['request_id']
                        
                        data['request_id'] = self.TradingIDDic[key]
                    
                    else:
                        data['request_id'] = data['uidnum']
                    
                    print("DEEPAK DATA ---------",self.TradingIDDic)
                    self.TradingDic[str(data['clientid'])+str(data['request_id'])] = data
                    self.TradingQueueList.put(data)
                else:
                    self.sendOrderErrorLogs(data)
                    print("request_id Exceed!!")
            except Exception as e:
                # traceback.print_exc()
                print("receiveManualTrades Exception---",e)  

    def sendOrderErrorLogs(self,item):
            data = {"event": "ordererrorlogs","eventtime":datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f'), 
                "date": datetime.date.today().strftime("%Y%m%d"), "client": str(item.get('clientid')),"orderno": "1234","data":item}
            try:
                self.broadCastServiceCon.send(json.dumps(data))
            except Exception as e:
                self.websocketConnect()
                self.broadCastServiceCon.send(json.dumps(data))
                print("sendOrderErrorLogs Exception ----",e) 


    def sendManulaTrades(self):
        while self.flag > 0:
            try:
                QueueData = self.TradingQueueList.get()
                data = self.TradingDic[str(QueueData['clientid'])+str(QueueData['request_id'])]
                CLIENT_IDENTIFIER =  CLIENT_IDENTIFIER_Structure(0,int(data['clientid']),int(data['request_id']))
                OMS_API_BODY =  OMS_API_BODY_Structure()

                OMS_API_BODY.flags_[0] = self.configData[f"{data['clienttype']}_{data['producttype']}_{data['buysell']}_{data['booktype']}"]

                OMS_API_BODY.price_[0] = int(data['price'])
                
                OMS_API_BODY.quantity_[0] = int(data['qty'])

                OMS_API_BODY.product_id_[0] = int(data['tokenid2'])

                OMS_API_BODY.token1_status = int(data['token1_status'])
                            
                OMS_API_HEADER =  OMS_API_HEADER_Structure()
                OMS_API_HEADER.uid_ = CLIENT_IDENTIFIER
                OMS_API_HEADER.transaction_code = int(self.configData[data['event'].upper()])

                MSGCODE = int(self.UI_HEADER_MANUALTRADE['MSGCODE'])

                UI_Header =  UIHeader_Structure(MSGCODE,1)

                OMS_TRANSACTION =  OMS_TRANSACTION_Structure()
                OMS_TRANSACTION.uihdr_ = UI_Header
                OMS_TRANSACTION.hdr_ = OMS_API_HEADER
                OMS_TRANSACTION.packet_ = OMS_API_BODY

                self.socket.send(bytes(OMS_TRANSACTION))
                print("Sending to Server...",bytes(OMS_TRANSACTION))
            except Exception as e:
                print("sendManulaTrades Exception--------",e) 


    def recvTradeResponse(self):
        while self.flag > 0:
            try:
                message = self.socket.recv()
                message = message[72:sys.getsizeof(message)]
                # print(message)
                uiheader = UIHeader_Structure.from_buffer_copy(message)
                msgcode = uiheader.msgcode

                if(msgcode == self.UI_HEADER_MANUALTRADE['RESPONSE']):

                    data_in = OMS_TRANSACTION_Structure.from_buffer_copy(message)
                    headers = data_in.hdr_
                    body = data_in.packet_

                    # finalData = {"transaction_code":headers.transaction_code,"strategy_id":headers.uid_.strategy_id,
                    #             "client_id":headers.uid_.client_id,"request_id":headers.uid_.request_id,
                    #             "error_code":headers.error_code,"reason_code":headers.reason_code,
                    #             "trigger_timestamp":headers.trigger_timestamp,"event_timestamp":headers.event_timestamp,
                    #             "exchange_timestamp":headers.exchange_timestamp,
                                
                    #             "product_id_":body.product_id_[0],"price_":body.price_[0],
                    #             "quantity_":body.quantity_[0],"flags_":body.flags_[0],"exchange_order_id":body.exchange_order_id,
                    #             "exchange_error_code":body.exchange_error_code,"exchange_response_code":body.exchange_response_code,
                    #             "exchange_client_id":body.client_id,"oms_id":body.oms_id,"algo_id":body.algo_id,"exchange_fill_id":body.exchange_fill_id
                    #     }
                    
                    print("error Code --------",self.OMS_API_TRANS_CODES[str(headers.transaction_code)])
                    
                    if((self.OMS_API_TRANS_CODES[str(headers.transaction_code)] == "OMS_ORDER_CANCELLED"                          #5555
                        or self.OMS_API_TRANS_CODES[str(headers.transaction_code)] == "OMS_TRADE")                                #6666
                        or (self.OMS_API_TRANS_CODES[str(headers.transaction_code)] == "OMS_REQ_REJ"                              #7777
                        and self.TradingDic[str(headers.uid_.client_id)+str(headers.uid_.request_id)]['event']=='create')):
                            
                            self.TradingDic.pop(str(headers.uid_.client_id)+str(headers.uid_.request_id), None)
                            print("TradingDic Popup ------------",str(headers.uid_.client_id)+str(headers.uid_.request_id))
                
                elif(msgcode == self.UI_HEADER_STRATEGYTRADE['MSGCODE']['RESPONSE'] or msgcode == self.UI_HEADER_STRATEGYTRADE['MSGCODE']['SPREADUPDATE']):

                    data_in = Strategy_Param_Structure.from_buffer_copy(message)

                    jsonData = {"client_id": data_in.client_id,"strategy_id": data_in.strategy_id,"buylive": data_in.buylive,"selllive": data_in.selllive,
                            "buyspread": data_in.buyspread,"sellspread": data_in.sellspread,"tradedlots": data_in.tradedlots,"buyavg": data_in.buyavg,
                            "sellavg": data_in.sellavg,"buytargetavg": data_in.buytargetavg,"selltargetavg": data_in.selltargetavg,"avgdisparity": data_in.avgdisparity,
                            "pnl": data_in.pnl,"token1qty": data_in.token1qty,"token2qty": data_in.token2qty,"token3qty": data_in.token3qty,"token4qty": data_in.token4qty,
                            "tc": data_in.tc,"usdinr": data_in.usdinr
                            # ,'status':str(data_in.status, 'utf-8') 
                        }
                    client_id = jsonData['client_id'] 
                    strategy_id = jsonData['strategy_id']

                    jsonData['buyavg'] = 0
                    jsonData['sellavg'] = 0
                    jsonData['avgdisparity'] = 0


                    # print(self.buySellSpreadAvgData.get(str(client_id) + str(strategy_id)))
                    avgData = self.buySellSpreadAvgData.get(str(client_id) + str(strategy_id))
                    # print("jsonData",jsonData)
                    if(avgData):
                        # print("avgData",jsonData)
                        jsonData['buyavg'] = avgData['buyavg']
                        jsonData['sellavg'] = avgData['sellavg']
                        jsonData['avgdisparity'] = avgData['avgdisparity']

                    #  "strategy_name": data_in.strategy_name

                    if(msgcode == self.UI_HEADER_STRATEGYTRADE['MSGCODE']['RESPONSE']):
                        # print(jsonData['client_id'],jsonData['strategy_id'],jsonData['buylive'],jsonData['selllive'],jsonData['buyspread'],jsonData['sellspread'])
                        self.strategylive.send(json.dumps(jsonData))
                
                        
                    elif(msgcode == self.UI_HEADER_STRATEGYTRADE['MSGCODE']['SPREADUPDATE']):
                        print("Steplot",jsonData['client_id'],jsonData['strategy_id'],jsonData['buylive'],jsonData['selllive'],jsonData['buyspread'],jsonData['sellspread'])
                        self.spreadLive.send(json.dumps(jsonData))


            except Exception as e:
                # print(traceback.print_exc())
                print("Error on recvTradeResponse",str(e))


    def receiveStrategyTrades(self):
        while True:
            try:
                rawData = self.sendDeepakStrategy.receive()
                data  = json.loads(rawData[0].decode())
                self.strategyTradeQueueList.put(data)
            except Exception as e:
                print("receiveManualTrades Exception---",e)  


    def receivebuySellSpreadAvg(self):
        while True:
            try:
                rawData = self.buySellSpreadAvg.receive()
                data  = json.loads(rawData[0].decode())
                clientid = data['clientid']
                strategyid = data['strategyid']

                self.buySellSpreadAvgData[str(clientid) + str(strategyid)] = data
            except Exception as e:
                print("receiveManualTrades Exception---",e)  

                


    def sendStrategyTradeConnection(self):
        while self.flag > 0:
            try:
                QueueData = self.strategyTradeQueueList.get()

                event = QueueData['event']
                data = QueueData['data']

                MSGCODE = self.UI_HEADER_STRATEGYTRADE['MSGCODE']
                STRATEGYTYPE = self.UI_HEADER_STRATEGYTRADE['STRATEGYTYPE']
                STRATEGYMODE = self.UI_HEADER_STRATEGYTRADE['STRATEGYMODE']

                UI_Header =  UIHeader_Structure(MSGCODE[event.upper()],1)
                
                Strategy_Param =  Strategy_Param_Structure()
                Strategy_Param.uihdr_ = UI_Header
                Strategy_Param.client_id = int(data['clientid'])
                Strategy_Param.strategy_id =  int(data['strategyid'])
                Strategy_Param.strategy_type =  int(STRATEGYTYPE[data['strategytype']]['id'])
                Strategy_Param.strategymode =  int(STRATEGYMODE[data['strategymode'].upper()])

                # print("int(STRATEGYMODE[data['strategymode'].upper()])",int(STRATEGYMODE[data['strategymode'].upper()]))

                Strategy_Param.token1 = int(setStrategyLeg(STRATEGYTYPE[data['strategytype']],data,'optiontype',"1"))
                Strategy_Param.token2 = int(setStrategyLeg(STRATEGYTYPE[data['strategytype']],data,'optiontype',"2"))
                Strategy_Param.token3 = int(setStrategyLeg(STRATEGYTYPE[data['strategytype']],data,'optiontype',"3"))
                Strategy_Param.token4 = int(setStrategyLeg(STRATEGYTYPE[data['strategytype']],data,'optiontype',"4"))

                Strategy_Param.buyspread = int(data['buyspread'])
                Strategy_Param.sellspread = int(data['sellspread'])
                
                # TODOList
                # Strategy_Param.status = bytes(data['status'])
                
                Strategy_Param.tlots = int(data['totallots'])
                Strategy_Param.nlots = int(data['netlots'])
                Strategy_Param.tradedlots = int(data['trlot'])

                # print("+++++++++++++++++++++++",data['trlot'],int(data['trlot']))

                Strategy_Param.token1qty = int(data.get('buystep',0))
                Strategy_Param.token2qty = int(data.get('sellstep',0))
                Strategy_Param.token3qty = int(data.get('steplot',0))
                Strategy_Param.token4qty = int(data.get('squareoff',0))


                Strategy_Param.token1_status = int(data.get('token1_status',0))
                Strategy_Param.token2_status = int(data.get('token2_status',0))
                Strategy_Param.token3_status = int(data.get('token3_status',0))
                Strategy_Param.token4_status = int(data.get('token4_status',0))


                print(Strategy_Param.client_id,Strategy_Param.strategy_id,Strategy_Param.strategy_type,Strategy_Param.token1,
                    Strategy_Param.token2,Strategy_Param.token3,Strategy_Param.token4,Strategy_Param.buyspread,
                    Strategy_Param.sellspread,Strategy_Param.tlots,Strategy_Param.nlots)

                # to be commmented
                if(MSGCODE[event.upper()] == 2004):
                    self.buySellSpreadAvgData.pop(str(data['clientid'])+str(data['strategyid']), None)
            
                self.socket.send(bytes(Strategy_Param))
                
            except Exception as e:
                # print(traceback.format_exc())
                print("Error on sendStrategyTradeConnection",str(e))

    
    def jsonWriter(self,data,filedirect,pkcolumnName):
        try:
            if not os.path.exists(filedirect):
                print("file not exist..")
                with open(filedirect, "w+") as file:
                    json.dump({}, file)

            with open(filedirect, "r+") as file:
                temp = json.load(file)
                temp[pkcolumnName] = data
                # print(temp)
                file.seek(0)
                json.dump(temp, file)

        except Exception as e:
            print("jsonWriter ==========",str(e))


    def systemBreak(self,signum,stack):
        print("systemBreak",signum,stack,self.exchangeListJson['Deepak'])
        try:
            BuySellAvg_filePath = str(self.baseDir)+str(self.tradingPath)+'BuySellAvg.json'

            for i in self.exchangeListJson['Deepak']:
                Trades_filePath = str(self.baseDir)+str(self.tradingPath)+str(i)+'_Trades.json'
                TradesID_filePath = str(self.baseDir)+str(self.tradingPath)+str(i)+'_TradesID.json'


                print("systemBreak self.TradingDic",self.TradingDic)
                print("systemBreak self.TradingIDDic",self.TradingIDDic)

                if len(self.TradingDic) > 0:
                    for key, value in self.TradingDic.items():
                        if(value['exchange'] == i ):
                            self.jsonWriter(value,Trades_filePath,key)
                else:
                    resetJsonWriter(Trades_filePath)

                if len(self.TradingIDDic) > 0:
                    for key, value in self.TradingIDDic.items():
                        # print("key, value",key, value,i)
                        if i in key:
                            self.jsonWriter(value,TradesID_filePath,key)

            if len(self.buySellSpreadAvgData) > 0:
                resetJsonWriter(BuySellAvg_filePath)
                for key, value in self.buySellSpreadAvgData.items():
                    self.jsonWriter(value,BuySellAvg_filePath,key)


            pid = os.getpid()
            os.system("kill -9 "+str(pid))
        except Exception as e:
            pid = os.getpid()
            os.system("kill -9 "+str(pid))
            print("systemBreak",e)



    def TrapAllSignals(self):
        # uncatchable = ['SIG_DFL','SIGSTOP','SIGKILL']
        skipSignal = ['SIGWINCH']

        for i in [x for x in dir(signal) if x.startswith("SIG")]:
            try:
                if getattr(signal,i):
                    if(not i in skipSignal):
                        signum = getattr(signal,i)
                        signal.signal(signum,self.systemBreak)
            except (OSError) as m: #OSError for Python3, RuntimeError for 2
                print("Skipping {}",i)


    def validateRequest_ID(self,key,exchange):
        flag = True
        if(self.TradingIDDic.get(key)):
            serverMap_lastRequest_id = self.serverMapDetailsJson[str(exchange).upper()]['lastRequest_id']
            if(int(self.TradingIDDic[key]) >= int(serverMap_lastRequest_id)):
                flag = False
        return flag



deepakobj = deepakTrade()
deepakobj.startDeepakThread()







   