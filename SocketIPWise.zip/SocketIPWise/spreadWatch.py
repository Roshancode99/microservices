
# import SharedArray as sa
import threading
import multiprocessing,json,time
import sys,os
from websocket import create_connection
# import socket	
from os.path import expanduser
import SharedArray as sa
import logging 
import sysv_ipc
from utils import loadJsonData
from datetime import date,datetime,timedelta
import traceback,signal
from generalCon import generalCon
from utils import setStrategyLeg,writerPID


"""Get Params From Input Ex : python pythonfileName.py FileName  """
generalSettingFile = sys.argv[1]
manualTradeSettings = sys.argv[2]


class spreadWatch(generalCon):

    def __init__(self):
        super().__init__()

        self.flag = 1
        self.printCounter = 0
        self.starttime = datetime.now()


        self.setGeneralConData(generalSettingFile)
        self.setTradingCodeData(manualTradeSettings)

        self.tokenID2KeyMapDict = dict()
        self.spreadBookWatchDict = dict()
        self.initializeQueue()

        writerPID(self.baseDir,os.getpid(),'spreadWatch','vishal')



    def initializeQueue(self):
        self.buyspreadIndex= self.spreadWatchDataPacket.get('buyspread')
        self.sellspreadIndex = self.spreadWatchDataPacket.get('sellspread')
        
        self.spreadBookWatchDict =  self.getSpreadBookWatchFile()
        # self.tokenID2KeyMapDict = self.getTokenID2KeyContractFile()
        self.getContractFile()
        self.websocketConnect()
        self.TrapAllSignals()

        try :
            self.spreadBookWatchQueue = sysv_ipc.MessageQueue(self.spreadBookWatchQueueNum,sysv_ipc.IPC_CREX)
        except Exception as e:     
            self.spreadBookWatchQueue = sysv_ipc.MessageQueue(self.spreadBookWatchQueueNum)   
        

        
    def getContractFile(self):
        flag =False
        for t in self.listOfExchanges:
            filePath = self.baseDir+self.bodPathPath+t.lower()+'_contractfile'+str(self.todayDate)+'.json'
            if(os.path.exists(filePath)):
                break
            else:
                flag =True
                cur_date = datetime.strptime(self.todayDate, "%Y%m%d").date()
                pre_date = str(cur_date+ timedelta(days=-1)).replace('-','')
                self.todayDate = pre_date
        if flag:
            self.getContractFile()
        else:
            self.tokenID2KeyMapDict = self.getTokenID2KeyContractFile()


        
    def startThread(self) :
        threading.Thread(target=self.recvSpreadWatch).start()
        threading.Thread(target=self.sendSpreadWatch).start()
     

    def recvSpreadWatch(self):
        while True:
            try:
                queueData = self.spreadBookWatchQueue.receive()
                print(queueData)
                rawData  = json.loads(queueData[0].decode())
                event  = rawData['event']
                data  = rawData['data']
                tokenkey = data['tokenkey']

                if(event == 'create'):
                    if tokenkey in self.spreadBookWatchDict:
                        self.spreadBookWatchDict[tokenkey]['count'] = self.spreadBookWatchDict[tokenkey]['count'] + 1
                    else:
                        self.spreadBookWatchDict[tokenkey] = data
                        self.spreadBookWatchDict[tokenkey]['count'] = 1

                elif(event == 'delete'):
                    self.spreadBookWatchDict[tokenkey]['count'] = self.spreadBookWatchDict[tokenkey]['count'] - 1
                    if(self.spreadBookWatchDict[tokenkey]['count'] <= 0):
                        self.spreadBookWatchDict.pop(tokenkey,None)

            except Exception as e :
                self.logger.error(str(e))
                print("[Error] in (recvSpreadWatch) msg: ",str(e))   

        
    def sendSpreadWatch(self):
        msg = dict()
        BuySpread = 0
        SellSpread = 0 
        STRATEGYTYPE  = self.UI_HEADER_STRATEGYTRADE['STRATEGYTYPE']
        bid = self.marketDataStruct['bid0']
        ask = self.marketDataStruct['ask0']


        while self.flag>0 :
            try :
                for key ,value in list(self.spreadBookWatchDict.items()):
                    endtime = datetime.now()

                    spreadtype = value['spreadtype']
                    clientid = value['clientid']
                    tokenkey = value['tokenkey']

                    StrategyDetails = STRATEGYTYPE[spreadtype]

                    if(StrategyDetails['id'] == 1):
                        # print(StrategyDetails)
                        # two leg spread
                        
                        token1 = str(setStrategyLeg(StrategyDetails,value,'optiontype',"1"))
                        token2 = str(setStrategyLeg(StrategyDetails,value,'optiontype',"2"))
                        
                        token1Divider = self.tokenID2KeyMapDict[token1]['divider']
                        token2Divider = self.tokenID2KeyMapDict[token2]['divider']

                        try:
                            TokenArray1 = sa.attach("file://{}/{}/{}".format(self.baseDir,'tickers',token1))
                            TokenArray2= sa.attach("file://{}/{}/{}".format(self.baseDir,'tickers',token2))
                            
                            T1BID = TokenArray1[bid]/int(token1Divider)
                            T1ASK = TokenArray1[ask]/int(token1Divider)

                            T2BID = TokenArray2[bid]/int(token2Divider)
                            T2ASK = TokenArray2[ask]/int(token2Divider)

                            BuySpread =  T1BID - T2ASK
                            SellSpread = T1ASK - T2BID 

                            # print("spreadParity",BuySpread,SellSpread)
        
                            del TokenArray1
                            del TokenArray2
                        except Exception as e:
                            print(e)


                    elif(StrategyDetails['id'] == 2):
                        # three leg conrev
                        # print(StrategyDetails)
                        strikePrice = int(value['strikeprice1'])

                        token1 = str(setStrategyLeg(StrategyDetails,value,'optiontype',"1"))
                        token2 = str(setStrategyLeg(StrategyDetails,value,'optiontype',"2"))
                        token3 = str(setStrategyLeg(StrategyDetails,value,'optiontype',"3"))

                        token1Divider = self.tokenID2KeyMapDict[token1]['divider']
                        token2Divider = self.tokenID2KeyMapDict[token2]['divider']
                        token3Divider = self.tokenID2KeyMapDict[token3]['divider']


                        try:
                            TokenArray1 = sa.attach("file://{}/{}/{}".format(self.baseDir,'tickers',token1))
                            TokenArray2= sa.attach("file://{}/{}/{}".format(self.baseDir,'tickers',token2))
                            TokenArray3 = sa.attach("file://{}/{}/{}".format(self.baseDir,'tickers',token3))
                            
                            # print(("file://{}/{}/{}".format(self.baseDir,'tickers',token1)))
                            T1BID = TokenArray1[bid]/int(token1Divider)
                            T1ASK = TokenArray1[ask]/int(token1Divider)

                            T2BID = TokenArray2[bid]/int(token2Divider)
                            T2ASK = TokenArray2[ask]/int(token2Divider)

                            T3BID = TokenArray3[bid]/int(token3Divider)
                            T3ASK = TokenArray3[ask]/int(token3Divider)
                                
                            BuySpread = strikePrice + T1BID - T3ASK - T2ASK
                            SellSpread = strikePrice + T1ASK - T2BID - T3BID
        
                            del TokenArray1
                            del TokenArray2
                            del TokenArray3
                        except Exception as e:
                            print(e)
        
                    # print("conrevParity",BuySpread,SellSpread)
                    item = {"tokenkey":tokenkey,"buyspread":str(BuySpread) ,"sellspread":str(SellSpread)}
                    
                    if((endtime-self.starttime).seconds > 1):
                        self.starttime = datetime.now()
                        msg = self.saveBroadcast(item)
                        if(msg):
                            # print((endtime-self.starttime).seconds)
                            try:
                                self.broadCastServiceCon.send(json.dumps(msg))
                                # self.printCounter = self.printCounter + 1
                                # if(self.printCounter == 100):
                                #     # print(msg)
                                #     self.printCounter = 0

                            except Exception as e:
                                print("exception" ,e)
                                self.websocketConnect()
                                self.broadCastServiceCon.send(json.dumps(msg))
                            
            except Exception as e:
                print("[Error] in (self,sendSpreadWatch) msg: ",str(e)) 

                        

    def saveBroadcast(self,item):
        msg = dict()
        try:
            filePath = str(self.baseDir)+str(self.spreadWatchListPath)+str(item.get('tokenkey'))
            # print("file://"+filePath)
            if(os.path.exists(filePath)):
                sharedTokenArray = sa.attach("file://"+filePath)
                sharedTokenArray[self.buyspreadIndex] = item.get('buyspread')  #tokenid2
                sharedTokenArray[self.sellspreadIndex] = item.get('sellspread')      #bid
            
                """ delete a instance """
                del sharedTokenArray

                msg = {"event":"spreadwatch","tokenkey":str(item.get('tokenkey')) }
                return msg
        except Exception as e:
            print("[Error] in (self,saveBroadcast) msg: ",str(e))  

            return msg


    def jsonWriter(self,data,filedirect,pkcolumnName):
        try:
            if not os.path.exists(filedirect):
                print("file not exist..")
                with open(filedirect, "w+") as file:
                    json.dump({}, file)

            with open(filedirect, "r+") as file:

                temp = json.load(file)
                temp[pkcolumnName] = data
                # print(temp)
                file.seek(0)
                json.dump(temp, file)

        except Exception as e:
            print("jsonWriter ==========",str(e))


    def systemBreak(self,signum,stack):
        try:
            print("systemBreak self.spreadBookWatchDict",self.spreadBookWatchDict)

            if len(self.spreadBookWatchDict) > 0:
                for key, value in self.spreadBookWatchDict.items():
                    self.jsonWriter(value,self.spreadBookWatch_filePath,key)
            else:
                print("inside else")
                resetJsonWriter(self.spreadBookWatch_filePath)

            pid = os.getpid()
            os.system("kill -9 "+str(pid))
        except Exception as e:
            pid = os.getpid()
            os.system("kill -9 "+str(pid))
            print("systemBreak",e)


    def TrapAllSignals(self):
        # uncatchable = ['SIG_DFL','SIGSTOP','SIGKILL']
        skipSignal = ['SIGWINCH']

        for i in [x for x in dir(signal) if x.startswith("SIG")]:
            try:
                if getattr(signal,i):
                    if(not i in skipSignal):
                        signum = getattr(signal,i)
                        signal.signal(signum,self.systemBreak)
            except (OSError) as m: #OSError for Python3, RuntimeError for 2
                print ("Skipping {}",i)


spreadWatchobj = spreadWatch()
spreadWatchobj.startThread()