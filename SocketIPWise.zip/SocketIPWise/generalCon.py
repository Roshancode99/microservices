import threading
from datetime import date,datetime,timedelta
import multiprocessing,json,time
import sys,os
import pandas as pd
from websocket import create_connection
from os.path import expanduser
import logging ,zmq
from utils import createFolder,createJson,setSocketInstance


class generalCon:
    def __init__(self):
        self.baseDir=''
        self.tradingPath =''
        self.exchange =''
        self.segment =''
        self.broadCastServiceCon = None

        self.todayDate = str(date.today()).replace('-','')

        # self.DeepakExchangeList = ['NSEFO','SGXXX']
        # self.JayeshExchangeList = ['MT5XX']

        self.logger=logging.getLogger() 
        self.home = expanduser("~")

        createFolder(self.home,'sharedMemory')
        createFolder(self.home,'sharedMemory/settings')
        createFolder(self.home,'sharedMemory/spreadwatch')

     
    # """ read settingFile and Instantiate Varibles """
    def setGeneralConData(self,generalSettings):
        try:
            with open(generalSettings, "r") as jsonfile:
                self.generalSettingsData = json.load(jsonfile)
        except Exception as e:
            print(e)


        try:
            self.BloombergData = pd.read_csv('./TokenFile/ParityDetails.csv')
        except Exception as e:
            print(e)

        self.generalSettingsJson = self.generalSettingsData.get('settings')
        self.contractSettings = self.generalSettingsData.get("contractSettings")

        self.queueKeyJson = self.generalSettingsData.get('queueKey')
        self.MarketDatajson = self.generalSettingsData.get('marketdata')
        self.marketDataStruct = self.MarketDatajson.get("packet")
        self.sharedArraySize = self.MarketDatajson.get('sharedArraySize')

        self.webSocketRoutes = self.generalSettingsJson.get("webSocketRoutes")

        self.baseDir = self.generalSettingsJson.get('baseDir')                        
        self.fileLocation = self.generalSettingsJson.get('fileLocation')
            
        self.tickersPath = self.fileLocation.get('tickers')   
        self.candleStickPath = self.fileLocation.get('candleStickPath')              

        self.contractsPath = self.fileLocation.get('contracts')              
        self.bodPathPath = self.fileLocation.get('bodPath')          
        self.tradingPath = self.fileLocation.get('tradingPath')          
        self.spreadWatchPath = self.fileLocation.get('spreadWatchPath')          
        self.spreadWatchListPath = self.fileLocation.get('spreadWatchListPath')          

        self.broadCastRoute = self.webSocketRoutes.get('broadCastRoute')
        print(self.broadCastRoute)
    

        
        self.strategyLiveQueueNum = self.queueKeyJson.get('strategyLiveQueue')
        self.spreadLiveQueueNum = self.queueKeyJson.get('SpreadLiveQueue')

        self.spreadBookWatchQueueNum = self.queueKeyJson.get('spreadBookWatchQueue')
        self.mt5ResponseQueueNum = self.queueKeyJson.get('mt5ResponseQueue')
        self.strategyQueueNum = self.queueKeyJson.get('strategyQueue')
        self.manualTradeQueueNum = self.queueKeyJson.get('manualTradeQueue')

        self.sendJayeshTradesNum = self.queueKeyJson.get('sendJayeshTradesQueue')
        self.sendDeepakStrategyNum = self.queueKeyJson.get('sendDeepakStrategyQueue')
        self.sendDeepakTradesNum = self.queueKeyJson.get('sendDeepakTradesQueue')
        self.candleStickQueueNum = self.queueKeyJson.get('candleStickQueue')
        self.bloombergParityQueueNum = self.queueKeyJson.get('bloombergParityQueue')
        self.AnalysisDataQueueNum = self.queueKeyJson.get('AnalysisDataQueue')


        self.buySellSpreadAvgQueueNum = self.queueKeyJson.get('buySellSpreadAvgQueue')

        self.spreadWatchdata = self.generalSettingsData.get('spreadWatchdata')
        self.spreadWatchDataPacket = self.spreadWatchdata.get('packet')

        self.strategyLivedata = self.generalSettingsData.get('strategylivedata')
        self.strategyLiveDataPacket = self.strategyLivedata.get('packet')

        self.candleStickdata = self.generalSettingsData.get('candleStickdata')
        self.candleStickdataPacket = self.candleStickdata.get('packet')

        self.serverMapJson = self.generalSettingsData.get('serverMap')
        self.exchangeListJson = self.serverMapJson.get('exchangeList')
        self.serverMapDetailsJson = self.serverMapJson.get('details')

        self.listOfExchanges = self.contractSettings.keys()


    def setServerConData(self,exchangeSettings):

        jsonFileName = exchangeSettings.split('/')[-1].replace('.json','')
        createJson(self.home+'/sharedMemory/settings',jsonFileName,{})


        try:
            with open(exchangeSettings, "r") as jsonfile:
                self.exchangeSettingsData = json.load(jsonfile)
        except Exception as e:
            print(e)

        self.exchangeSettingsJson = self.exchangeSettingsData.get('settings')
        self.maxsizeQueue = self.exchangeSettingsJson.get('maxsizeQueue')
        # """ define queue size """

        self.broadCastQueueList = multiprocessing.Queue(self.maxsizeQueue)

        self.host = self.exchangeSettingsJson.get('host')
        self.port = self.exchangeSettingsJson.get('port')
        self.exchange = self.exchangeSettingsJson.get('exchange')
        self.segment = self.exchangeSettingsJson.get('segment')

        self.context = zmq.Context()
        self.socket = self.context.socket(zmq.PAIR)
        self.socket.bind(f"tcp://{self.host}:{self.port}")
            
        if self.exchange:
            createFolder(os.getcwd(),'Logs')
            self.logFileDir = 'Logs/'+self.exchange.lower()+'Logs'
            createFolder(os.getcwd(),self.logFileDir)
            createFolder(os.getcwd(),"TokenFile")


   
    def setTradingServerConData(self,tradingServerSettings,ExchangeListName): 
        
        self.TradingDic = dict()
        self.TradingIDDic = dict()
        self.buySellSpreadAvgData = dict()


        try:
            with open(tradingServerSettings, "r") as jsonfile:
                self.tradingServerSettingsData = json.load(jsonfile)
        except Exception as e:
            print(e)

        self.tradingServerSettingsJson = self.tradingServerSettingsData.get('settings')

        tradingExchangeList = self.exchangeListJson[ExchangeListName]

        self.tradingServerSettingsJson = self.serverMapDetailsJson.get(tradingExchangeList[0])
        self.tradingMaxsizeQueue = self.tradingServerSettingsJson.get('maxsizeQueue')

        self.tradingIP = self.tradingServerSettingsJson.get('ip')
        self.tradingPort = self.tradingServerSettingsJson.get('port')

        BuySellAvg_filePath = str(self.baseDir)+str(self.tradingPath)+'BuySellAvg.json'
        

        for i in tradingExchangeList:
            # print("+++++++",(str(self.baseDir)+str(self.tradingPath)+str(i)+'_Trades.json'))
            now = datetime.now()
            if (now.hour <= 9 and now.minute <=15) or now.hour < 9:
                try:
                    os.remove(str(self.baseDir)+str(self.tradingPath)+str(i)+'_Trades.json')
                    os.remove(str(self.baseDir)+str(self.tradingPath)+str(i)+'_TradesID.json')
                except OSError:
                    pass

            Trades_filePath = str(self.baseDir)+str(self.tradingPath)+str(i)+'_Trades.json'
            TradesID_filePath = str(self.baseDir)+str(self.tradingPath)+str(i)+'_TradesID.json'
            

            if(not os.path.exists(Trades_filePath)):
                with open(Trades_filePath, "w") as f:
                    json.dump({}, f)
            else:
                temp=json.load(open(Trades_filePath))
                self.TradingDic.update(temp)

            if(not os.path.exists(TradesID_filePath)):
                with open(TradesID_filePath, "w") as f:
                    json.dump({}, f)
            else:
                temp=json.load(open(TradesID_filePath))
                self.TradingIDDic.update(temp)


        if(not os.path.exists(BuySellAvg_filePath)):
            with open(BuySellAvg_filePath, "w") as f:
                json.dump({}, f)
        else:
            temp=json.load(open(BuySellAvg_filePath))
            self.buySellSpreadAvgData.update(temp)

        self.socket = setSocketInstance(self.tradingIP,self.tradingPort)

    # """ read settingFile and Instantiate Varibles """
    def setTradingCodeData(self,manualTradeSettings):
        try:
            with open(manualTradeSettings, "r") as jsonfile:
                self.manualTradeSettingsData = json.load(jsonfile)
        except Exception as e:
            print(e)

            
        BuySellAvg_filePath = str(self.baseDir)+str(self.tradingPath)
        print("BuySellAvg_filePath",BuySellAvg_filePath)
        createJson(BuySellAvg_filePath,'BuySellAvg',{})
            

        self.configData = self.manualTradeSettingsData.get('configData')
        self.OMS_API_TRANS_CODES = self.manualTradeSettingsData.get('OMS_API_TRANS_CODES')
        self.OMS_API_ERROR_CODES = self.manualTradeSettingsData.get('OMS_API_ERROR_CODES')

        self.UI_HEADER = self.manualTradeSettingsData.get('UI_HEADER')
        self.UI_HEADER_MANUALTRADE =self.UI_HEADER.get('ManualTrade')
        self.UI_HEADER_STRATEGYTRADE =self.UI_HEADER.get('StrategyTrade')
        


    def getTokenIDKeyContractFile(self,filePath,exchange,segment):
        tokenIDKeyMapDict = dict()
        # df = pd.read_csv(filePath, usecols = ['token','tokenID2'])
        df = pd.read_csv(filePath)
        df = df.loc[(df['exchange'] == exchange) & (df['segment'] == segment)]
        df.to_csv("TokenFile/"+exchange+segment+"Data.csv")
        temp = df.to_dict('records')
        for i in temp:
            tokenIDKeyMapDict[i['token']] = i
        # print(tokenIDKeyMapDict)
        
        return tokenIDKeyMapDict

   
    def getTokenID2KeyContractFile(self):
        tokenID2KeyMapDict = dict()

        for t in self.listOfExchanges:
            filePath = self.baseDir+self.bodPathPath+t.lower()+'_contractfile'+str(self.todayDate)+'.json'
            if(os.path.exists(filePath)):
                temp=json.load(open(filePath))
                tokenID2KeyMapDict.update(temp)

        return tokenID2KeyMapDict


    def getSpreadBookWatchFile(self):
        spreadBookWatchDict = dict()
        self.spreadBookWatch_filePath = str(self.baseDir)+str(self.spreadWatchPath)+'spreadWatch.json'

        if(not os.path.exists(self.spreadBookWatch_filePath)):
            with open(self.spreadBookWatch_filePath, "w") as f:
                json.dump({}, f)
        else:
            temp=json.load(open(self.spreadBookWatch_filePath))
            spreadBookWatchDict.update(temp)
        return spreadBookWatchDict
        

    def websocketConnect(self):
        print('hello')
        print(self.broadCastRoute)
        try:
            self.broadCastServiceCon = create_connection(self.broadCastRoute,cookie="broadcastService")
            print("self.broadCastServiceCon",self.broadCastServiceCon)
        except Exception as e:
            time.sleep(1)
            print("[Error] in (self,websocketConnect) msg: ",str(e))   
            self.websocketConnect()